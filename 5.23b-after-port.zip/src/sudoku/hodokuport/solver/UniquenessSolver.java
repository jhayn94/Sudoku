/*
 * Copyright (C) 2008-12  Bernhard Hobiger
 *
 * This file is part of HoDoKu.
 *
 * HoDoKu is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * HoDoKu is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with HoDoKu. If not, see <http://www.gnu.org/licenses/>.
 */

package sudoku.hodokuport.solver;

import java.util.ArrayList;
import java.util.List;

import sudoku.hodokuport.model.Candidate;
import sudoku.hodokuport.model.Options;
import sudoku.hodokuport.model.SolutionStep;
import sudoku.hodokuport.model.SolutionType;
import sudoku.hodokuport.model.Sudoku2;
import sudoku.hodokuport.model.SudokuStatus;
import sudoku.model.SudokuSet;

public class UniquenessSolver extends AbstractSolver {

	/** An array for caching constraint indices while searching for BUG +1 */
	private final int[] bugConstraints = new int[3];
	/** One global step for optimization */
	private final SolutionStep globalStep = new SolutionStep(SolutionType.FULL_HOUSE);
	/** All steps that were found in this search */
	private List<SolutionStep> steps = new ArrayList<>();
	/**
	 * All already checked rectangles: One int aabbccdd with "aa"... the indices
	 * of the corners (sorted ascending)
	 */
	private final int[] rectangles = new int[400];
	/** Current index in {@link #rectangles}. */
	private int rectAnz = 0;
	/** Contains the indices of the current rectangle */
	private final int[] indexe = new int[4];
	/** Temporary array for sorting */
	private final int[] tmpRect = new int[4];
	/** The first candidate of the UR */
	private int cand1;
	/** The second candidate of the UR */
	private int cand2;
	/** A list of cached steps */
	private final List<SolutionStep> cachedSteps = new ArrayList<>();
	/**
	 * The {@link SudokuStepFinder#stepNumber} under which the cached steps were
	 * found
	 */
	private int stepNumber = -1;
	/**
	 * A set with all cells that hold only {@link #cand1} and/or {@link #cand2}.
	 */
	private final SudokuSet twoCandidates = new SudokuSet();
	/** A set with all cells that hold additional candidates */
	private final SudokuSet additionalCandidates = new SudokuSet();
	/** A set for various checks */
	private final SudokuSet tmpSet = new SudokuSet();
	/** A set for various checks */
	private final SudokuSet tmpSet1 = new SudokuSet();
	/** A flag that indicates if the last search was for URs */
	private boolean lastSearchWasUR = false;
	/** A flag that indicates if the last search was for ARs */
	private boolean lastSearchWasAR = false;

	/**
	 * Creates a new instance of SimpleSolver
	 *
	 * @param finder
	 */
	public UniquenessSolver(final SudokuStepFinder finder) {
		super(finder);
	}

	@Override
	protected SolutionStep getStep(final SolutionType type) {
		SolutionStep result = null;
		this.sudoku = this.finder.getSudoku();
		if (this.sudoku.getStatus() != SudokuStatus.VALID) {
			// Uniqueness only for sudokus, that are strictly valid!
			return null;
		}
		switch (type) {
		case UNIQUENESS_1:
		case UNIQUENESS_2:
		case UNIQUENESS_3:
		case UNIQUENESS_4:
		case UNIQUENESS_5:
		case UNIQUENESS_6:
		case HIDDEN_RECTANGLE:
			result = this.getUniqueness(type);
			break;
		case AVOIDABLE_RECTANGLE_1:
		case AVOIDABLE_RECTANGLE_2:
			if (this.sudoku.getStatusGivens() != SudokuStatus.VALID) {
				// only, if the givens themselves have only one solution!
				return null;
			}
			result = this.getAvoidableRectangle(type);
			break;
		case BUG_PLUS_1:
			result = this.getBugPlus1();
			break;
		default:
			// Nothing to do.
		}

		return result;

	}

	@Override
	protected boolean doStep(final SolutionStep step) {
		boolean handled = true;
		this.sudoku = this.finder.getSudoku();
		switch (step.getType()) {
		case UNIQUENESS_1:
		case UNIQUENESS_2:
		case UNIQUENESS_3:
		case UNIQUENESS_4:
		case UNIQUENESS_5:
		case UNIQUENESS_6:
		case HIDDEN_RECTANGLE:
		case AVOIDABLE_RECTANGLE_1:
		case AVOIDABLE_RECTANGLE_2:
		case BUG_PLUS_1:
			for (final Candidate cand : step.getCandidatesToDelete()) {
				this.sudoku.delCandidate(cand.getIndex(), cand.getValue());
			}
			break;
		default:
			handled = false;
		}
		return handled;
	}

	/**
	 * Try to get an appropriate step from the cache {@link #cachedSteps}. If none
	 * is available or the sudoku has changed since the last call find a new one.
	 * If no step is found but the sudoku has not changed the already found and
	 * stored URs ({@link #rectangles}) are not reset (they have already been
	 * searched and if a step was in them it would have been cached).
	 */
	private SolutionStep getUniqueness(final SolutionType type) {
		if (this.finder.getStepNumber() == this.stepNumber && this.lastSearchWasUR) {
			if (!this.cachedSteps.isEmpty()) {
				// try to find the step in cachedSteps
				for (final SolutionStep step : this.cachedSteps) {
					if (step.getType() == type) {
						return step;
					}
				}
			}
		} else {
			this.stepNumber = this.finder.getStepNumber();
			this.cachedSteps.clear();
			this.rectAnz = 0;
		}
		this.lastSearchWasUR = true;
		this.lastSearchWasAR = false;
		return this.getAllUniquenessInternal(type, true);
	}

	/**
	 * More or less equal to {@link #getUniqueness(sudoku.SolutionType)}.
	 */
	private SolutionStep getAvoidableRectangle(final SolutionType type) {
		if (this.finder.getStepNumber() == this.stepNumber && this.lastSearchWasAR) {
			if (!this.cachedSteps.isEmpty()) {
				// try to find the step in cachedSteps
				for (final SolutionStep step : this.cachedSteps) {
					if (step.getType() == type) {
						return step;
					}
				}
			}
		} else {
			this.stepNumber = this.finder.getStepNumber();
			this.cachedSteps.clear();
			this.rectAnz = 0;
		}
		this.lastSearchWasUR = false;
		this.lastSearchWasAR = true;
		return this.getAllAvoidableRectangles(type, true);
	}

	/**
	 * Find all Uniqueness steps except BUG+1
	 */
	protected List<SolutionStep> getAllUniqueness() {
		this.stepNumber = -1;
		this.cachedSteps.clear();
		this.rectAnz = 0;
		this.lastSearchWasAR = false;
		this.lastSearchWasUR = false;
		this.sudoku = this.finder.getSudoku();
		final List<SolutionStep> tmpSteps = new ArrayList<>();
		final List<SolutionStep> oldSteps = this.steps;
		this.steps = tmpSteps;
		this.getAllUniquenessInternal(null, false);
		this.getAllAvoidableRectangles(null, false);
		this.steps = oldSteps;
		return tmpSteps;
	}

	/**
	 * Find all available Avoidable Rectangles. If <code>onlyone</code> is
	 * <code>true</code>, the first one found is returned.
	 */
	private SolutionStep getAllAvoidableRectangles(final SolutionType type, final boolean onlyOne) {
		// check for solved cells that are not givens
		for (int i = 0; i < Sudoku2.LENGTH; i++) {
			if (this.sudoku.getValue(i) == 0 || this.sudoku.isFixed(i)) {
				// cell is either not solved or a given
				continue;
			}
			this.cand1 = this.sudoku.getValue(i);
			SolutionStep step = this.findUniquenessForStartCell(i, true, type, onlyOne);
			if (step != null && onlyOne) {
				return step;
			}
			step = this.findUniquenessForStartCell(i, true, type, onlyOne);
			if (step != null && onlyOne) {
				return step;
			}
		}
		return null;
	}

	/**
	 * Find all bivalue cells and take them as starting point for a search. the
	 * search itself is delegated to ....
	 */
	private SolutionStep getAllUniquenessInternal(final SolutionType type, final boolean onlyOne) {
		// get bivalue cells
		for (int i = 0; i < Sudoku2.LENGTH; i++) {
			if (this.sudoku.getNumberOfCandidates(i) == 2) {
				final int[] cands = this.sudoku.getAllCandidates(i);
				this.cand1 = cands[0];
				this.cand2 = cands[1];
				final SolutionStep step = this.findUniquenessForStartCell(i, false, type, onlyOne);
				if (step != null && onlyOne) {
					return step;
				}
			}
		}
		return null;
	}

	/**
	 * Only one cell exists with three candidates, all other cells have two
	 * candidates. All candidates appear in all units exactly twice, except one of
	 * the candidates in the cell with the three candidates.
	 */
	private SolutionStep getBugPlus1() {
		// check the number of candidates in all cells
		int index3 = -1;
		for (int i = 0; i < Sudoku2.LENGTH; i++) {
			final int anz = this.sudoku.getNumberOfCandidates(i);
			if (anz > 3) {
				// no BUG+1!
				return null;
			} else if (anz == 3) {
				if (index3 != -1) {
					// second cell with three candidates -> no BUG+1!
					return null;
				}
				index3 = i;
			}
		}
		if (index3 == -1) {
			// no cell with three candidates exists -> no BUG+1
			return null;
		}
		// all cells have two candidates except one and that cell is index3
		// -> check for possible BUG+1
		int cand3 = -1;
		this.bugConstraints[0] = -1;
		this.bugConstraints[1] = -1;
		this.bugConstraints[2] = -1;
		final byte[][] free = this.sudoku.getFree();
		for (int constr = 0; constr < free.length; constr++) {
			for (int cand = 1; cand <= 9; cand++) {
				final int anz = free[constr][cand];
				if (anz > 3) {
					// no BUG+1
					return null;
				} else if (anz == 3) {
					// must be for same candidate and only once per type of constraint
					if (this.bugConstraints[constr / 9] != -1 || (cand3 != -1 && cand3 != cand)) {
						// cant be BUG+1
						return null;
					}
					cand3 = cand;
					this.bugConstraints[constr / 9] = constr;
				}
			}
		}
		// still here?
		if (this.sudoku.isCandidate(index3, cand3) && Sudoku2.CONSTRAINTS[index3][0] == this.bugConstraints[0]
				&& Sudoku2.CONSTRAINTS[index3][1] == this.bugConstraints[1]
				&& Sudoku2.CONSTRAINTS[index3][2] == this.bugConstraints[2]) {
			// ok it IS a BUG+1
			// don't call initStep()!
			this.globalStep.reset();
			this.globalStep.setType(SolutionType.BUG_PLUS_1);
			final int[] candArr = this.sudoku.getAllCandidates(index3);
			for (int i = 0; i < candArr.length; i++) {
				if (candArr[i] != cand3) {
					this.globalStep.addCandidateToDelete(index3, candArr[i]);
				}
			}
			return (SolutionStep) this.globalStep.clone();
		}
		return null;
	}

	/**
	 * When checking for avoidable rectangles some rules change: index11/index12
	 * have to be solved cells, they designate the candidates; the other side of
	 * the avoidable rectangle has to have at least one not solved cell. All
	 * solved cells must not be givens.
	 */
	private SolutionStep findUniquenessForStartCell(final int index11, final boolean avoidable, final SolutionType type,
			final boolean onlyOne) {
		final boolean allowMissing = Options.getInstance().isAllowUniquenessMissingCandidates();

		// find a second cell within the same block that contains the same two
		// candidates
		// and is either in the same row or in the same column
		// start the search with index11 to avoid double findings
		final int line11 = Sudoku2.getLine(index11);
		final int col11 = Sudoku2.getCol(index11);
		final int block11 = Sudoku2.getBlock(index11);
		final int cell11 = this.sudoku.getCell(index11);
		final SudokuSet allowedCand1 = this.finder.getCandidatesAllowed()[this.cand1];
		final SudokuSet allowedCand2 = this.finder.getCandidatesAllowed()[this.cand2];
		final int[] blockIndices = Sudoku2.BLOCKS[Sudoku2.getBlock(index11)];
		for (int i = 0; i < blockIndices.length; i++) {
			if (blockIndices[i] == index11) {
				continue;
			}
			final int index12 = blockIndices[i];
			if (line11 != Sudoku2.getLine(index12) && col11 != Sudoku2.getCol(index12)) {
				// not in the same row or col -> cannot become a rectangle
				continue;
			}
			// check it
			final int cell12 = this.sudoku.getCell(index12);
			if ((!avoidable && (this.sudoku.getValue(index12) == 0 && ((!allowMissing && (cell11 & cell12) == cell11)
					|| (allowMissing && allowedCand1.contains(index12) && allowedCand2.contains(index12)))))
					|| (avoidable && (this.sudoku.getValue(index12) != 0 && !this.sudoku.isFixed(index12)))) {
				if (avoidable) {
					this.cand2 = this.sudoku.getValue(index12);
				}
				// possible second endpoint: check for rectangles
				final boolean isLines = line11 == Sudoku2.getLine(index12);
				// get the units that have to hold the opposite side of the rectangle
				final int[] unit11 = Sudoku2.ALL_UNITS[isLines ? Sudoku2.getCol(index11) + 9 : Sudoku2.getLine(index11)];
				final int[] unit12 = Sudoku2.ALL_UNITS[isLines ? Sudoku2.getCol(index12) + 9 : Sudoku2.getLine(index12)];
				// check the units: two adequate cells at the same indices in a
				// different block
				for (int j = 0; j < unit11.length; j++) {
					if (Sudoku2.getBlock(unit11[j]) == block11) {
						// must be another block!
						continue;
					}
					final int index21 = unit11[j];
					final int index22 = unit12[j];
					final int cell21 = this.sudoku.getCell(index21);
					final int cell22 = this.sudoku.getCell(index22);

					if ((!avoidable && (!allowMissing && (cell21 & cell11) == cell11 && (cell22 & cell11) == cell11))
							|| (allowMissing && allowedCand1.contains(index21) && allowedCand1.contains(index22)
									&& allowedCand2.contains(index22))
							|| (avoidable && ((this.sudoku.getValue(index21) == this.cand2 && !this.sudoku.isFixed(index21)
									&& this.sudoku.getValue(index22) == 0 && this.sudoku.isCandidate(index22, this.cand1)
									&& this.sudoku.getNumberOfCandidates(index22) == 2)
									|| (this.sudoku.getValue(index22) == this.cand1 && !this.sudoku.isFixed(index22)
											&& this.sudoku.getValue(index21) == 0 && this.sudoku.isCandidate(index21, this.cand2)
											&& this.sudoku.getNumberOfCandidates(index21) == 2)
									|| (this.sudoku.getValue(index21) == 0 && this.sudoku.isCandidate(index21, this.cand2)
											&& this.sudoku.getNumberOfCandidates(index21) == 2 && this.sudoku.getValue(index22) == 0
											&& this.sudoku.isCandidate(index22, this.cand1)
											&& this.sudoku.getNumberOfCandidates(index22) == 2)))) {
						// ok, could be a UR: didi we have it already?
						if (this.checkRect(index11, index12, index21, index22)) {
							// check for UR Type and get candidates that can be deleted
							this.indexe[0] = index11;
							this.indexe[1] = index12;
							this.indexe[2] = index21;
							this.indexe[3] = index22;
							SolutionStep step = null;
							if (avoidable) {
								step = this.checkAvoidableRectangle(index21, index22, type, onlyOne);
							} else {
								step = this.checkURForStep(type, onlyOne);
							}
							if (step != null && onlyOne) {
								return step;
							}
						}
					}
				}
			}
		}
		return null;
	}

	/**
	 * Checks the UR in {@link #indexe} for a possible UR. All UR types are
	 * checked at once, if <code>onlyOne</code> is set and a UR of type
	 * <code>searchType</code> could be found it is returned immediately.
	 */
	private SolutionStep checkURForStep(final SolutionType searchType, final boolean onlyOne) {
		// collects all cells that contain only cand1 and/or cand2 in twoCandidates
		// and all candidates in the UR except cand1 and cand2 in
		// additionalCandidates
		this.initCheck(this.indexe);

		SolutionStep step = null;
		final int twoSize = this.twoCandidates.size();
		final short urMask = (short) (Sudoku2.MASKS[this.cand1] | Sudoku2.MASKS[this.cand2]);

		// Uniqueness Test 1: 3 cells have only 2 candidates -> delete cand1 and
		// cand2 from the fourth cell
		if (twoSize == 3) {
			// yes, it is a Uniqueness Type 1
			this.initStep(SolutionType.UNIQUENESS_1);
			final int delIndex = this.additionalCandidates.get(0);
			if (this.sudoku.isCandidate(delIndex, this.cand1)) {
				this.globalStep.addCandidateToDelete(delIndex, this.cand1);
			}
			if (this.sudoku.isCandidate(delIndex, this.cand2)) {
				this.globalStep.addCandidateToDelete(delIndex, this.cand2);
			}
			if (!this.globalStep.getCandidatesToDelete().isEmpty()) {
				step = (SolutionStep) this.globalStep.clone();
				if (onlyOne) {
					if (searchType == step.getType()) {
						return step;
					} else {
						this.cachedSteps.add(step);
					}
				} else {
					this.steps.add(step);
				}
			}
		}

		// Uniqueness Test 2/5/5A: one or two cells have 2 candidates, the other
		// have exactly one additional candidate, which is the same for all cells:
		// This candidate
		// can be deleted from all cells that can see all UR cells with that
		// candidate.
		// If there are only two additional candidate cells and if they are in the
		// same cell or row it is a UR 2, else a UR 5
		if (twoSize == 2 || twoSize == 1) {
			short addMask = 0;
			this.tmpSet.setAll();
			for (int i = 0; i < this.additionalCandidates.size(); i++) {
				final int index3 = this.additionalCandidates.get(i);
				addMask |= (short) (this.sudoku.getCell(index3) & ~urMask);
				if (Sudoku2.ANZ_VALUES[addMask] > 1) {
					break;
				}
				this.tmpSet.and(Sudoku2.buddies[index3]);
			}
			if (Sudoku2.ANZ_VALUES[addMask] == 1) {
				// ok, valid UR 2 or UR 5
				// get cells that can see all cells with the additional candidate
				final int addCand = Sudoku2.CAND_FROM_MASK[addMask];
				this.tmpSet.and(this.finder.getCandidates()[addCand]);
				if (!this.tmpSet.isEmpty()) {
					// ok, valid step
					SolutionType type = SolutionType.UNIQUENESS_2;
					final int i1 = this.additionalCandidates.get(0);
					final int i2 = this.additionalCandidates.get(1);
					if (this.additionalCandidates.size() == 3
							|| (Sudoku2.getLine(i1) != Sudoku2.getLine(i2) && Sudoku2.getCol(i1) != Sudoku2.getCol(i2))) {
						type = SolutionType.UNIQUENESS_5;
					}
					this.initStep(type);
					for (int i = 0; i < this.tmpSet.size(); i++) {
						this.globalStep.addCandidateToDelete(this.tmpSet.get(i), addCand);
					}
					step = (SolutionStep) this.globalStep.clone();
					if (onlyOne) {
						if (searchType == step.getType()) {
							return step;
						} else {
							this.cachedSteps.add(step);
						}
					} else {
						this.steps.add(step);
					}
				}
			}
		}

		// Uniqueness Test 3: If two UR cells have additional candidates, find in
		// one of their houses additional (k - 1) cells, so that all cells contain
		// exactly k candidates (cand1 and cand2 may not appear in any of these
		// cells). If we find such cells, the k candidates can be deleted from all
		// other cells in the house.
		if (twoSize == 2) {
			short u3Cands = 0;
			// get all additional candidates
			for (int i = 0; i < this.additionalCandidates.size(); i++) {
				final int index3 = this.additionalCandidates.get(i);
				u3Cands |= (short) (this.sudoku.getCell(index3) & ~urMask);
			}
			// check the houses
			final int i1 = this.additionalCandidates.get(0);
			final int i2 = this.additionalCandidates.get(1);
			if (Sudoku2.getLine(i1) == Sudoku2.getLine(i2)) {
				step = this.checkUniqueness3(Sudoku2.LINE, Sudoku2.LINES[Sudoku2.getLine(i1)], u3Cands, urMask, searchType,
						onlyOne);
				if (step != null && onlyOne) {
					// if steps should be cached that was already done
					return step;
				}
			}
			if (Sudoku2.getCol(i1) == Sudoku2.getCol(i2)) {
				step = this.checkUniqueness3(Sudoku2.COL, Sudoku2.COLS[Sudoku2.getCol(i1)], u3Cands, urMask, searchType,
						onlyOne);
				if (step != null && onlyOne) {
					// if steps should be cached that was already done
					return step;
				}
			}
			if (Sudoku2.getBlock(i1) == Sudoku2.getBlock(i2)) {
				step = this.checkUniqueness3(Sudoku2.BLOCK, Sudoku2.BLOCKS[Sudoku2.getBlock(i1)], u3Cands, urMask, searchType,
						onlyOne);
				if (step != null && onlyOne) {
					// if steps should be cached that was already done
					return step;
				}
			}
		}

		// Uniqueness Test 4: Two cells with additional candidates; in all cells
		// seen by both cells one of the UR candidates is missing: the other UR
		// candidate can be eliminated from the cells with the additional candidates
		// the cells with additional candidates have to be in one row or one column
		if (twoSize == 2) {
			final int i1 = this.additionalCandidates.get(0);
			final int i2 = this.additionalCandidates.get(1);
			if ((Sudoku2.getLine(i1) == Sudoku2.getLine(i2)) || (Sudoku2.getCol(i1) == Sudoku2.getCol(i2))) {
				// get all cells that can see both cells with additional candidates
				this.tmpSet.setAnd(Sudoku2.buddies[i1], Sudoku2.buddies[i2]);
				// now check
				int delCand = -1;
				this.tmpSet1.setAnd(this.tmpSet, this.finder.getCandidates()[this.cand1]);
				if (this.tmpSet1.isEmpty()) {
					delCand = this.cand2;
				} else {
					this.tmpSet1.setAnd(this.tmpSet, this.finder.getCandidates()[this.cand2]);
					if (this.tmpSet1.isEmpty()) {
						delCand = this.cand1;
					}
				}
				if (delCand != -1) {
					this.initStep(SolutionType.UNIQUENESS_4);
					if (this.sudoku.isCandidate(i1, delCand)) {
						this.globalStep.addCandidateToDelete(i1, delCand);
					}
					if (this.sudoku.isCandidate(i2, delCand)) {
						this.globalStep.addCandidateToDelete(i2, delCand);
					}
					if (!this.globalStep.getCandidatesToDelete().isEmpty()) {
						step = (SolutionStep) this.globalStep.clone();
						if (onlyOne) {
							if (searchType == step.getType()) {
								return step;
							} else {
								this.cachedSteps.add(step);
							}
						} else {
							this.steps.add(step);
						}
					}
				}
			}
		}

		// Uniqueness Test 6: Two cells with additional candidates located
		// diagonally; if in both lines and cols none of the other candidates
		// contain
		// cand1 -> cand2 can be deleted from the diagonal cells
		if (twoSize == 2) {
			final int i1 = this.additionalCandidates.get(0);
			final int i2 = this.additionalCandidates.get(1);
			if ((Sudoku2.getLine(i1) != Sudoku2.getLine(i2)) && (Sudoku2.getCol(i1) != Sudoku2.getCol(i2))) {
				// get all cells in both lines and cols but without the UR itself
				this.tmpSet.set(Sudoku2.LINE_TEMPLATES[Sudoku2.getLine(i1)]);
				this.tmpSet.or(Sudoku2.COL_TEMPLATES[Sudoku2.getCol(i1)]);
				this.tmpSet.or(Sudoku2.LINE_TEMPLATES[Sudoku2.getLine(i2)]);
				this.tmpSet.or(Sudoku2.COL_TEMPLATES[Sudoku2.getCol(i2)]);
				this.tmpSet.andNot(this.additionalCandidates);
				this.tmpSet.andNot(this.twoCandidates);
				// now check for additional candidates
				int delCand = -1;
				this.tmpSet1.setAnd(this.tmpSet, this.finder.getCandidates()[this.cand1]);
				if (this.tmpSet1.isEmpty()) {
					delCand = this.cand1;
				} else {
					this.tmpSet1.setAnd(this.tmpSet, this.finder.getCandidates()[this.cand2]);
					if (this.tmpSet1.isEmpty()) {
						delCand = this.cand2;
					}
				}
				if (delCand != -1) {
					this.initStep(SolutionType.UNIQUENESS_6);
					if (this.sudoku.isCandidate(i1, delCand)) {
						this.globalStep.addCandidateToDelete(i1, delCand);
					}
					if (this.sudoku.isCandidate(i2, delCand)) {
						this.globalStep.addCandidateToDelete(i2, delCand);
					}
					if (this.globalStep.getCandidatesToDelete().isEmpty()) {
						step = (SolutionStep) this.globalStep.clone();
						if (onlyOne) {
							if (searchType == step.getType()) {
								return step;
							} else {
								this.cachedSteps.add(step);
							}
						} else {
							this.steps.add(step);
						}
					}
				}
			}
		}

		// Hidden Rectangle: If one or two cells contain only two candidates (if two
		// they have to be aligned diagonally) one of the cells with only two cands
		// is the corner; if the line and the col through the other three cells
		// contain only two instances of one of the uniqueness candidates each, the
		// other uniqueness candidate can be deleted
		if (twoSize == 2 || twoSize == 1) {
			final int i1 = this.twoCandidates.get(0);
			final int i2 = this.twoCandidates.get(1);
			boolean doCheck = true;
			if (twoSize == 2) {
				// must be aligned diagonally -> must not be in the same row or column
				if (Sudoku2.getLine(i1) == Sudoku2.getLine(i2) || Sudoku2.getCol(i1) == Sudoku2.getCol(i2)) {
					doCheck = false;
				}
			}
			if (doCheck) {
				step = this.checkHiddenRectangle(i1, searchType, onlyOne);
				if (step != null && onlyOne) {
					return step;
				}
				if (this.twoCandidates.size() == 2) {
					step = this.checkHiddenRectangle(i2, searchType, onlyOne);
					if (step != null && onlyOne) {
						return step;
					}
				}
			}
		}
		return null;
	}

	/**
	 * Avoidable Rectangle: If only one of cell21/cell22 is not set, cand1/cand2
	 * can be deleted from that cell. If both cell21 and cell22 are not set,
	 * cell21 must contain cand2, cell22 must contain cand1 and both cells have to
	 * have the same additional candidate. This candidate can be deleted from all
	 * cells that see both cell21 and cell22.
	 */
	private SolutionStep checkAvoidableRectangle(final int index21, final int index22, final SolutionType type,
			final boolean onlyOne) {
		SolutionStep step = null;
		if (this.sudoku.getValue(index21) != 0 || this.sudoku.getValue(index22) != 0) {
			// first type: cand1/cand2 can be deleted
			this.initStep(SolutionType.AVOIDABLE_RECTANGLE_1);
			if (this.sudoku.getValue(index21) != 0) {
				if (this.sudoku.isCandidate(index22, this.cand1)) {
					this.globalStep.addCandidateToDelete(index22, this.cand1);
				}
			} else {
				if (this.sudoku.isCandidate(index21, this.cand2)) {
					this.globalStep.addCandidateToDelete(index21, this.cand2);
				}
			}
			if (!this.globalStep.getCandidatesToDelete().isEmpty()) {
				step = (SolutionStep) this.globalStep.clone();
				if (onlyOne) {
					if (type == SolutionType.AVOIDABLE_RECTANGLE_1) {
						return step;
					} else {
						this.cachedSteps.add(step);
					}
				} else {
					this.steps.add(step);
				}
			}
		} else {
			// the additional candidate in index21 and index22 has to be the same
			final int[] cands = this.sudoku.getAllCandidates(index21);
			int additionalCand = cands[0];
			if (additionalCand == this.cand2) {
				additionalCand = cands[1];
			}
			if (!this.sudoku.isCandidate(index22, additionalCand)) {
				// wrong candidate -> do nothing
				return null;
			}
			// check for deletions
			this.tmpSet.set(Sudoku2.buddies[index21]);
			this.tmpSet.and(Sudoku2.buddies[index22]);
			this.tmpSet.and(this.finder.getCandidates()[additionalCand]);
			if (this.tmpSet.isEmpty()) {
				// no eliminations possible -> do nothing
				return null;
			}
			this.initStep(SolutionType.AVOIDABLE_RECTANGLE_2);
			for (int i = 0; i < this.tmpSet.size(); i++) {
				this.globalStep.addCandidateToDelete(this.tmpSet.get(i), additionalCand);
			}
			this.globalStep.addEndoFin(index21, additionalCand);
			this.globalStep.addEndoFin(index22, additionalCand);
			step = (SolutionStep) this.globalStep.clone();
			if (onlyOne) {
				if (type == SolutionType.AVOIDABLE_RECTANGLE_2) {
					return step;
				} else {
					this.cachedSteps.add(step);
				}
			} else {
				this.steps.add(step);
			}
		}
		return null;
	}

	/**
	 * Hidden Rectangle: If one or two cells contain only two candidates (if two
	 * they have to be aligned diagonally) one of the cells with only two cands is
	 * the corner; if the line and the col through the other three cells contain
	 * only two occurences of one of the uniqueness candidates each, the other
	 * uniqueness candidate can be deleted
	 */
	private SolutionStep checkHiddenRectangle(final int cornerIndex, final SolutionType type, final boolean onlyOne) {
		// whether there is only one cell or two cells with two candidates,
		// checking two additional cells is enough to get the line and col
		// that have to be checked
		final int lineC = Sudoku2.getLine(cornerIndex);
		final int colC = Sudoku2.getCol(cornerIndex);
		final int i1 = this.additionalCandidates.get(0);
		final int i2 = this.additionalCandidates.get(1);
		int line1 = Sudoku2.getLine(i1);
		if (line1 == lineC) {
			line1 = Sudoku2.getLine(i2);
		}
		int col1 = Sudoku2.getCol(i1);
		if (col1 == colC) {
			col1 = Sudoku2.getCol(i2);
		}

		SolutionStep step = this.checkCandForHiddenRectangle(line1, col1, this.cand1, this.cand2, type, onlyOne);
		if (step != null && onlyOne) {
			return step;
		}
		step = this.checkCandForHiddenRectangle(line1, col1, this.cand2, this.cand1, type, onlyOne);
		if (step != null && onlyOne) {
			return step;
		}
		return null;
	}

	/**
	 * In line <code>line</code> and col <code>col</code> the candidate
	 * <code>cand1</code> may appear only twice. If that is the case candidate
	 * <code>cand2</code> may be deleted from the cell at the intersection of
	 * <code>line</code> and <code>col</code>.<br>
	 * CAUTION: the condition "only twice" is invalid if a UR candidate is missing
	 * from the additional cell itself!
	 */
	private SolutionStep checkCandForHiddenRectangle(final int line, final int col, final int cand1, final int cand2,
			final SolutionType type, final boolean onlyOne) {
		this.tmpSet1.setOr(this.twoCandidates, this.additionalCandidates);
		this.tmpSet.set(this.finder.getCandidates()[cand1]);
		this.tmpSet.and(Sudoku2.LINE_TEMPLATES[line]);
		this.tmpSet.andNot(this.tmpSet1);
		if (!this.tmpSet.isEmpty()) {
			return null;
		}
		this.tmpSet.set(this.finder.getCandidates()[cand1]);
		this.tmpSet.and(Sudoku2.COL_TEMPLATES[col]);
		this.tmpSet.andNot(this.tmpSet1);
		if (!this.tmpSet.isEmpty()) {
			return null;
		}
		// ok ->hidden rectangle; delete cand2 from cell at the intersection
		final int delIndex = Sudoku2.getIndex(line, col);

		this.initStep(SolutionType.HIDDEN_RECTANGLE);
		if (this.sudoku.isCandidate(delIndex, cand2)) {
			this.globalStep.addCandidateToDelete(delIndex, cand2);
		}
		if (!this.globalStep.getCandidatesToDelete().isEmpty()) {
			final SolutionStep step = (SolutionStep) this.globalStep.clone();
			if (onlyOne) {
				if (type == step.getType()) {
					return step;
				} else {
					this.cachedSteps.add(step);
				}
			} else {
				this.steps.add(step);
			}
		}
		return null;
	}

	/**
	 * Collect all cells that have to be checked and call the recursive check
	 * method.
	 */
	private SolutionStep checkUniqueness3(final int unitType, final int[] unit, final short u3Cands, final short urMask,
			final SolutionType searchType, final boolean onlyOne) {
		final SudokuSet u3Indices = new SudokuSet();
		this.tmpSet.set(this.twoCandidates);
		this.tmpSet.or(this.additionalCandidates);
		for (int i = 0; i < unit.length; i++) {
			// a cell has to be checked, if it is not set, not part of the UR without
			// additional candidates and doesnt contain cand1 or cand2
			final short cell = this.sudoku.getCell(unit[i]);
			if (cell != 0 && (cell & urMask) == 0 && !this.tmpSet.contains(unit[i])) {
				u3Indices.add(unit[i]);
			}
		}
		// now check all combinations: the additional cells have to
		// be in the set always
		if (!u3Indices.isEmpty()) {
			final SolutionStep step = this.checkUniqueness3Recursive(unitType, unit, u3Indices, u3Cands,
					new SudokuSet(this.additionalCandidates), 0, searchType, onlyOne);
			if (step != null && onlyOne) {
				return step;
			}
		}
		return null;
	}

	/**
	 * Do the recursive check for UR 3.
	 */
	private SolutionStep checkUniqueness3Recursive(final int type, final int[] unit, final SudokuSet u3Indices,
			final short candsIncluded, final SudokuSet indicesIncluded, final int startIndex, final SolutionType searchType,
			final boolean onlyOne) {
		SolutionStep step = null;
		for (int i = startIndex; i < u3Indices.size(); i++) {
			short aktCands = candsIncluded;
			final SudokuSet aktIndices = indicesIncluded.clone();
			aktIndices.add(u3Indices.get(i));
			// collect all additional candidates
			aktCands |= this.sudoku.getCell(u3Indices.get(i));
			// if we search for blocks, a check for deletable candidates is only done,
			// if the cells are not all in the same line or column (in that case the
			// step has already been checked)
			if (type != Sudoku2.BLOCK || !this.isSameLineOrCol(aktIndices)) {
				// if the number of additional candidates is one smaller as the number
				// of cells
				// in aktIndices, it is a UR 3 -> check if candidates can be deleted
				if (Sudoku2.ANZ_VALUES[aktCands] == (aktIndices.size() - 1)) {
					// candidates can be deleted in all cells of the same unit, which are
					// not contained in aktIndices (that includes the UR candidates). All
					// candidates belonging to the Naked Subset are written as fins (for
					// display only)
					this.initStep(SolutionType.UNIQUENESS_3);
					for (int j = 0; j < unit.length; j++) {
						if (this.sudoku.getValue(unit[j]) == 0 && !aktIndices.contains(unit[j])) {
							final short delCands = (short) (this.sudoku.getCell(unit[j]) & aktCands);
							if (Sudoku2.ANZ_VALUES[delCands] == 0) {
								// no candidates to delete
								continue;
							}
							final int[] delCandsArray = Sudoku2.POSSIBLE_VALUES[delCands];
							for (int k = 0; k < delCandsArray.length; k++) {
								this.globalStep.addCandidateToDelete(unit[j], delCandsArray[k]);
							}
						}
					}
					// do we have a step?
					if (!this.globalStep.getCandidatesToDelete().isEmpty()) {
						// write the fins
						final int[] aktCandsArray = Sudoku2.POSSIBLE_VALUES[aktCands];
						for (int k = 0; k < aktCandsArray.length; k++) {
							final int cTmp = aktCandsArray[k];
							for (int l = 0; l < aktIndices.size(); l++) {
								if (this.sudoku.isCandidate(aktIndices.get(l), cTmp)) {
									this.globalStep.addFin(aktIndices.get(l), cTmp);
								}
							}
						}
						if (type == Sudoku2.LINE || type == Sudoku2.COL) {
							// could be Locked Subset
							final int block = this.getBlockForCheck3(aktIndices);
							if (block != -1) {
								final int[] unit1 = Sudoku2.BLOCKS[block];
								for (int j = 0; j < unit1.length; j++) {
									if (this.sudoku.getValue(unit1[j]) == 0 && !aktIndices.contains(unit1[j])) {
										final short delCands = (short) (this.sudoku.getCell(unit1[j]) & aktCands);
										if (Sudoku2.ANZ_VALUES[delCands] == 0) {
											// no candidates to delete
											continue;
										}
										final int[] delCandsArray = Sudoku2.POSSIBLE_VALUES[delCands];
										for (int k = 0; k < delCandsArray.length; k++) {
											this.globalStep.addCandidateToDelete(unit1[j], delCandsArray[k]);
										}
									}
								}
							}
						}
						step = (SolutionStep) this.globalStep.clone();
						if (onlyOne) {
							if (searchType == step.getType()) {
								return step;
							} else {
								this.cachedSteps.add(step);
							}
						} else {
							this.steps.add(step);
						}
					}
				}
			}
			// and on to the next level
			step = this.checkUniqueness3Recursive(type, unit, u3Indices, aktCands, aktIndices, i + 1, searchType, onlyOne);
			if (step != null && onlyOne) {
				return step;
			}
		}
		return null;
	}

	/**
	 * If all cells in <code>aktIndices</code> belong to the same block, return
	 * that block (for UR3 check)
	 */
	private int getBlockForCheck3(final SudokuSet aktIndices) {
		if (aktIndices.isEmpty()) {
			return -1;
		}
		final int block = Sudoku2.getBlock(aktIndices.get(0));
		for (int i = 1; i < aktIndices.size(); i++) {
			if (Sudoku2.getBlock(aktIndices.get(i)) != block) {
				return -1;
			}
		}
		return block;
	}

	/**
	 * Checks, if all indices in <code>aktIndices</code> are in the same line or
	 * column (for UR check).
	 */
	private boolean isSameLineOrCol(final SudokuSet aktIndices) {
		if (aktIndices.isEmpty()) {
			return false;
		}
		boolean sameLine = true;
		boolean sameCol = true;
		final int line = Sudoku2.getLine(aktIndices.get(0));
		final int col = Sudoku2.getCol(aktIndices.get(0));
		for (int i = 1; i < aktIndices.size(); i++) {
			if (Sudoku2.getLine(aktIndices.get(i)) != line) {
				sameLine = false;
			}
			if (Sudoku2.getCol(aktIndices.get(i)) != col) {
				sameCol = false;
			}
		}
		return sameLine || sameCol;
	}

	/**
	 * Initialize {@link #globalStep} for a Unique Rectangle.
	 */
	private void initStep(final SolutionType type) {
		this.globalStep.reset();
		this.globalStep.setType(type);
		this.globalStep.addValue(this.cand1);
		this.globalStep.addValue(this.cand2);
		this.globalStep.addIndex(this.indexe[0]);
		this.globalStep.addIndex(this.indexe[1]);
		this.globalStep.addIndex(this.indexe[2]);
		this.globalStep.addIndex(this.indexe[3]);
	}

	/**
	 * Get all cells that hold only {@link #cand1} and {@link #cand2} (or possibly
	 * only one of them). Collect all additional candidates in
	 * {@link #additionalCandidates}.
	 */
	private void initCheck(final int[] indices) {
		this.twoCandidates.clear();
		this.additionalCandidates.clear();
		final short mask = (short) ~(Sudoku2.MASKS[this.cand1] | Sudoku2.MASKS[this.cand2]);
		for (int i = 0; i < indices.length; i++) {
			final short addTemp = (short) (this.sudoku.getCell(indices[i]) & mask);
			if (addTemp == 0) {
				this.twoCandidates.add(indices[i]);
			} else {
				this.additionalCandidates.add(indices[i]);
			}
		}
	}

	/**
	 * Checks if the UR formed by the four indices is already contained in
	 * {@link #rectangles}. If the buffer is full, the UR is treated as if it were
	 * not already handled.
	 */
	private boolean checkRect(final int i11, final int i12, final int i21, final int i22) {
		this.tmpRect[0] = i11;
		this.tmpRect[1] = i12;
		this.tmpRect[2] = i21;
		this.tmpRect[3] = i22;
		// sort the indices (BubbleSort is sufficient for 4 indices only)
		for (int i = this.tmpRect.length; i > 1; i--) {
			boolean changed = false;
			for (int j = 1; j < i; j++) {
				if (this.tmpRect[j - 1] > this.tmpRect[j]) {
					final int tmp = this.tmpRect[j - 1];
					this.tmpRect[j - 1] = this.tmpRect[j];
					this.tmpRect[j] = tmp;
					changed = true;
				}
			}
			if (!changed) {
				break;
			}
		}
		// build the new rectangle number
		final int rect = (((this.tmpRect[0] * 10) + this.tmpRect[1]) * 10 + this.tmpRect[2]) * 10 + this.tmpRect[3];
		// new search for it in rectangles
		for (int i = 0; i < this.rectAnz; i++) {
			if (this.rectangles[i] == rect) {
				// already contained in rectangles -> don't check anymore
				return false;
			}
		}
		// a new UR -> put it in rectangles if there is any space left
		if (this.rectAnz < this.rectangles.length) {
			this.rectangles[this.rectAnz++] = rect;
		}
		// check it
		return true;
	}

}
