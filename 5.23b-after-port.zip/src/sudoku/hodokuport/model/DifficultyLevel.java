/*
 * Copyright (C) 2008-12  Bernhard Hobiger
 *
 * This file is part of HoDoKu.
 *
 * HoDoKu is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * HoDoKu is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with HoDoKu. If not, see <http://www.gnu.org/licenses/>.
 */

package sudoku.hodokuport.model;

import java.awt.Color;

public final class DifficultyLevel {
	private DifficultyType type;
	private int ordinal;
	private int maxScore;
	private String name;
	private Color backgroundColor;
	private Color foregroundColor;

	public DifficultyLevel() {
		// Nothing to do.
	}

	public DifficultyLevel(final DifficultyType type, final int maxScore, final String name, final Color backgroundColor,
			final Color foregroundColor) {
		this.setType(type);
		this.setMaxScore(maxScore);
		this.setName(name);
		this.setBackgroundColor(backgroundColor);
		this.setForegroundColor(foregroundColor);
	}

	public int getMaxScore() {
		return this.maxScore;
	}

	public String getName() {
		return this.name;
	}

	public Color getBackgroundColor() {
		return this.backgroundColor;
	}

	public Color getForegroundColor() {
		return this.foregroundColor;
	}

	public void setMaxScore(final int maxScore) {
		this.maxScore = maxScore;
	}

	public void setName(final String name) {
		this.name = name;
	}

	public void setBackgroundColor(final Color backgroundColor) {
		this.backgroundColor = backgroundColor;
	}

	public void setForegroundColor(final Color foregroundColor) {
		this.foregroundColor = foregroundColor;
	}

	public DifficultyType getType() {
		return this.type;
	}

	public void setType(final DifficultyType type) {
		this.type = type;
		this.ordinal = type.ordinal();
	}

	public int getOrdinal() {
		return this.ordinal;
	}

	public void setOrdinal(final int ordinal) {
		this.ordinal = ordinal;
	}
}
