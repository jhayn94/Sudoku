/*
 * Copyright (C) 2008-12  Bernhard Hobiger
 *
 * This file is part of HoDoKu.
 *
 * HoDoKu is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * HoDoKu is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with HoDoKu. If not, see <http://www.gnu.org/licenses/>.
 */

package sudoku.hodokuport.model;

public class Candidate implements Cloneable, Comparable<Candidate> {
	private int value;
	private int index;

	public Candidate() {

	}

	public Candidate(final int index, final int value) {
		this.index = index;
		this.value = value;
	}

	@Override
	public int compareTo(final Candidate o) {
		int ret = this.value - o.value;
		if (ret == 0) {
			ret = this.index - o.index;
		}
		return ret;
	}

	@Override
	public boolean equals(final Object o) {
		if (o == null) {
			return false;
		}
		if (!(o instanceof Candidate)) {
			return false;
		}
		final Candidate c = (Candidate) o;
		if (this.index == c.index && this.value == c.value) {
			return true;
		}
		return false;
	}

	@Override
	public int hashCode() {
		int hash = 7;
		hash = 29 * hash + this.value;
		hash = 29 * hash + this.index;
		return hash;
	}

	public int getValue() {
		return this.value;
	}

	public void setValue(final int value) {
		this.value = value;
	}

	public int getIndex() {
		return this.index;
	}

	public void setIndex(final int index) {
		this.index = index;
	}

	@Override
	public String toString() {
		return this.index + "/" + this.value;
	}
}
