/*
 * Copyright (C) 2008-12  Bernhard Hobiger
 *
 * This file is part of HoDoKu.
 *
 * HoDoKu is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * HoDoKu is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with HoDoKu. If not, see <http://www.gnu.org/licenses/>.
 */
package sudoku.hodokuport.model;

import java.util.Arrays;
import java.util.SortedSet;
import java.util.TreeSet;
import java.util.logging.Level;
import java.util.logging.Logger;

import sudoku.hodokuport.generator.SudokuGenerator;
import sudoku.hodokuport.generator.SudokuGeneratorFactory;
import sudoku.model.SudokuSet;
import sudoku.model.SudokuSetBase;

public class Sudoku2 implements Cloneable {

	private static final String NON_GIVEN_CELL = "0";

	public static final int LENGTH = 81;
	/** Number of units in each constraint */
	public static final int UNITS = 9;

	/** The internal number for block units. */
	public static final int BLOCK = 0;
	/** The internal number for line units. */
	public static final int LINE = 1;
	/** The internal number for column units. */
	public static final int COL = 2;
	/** The internal number for cell units. */
	public static final int CELL = 3;

	/** All indices for every line */
	public static final int[][] LINES = { { 0, 1, 2, 3, 4, 5, 6, 7, 8 }, { 9, 10, 11, 12, 13, 14, 15, 16, 17 },
			{ 18, 19, 20, 21, 22, 23, 24, 25, 26 }, { 27, 28, 29, 30, 31, 32, 33, 34, 35 },
			{ 36, 37, 38, 39, 40, 41, 42, 43, 44 }, { 45, 46, 47, 48, 49, 50, 51, 52, 53 },
			{ 54, 55, 56, 57, 58, 59, 60, 61, 62 }, { 63, 64, 65, 66, 67, 68, 69, 70, 71 },
			{ 72, 73, 74, 75, 76, 77, 78, 79, 80 } };
	/** All indices for every column */
	public static final int[][] COLS = { { 0, 9, 18, 27, 36, 45, 54, 63, 72 }, { 1, 10, 19, 28, 37, 46, 55, 64, 73 },
			{ 2, 11, 20, 29, 38, 47, 56, 65, 74 }, { 3, 12, 21, 30, 39, 48, 57, 66, 75 },
			{ 4, 13, 22, 31, 40, 49, 58, 67, 76 }, { 5, 14, 23, 32, 41, 50, 59, 68, 77 },
			{ 6, 15, 24, 33, 42, 51, 60, 69, 78 }, { 7, 16, 25, 34, 43, 52, 61, 70, 79 },
			{ 8, 17, 26, 35, 44, 53, 62, 71, 80 } };
	/** All indices for every block */
	public static final int[][] BLOCKS = { { 0, 1, 2, 9, 10, 11, 18, 19, 20 }, { 3, 4, 5, 12, 13, 14, 21, 22, 23 },
			{ 6, 7, 8, 15, 16, 17, 24, 25, 26 }, { 27, 28, 29, 36, 37, 38, 45, 46, 47 },
			{ 30, 31, 32, 39, 40, 41, 48, 49, 50 }, { 33, 34, 35, 42, 43, 44, 51, 52, 53 },
			{ 54, 55, 56, 63, 64, 65, 72, 73, 74 }, { 57, 58, 59, 66, 67, 68, 75, 76, 77 },
			{ 60, 61, 62, 69, 70, 71, 78, 79, 80 } };
	/** All indices for all constraints: first lines, then cols, then blocks */
	public static final int[][] ALL_UNITS = { LINES[0], LINES[1], LINES[2], LINES[3], LINES[4], LINES[5], LINES[6],
			LINES[7], LINES[8], COLS[0], COLS[1], COLS[2], COLS[3], COLS[4], COLS[5], COLS[6], COLS[7], COLS[8], BLOCKS[0],
			BLOCKS[1], BLOCKS[2], BLOCKS[3], BLOCKS[4], BLOCKS[5], BLOCKS[6], BLOCKS[7], BLOCKS[8] };
	/** All indices for lines and blocks (fish search) */
	public static final int[][] LINE_BLOCK_UNITS = { LINES[0], LINES[1], LINES[2], LINES[3], LINES[4], LINES[5], LINES[6],
			LINES[7], LINES[8], BLOCKS[0], BLOCKS[1], BLOCKS[2], BLOCKS[3], BLOCKS[4], BLOCKS[5], BLOCKS[6], BLOCKS[7],
			BLOCKS[8] };
	/** All indices for columns and blocks (fish search) */
	public static final int[][] COL_BLOCK_UNITS = { COLS[0], COLS[1], COLS[2], COLS[3], COLS[4], COLS[5], COLS[6],
			COLS[7], COLS[8], BLOCKS[0], BLOCKS[1], BLOCKS[2], BLOCKS[3], BLOCKS[4], BLOCKS[5], BLOCKS[6], BLOCKS[7],
			BLOCKS[8] };
	/** The index in {@link #BLOCKS} for every cell (speeds up lookup) */
	private static final int[] BLOCK_FROM_INDEX = { 0, 0, 0, 1, 1, 1, 2, 2, 2, 0, 0, 0, 1, 1, 1, 2, 2, 2, 0, 0, 0, 1, 1,
			1, 2, 2, 2, 3, 3, 3, 4, 4, 4, 5, 5, 5, 3, 3, 3, 4, 4, 4, 5, 5, 5, 3, 3, 3, 4, 4, 4, 5, 5, 5, 6, 6, 6, 7, 7, 7, 8,
			8, 8, 6, 6, 6, 7, 7, 7, 8, 8, 8, 6, 6, 6, 7, 7, 7, 8, 8, 8 };
	/** The internal Unit for every constraint */
	public static final int[] CONSTRAINT_TYPE_FROM_CONSTRAINT = { LINE, LINE, LINE, LINE, LINE, LINE, LINE, LINE, LINE,
			COL, COL, COL, COL, COL, COL, COL, COL, COL, BLOCK, BLOCK, BLOCK, BLOCK, BLOCK, BLOCK, BLOCK, BLOCK, BLOCK };
	/** The internal unit number for every constraint */
	public static final int[] CONSTRAINT_NUMBER_FROM_CONSTRAINT = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 1, 2, 3, 4, 5, 6, 7, 8, 9,
			1, 2, 3, 4, 5, 6, 7, 8, 9 };
	// Sets for units
	// Helper arrays for candidates
	/** All possible masks for the digits 1 to 9. */
	public static final short[] MASKS = { 0x0000, 0x0001, 0x0002, 0x0004, 0x0008, 0x0010, 0x0020, 0x0040, 0x0080,
			0x0100 };
	/** Mask for "all digits set" */
	public static final short MAX_MASK = 0x01ff;
	/**
	 * for each of the 256 possible bit combinations the matching array (for
	 * iteration)
	 */
	public static final int[][] POSSIBLE_VALUES = new int[0x200][];
	/**
	 * The length of the array in {@link #POSSIBLE_VALUES} for each bit
	 * combination.
	 */
	public static final int[] ANZ_VALUES = new int[0x200];
	/** The indices of the constraints for every cell (LINE, COL, BLOCK) */
	public static int[][] CONSTRAINTS = new int[LENGTH][3];
	/**
	 * The candidate represented by the least significant bit that is set in a
	 * candidate mask. If only one bit is set, the array contains the value of
	 * that bit (candidate).
	 */
	public static final short[] CAND_FROM_MASK = new short[0x200];

	/**
	 * One template for every possible combination of 9 equal digits in the grid.
	 */
	public static SudokuSetBase[] templates = new SudokuSetBase[46656];
	/** One bitmap with all buddies of each cell */
	public static SudokuSet[] buddies = new SudokuSet[LENGTH];
	/** The low order long from {@link #buddies} */
	public static long[] buddiesM1 = new long[LENGTH];
	/** The high order long from {@link #buddies} */
	public static long[] buddiesM2 = new long[LENGTH];
	/**
	 * For every group of 8 cells (denoted by a byte in a SudokuSetBase) all
	 * possible buddies
	 */
	public static SudokuSetBase[][] groupedBuddies = new SudokuSetBase[11][256];
	/** The low order long from {@link #groupedBuddies} */
	public static long[][] groupedBuddiesM1 = new long[11][256];
	/** The high order long from {@link #groupedBuddies} */
	public static long[][] groupedBuddiesM2 = new long[11][256];
	/** One bitmap with all cells of each line */
	public static SudokuSet[] LINE_TEMPLATES = new SudokuSet[LINES.length];
	/** One bitmap with all cells of each column */
	public static SudokuSet[] COL_TEMPLATES = new SudokuSet[COLS.length];
	/** One bitmap with all cells of each block */
	public static SudokuSet[] BLOCK_TEMPLATES = new SudokuSet[BLOCKS.length];
	/** One bitmap with all cells of each line and each block */
	public static SudokuSet[] LINE_BLOCK_TEMPLATES = new SudokuSet[LINE_BLOCK_UNITS.length];
	/** One bitmap with all cells of each column and each block */
	public static SudokuSet[] COL_BLOCK_TEMPLATES = new SudokuSet[COL_BLOCK_UNITS.length];
	/** One bitmap with all cells of each constraint */
	public static SudokuSet[] ALL_CONSTRAINTS_TEMPLATES = new SudokuSet[ALL_UNITS.length];
	/** The low order long from {@link #ALL_CONSTRAINTS_TEMPLATES} */
	public static long[] ALL_CONSTRAINTS_TEMPLATES_M1 = new long[ALL_UNITS.length];
	/** The high order long from {@link #ALL_CONSTRAINTS_TEMPLATES} */
	public static long[] ALL_CONSTRAINTS_TEMPLATES_M2 = new long[ALL_UNITS.length];

	/** Candidate bitmaps for all cells. 0 stands for "cell already set". */
	private short[] cells = new short[LENGTH];
	/**
	 * Bitmaps for candidates set by the user if "show all candidates" is not set.
	 */
	private short[] userCells = new short[LENGTH];
	/**
	 * Number of free cells per constraint and per candidate (CAUTION: candidates
	 * go from 1 to 9). Used to detect Hidden Singles easily
	 */
	private byte[][] free = new byte[ALL_UNITS.length][UNITS + 1];
	/** number of unfilled cells in the grid */
	private int unsolvedCellsAnz;
	/**
	 * The values of the cells (0 means cell not set); if a cell is set, the
	 * corresponding entry in {@link #cells} is deleted
	 */
	private int[] values = new int[LENGTH];
	/** Determines if cell is a given */
	private boolean[] fixed = new boolean[LENGTH];
	/** The correct values of the solution */
	private int[] solution = new int[LENGTH];
	/** Indicates if solution has been set! */
	private boolean solutionSet = false;
	/** The difficulty level of this puzzle */
	private DifficultyLevel level = null;
	/** The difficulty score of this puzzle */
	private int score;
	/** the state in which this Sudoku was loaded (for "Reset Puzzle") */
	private String initialState = null;
	/** the state of the sudoku (for progress display) */
	private SudokuStatus status = SudokuStatus.EMPTY;
	/** the state of the sudoku if only the givens are taken into account */
	private SudokuStatus statusGivens = SudokuStatus.EMPTY;

	// Queues for detecting Singles: Naked Singles and Hidden Singles become
	// obvious
	// while setting/deleting candidates; two synchronized arrays contain
	// index/value pairs
	/** A queue for newly detected Naked Singles */
	private SudokuSinglesQueue nsQueue = new SudokuSinglesQueue();
	/** A queue for newly detected Hidden Singles */
	private SudokuSinglesQueue hsQueue = new SudokuSinglesQueue();

	static {
		initBuddies();

		initTemplates();

		initGroupedBuddies();

		// initialize POSSIBLE_VALUES
		POSSIBLE_VALUES[0] = new int[0];
		ANZ_VALUES[0] = 0;
		final int[] temp = new int[9];
		for (int i = 1; i <= 0x1ff; i++) {
			int index = 0;
			int mask = 1;
			for (int j = 1; j <= 0x1ff; j++) {
				if ((i & mask) != 0) {
					temp[index++] = j;
				}
				mask <<= 1;
			}
			POSSIBLE_VALUES[i] = new int[index];
			System.arraycopy(temp, 0, POSSIBLE_VALUES[i], 0, index);
			ANZ_VALUES[i] = index;
		}

		// initialize the constraints table
		// lookup tables for constraints: three constraints for every cell
		// lines go from 0 .. 8
		// cols go from 9 .. 17
		// boxes from 18 .. 26
		int index = 0;
		// one loop for every line
		for (int line = 0; line < 9; line++) {
			// base box index for line index
			final int boxBase = 2 * 9 + ((line / 3) * 3);
			// one loop for every column in line index
			for (int col = 9; col < 2 * 9; col++) {
				CONSTRAINTS[index][0] = line;
				CONSTRAINTS[index][1] = col;
				CONSTRAINTS[index][2] = boxBase + ((col / 3) % 3);
				index++;
			}
		}

		// initialize CAND_FROM_MASK
		// CAND_FROM_MASK: The candidate represented by the least siginificant bit
		// that is set in a candidate mask
		for (int i = 1; i < CAND_FROM_MASK.length; i++) {
			short j = -1;
			while ((i & MASKS[++j]) == 0)
				;
			CAND_FROM_MASK[i] = j;
		}
	}

	/**
	 * Creates a new instance of Sudoku2.<br>
	 * All bitmaps are initialized with all bits set (in every cell every
	 * candidate is allowed)
	 */
	public Sudoku2() {
		this.clearSudoku();
	}

	/**
	 * Clones a Sudoku. Makes a valid deep copy.
	 */
	@Override
	public Sudoku2 clone() {
		Sudoku2 newSudoku = null;
		try {
			newSudoku = (Sudoku2) super.clone();
			newSudoku.cells = this.cells.clone();
			newSudoku.userCells = this.userCells.clone();
			newSudoku.values = this.values.clone();
			newSudoku.solution = this.solution.clone();
			newSudoku.fixed = this.fixed.clone();
			newSudoku.free = new byte[this.free.length][];
			for (int i = 0; i < this.free.length; i++) {
				newSudoku.free[i] = this.free[i].clone();
			}
			if (this.initialState != null) {
				// no copy needed, is immutable!
				newSudoku.initialState = this.initialState;
			}
			newSudoku.nsQueue = this.nsQueue.clone();
			newSudoku.hsQueue = this.hsQueue.clone();
			// no deep copy required for level, it is constant
		} catch (final CloneNotSupportedException ex) {
			Logger.getLogger(this.getClass().getName()).log(Level.SEVERE, "Error while cloning", ex);
		}
		return newSudoku;
	}

	/**
	 * Sets a Sudoku with the values from <code>src</code>.
	 */
	public void set(final Sudoku2 src) {
		System.arraycopy(src.cells, 0, this.cells, 0, LENGTH);
		System.arraycopy(src.userCells, 0, this.userCells, 0, LENGTH);
		System.arraycopy(src.values, 0, this.values, 0, LENGTH);
		System.arraycopy(src.solution, 0, this.solution, 0, LENGTH);
		System.arraycopy(src.fixed, 0, this.fixed, 0, LENGTH);
		for (int i = 0; i < this.free.length; i++) {
			System.arraycopy(src.free[i], 0, this.free[i], 0, UNITS + 1);
		}
		this.unsolvedCellsAnz = src.unsolvedCellsAnz;
		this.solutionSet = src.solutionSet;
		this.score = src.score;
		this.level = src.level;
		if (src.initialState != null) {
			this.initialState = src.initialState;
		}
		this.status = src.status;
		this.statusGivens = src.statusGivens;
		this.nsQueue.set(src.nsQueue);
		this.hsQueue.set(src.hsQueue);
	}

	/**
	 * A simplified version of {@link #set(sudoku.Sudoku2)} that doesnt set all
	 * fields. Must only be used by the BacktrackingSolver!
	 *
	 * @param src
	 */
	public void setBS(final Sudoku2 src) {
		this.cells = Arrays.copyOf(src.cells, this.cells.length);
		this.values = Arrays.copyOf(src.values, this.values.length);
		for (int i = 0; i < this.free.length; i++) {
			this.free[i] = Arrays.copyOf(src.free[i], this.free[i].length);
		}
		this.unsolvedCellsAnz = src.unsolvedCellsAnz;
		this.nsQueue.clear();
		this.hsQueue.clear();
	}

	/**
	 * Initialize the data structure to an empty grid (no values set, in all cells
	 * all candidates are possible), the queues are deleted.
	 */
	public final void clearSudoku() {
		for (int i = 0; i < this.cells.length; i++) {
			this.cells[i] = MAX_MASK;
			this.userCells[i] = 0;
		}
		for (int i = 0; i < this.free.length; i++) {
			for (int j = 1; j < this.free[i].length; j++) {
				this.free[i][j] = 9;
			}
		}
		for (int i = 0; i < this.values.length; i++) {
			this.values[i] = 0;
			this.solution[i] = 0;
			this.fixed[i] = false;
		}
		this.unsolvedCellsAnz = LENGTH;
		this.initialState = null;
		this.solutionSet = false;
		this.status = SudokuStatus.EMPTY;
		this.statusGivens = SudokuStatus.EMPTY;
		this.nsQueue.clear();
		this.hsQueue.clear();
	}

	/**
	 * Reset the Sudoku to its initial state as stored in {@link #initialState}.
	 */
	public void resetSudoku() {
		if (this.initialState != null) {
			this.setSudoku(this.initialState, true);
		}
	}

	/**
	 * Loads the Sudoku from a string. Delegates to
	 * {@link #setSudoku(java.lang.String, boolean) }.
	 */
	public void setSudoku(final String init) {
		this.setSudoku(init, true);
	}

	/**
	 * Loads a Sudoku from a String. Possible formats:
	 * <ul>
	 * <li>81 character string with givens (line may contain comments started with
	 * '#')</li>
	 * <li>One line from gsf's q1 taxonomy</li>
	 * <li>A PM grid (may contain markups)</li>
	 * <li>A combination of givens + PM grid (Simple Sudoku)</li>
	 * <li>The HoDoKu library format</li>
	 * </ul>
	 */
	public void setSudoku(final String init, final boolean saveInitialState) {
		this.clearSudoku();
		if (init == null) {
			return;
		}

		//
		// Possible formats: ...1.32.4..1.
		//
		// 0001032040010
		//
		// +-------+-------+-------+
		// | . . . | . . . | . . . | ('0' allowed)
		// | 2 4 . | 3 5 . | . . . | ('0' allowed)
		// | . . . | . . . | . . . | ('0' allowed)
		// +-------+-------+-------+
		// | . . . | . 7 . | 3 . 1 |
		// | . . . | . . . | . . . |
		// | . . . | . . . | . . . |
		// +-------+-------+-------+
		// | . . . | . . . | . . . |
		// | . . . | . . . | . . . |
		// | . . . | . . . | . . . |
		// +-------+-------+-------+
		//
		// *-----------------------------------------------------------*
		// | 6 19 2 | 3 19 5 | 4 8 7 |
		// | 578 19 4 | 28 67 1679 | 3 159 1259 |
		// | 578 3 57 | 28 4 179 | 19 6 1259 |
		// |-------------------+-------------------+-------------------|
		// | 3 *678 568 |*17 2 179 | 1679 159 4 |
		// | 57 4 1 | 6 379 8 | 2 3579 359 |
		// | 9 2 67 | 4 5 137 | 167 137 8 |
		// |-------------------+-------------------+-------------------|
		// | 2 5 #367 |*17 8 1367 | 179 4 139 |
		// | 4 *67 9 | 5 1367 2 | 8 137 13 |
		// | 1 *78 378 | 9 37 4 | 5 2 6 |
		// *-----------------------------------------------------------*
		//
		// CAUTION: When importing a PM grid, a single value in a cell could be a
		// Naked Single.
		// Solution: If one of the houses of a single candidate contains that
		// candidate in another
		// cell, that candidate is treated as Naked Single; if not, the cell is set
		//
		// Special case SimpleSudoku: SS exports puzzles in two formats:
		// - givens + pm
		// - givens + set cells + pm
		//
		// example for type 2:
		// *-----------*
		// |8..|4..|...|
		// |.65|...|.42|
		// |9..|.8.|1.6|
		// |---+---+---|
		// |7..|.65|..8|
		// |...|...|...|
		// |2..|94.|..5|
		// |---+---+---|
		// |5.9|.2.|..7|
		// |47.|...|29.|
		// |...|..1|..4|
		// *-----------*
		//
		//
		// *-----------*
		// |8..|4..|...|
		// |.65|.7.|.42|
		// |9..|.8.|1.6|
		// |---+---+---|
		// |7..|.65|..8|
		// |...|...|...|
		// |2..|94.|..5|
		// |---+---+---|
		// |5.9|.24|..7|
		// |47.|...|29.|
		// |...|791|..4|
		// *-----------*
		//
		//
		// *-----------------------------------------------------------------------------*
		// | 8 123 1237 | 4 135 2369 | 3579 357 39 |
		// | 13 6 5 | 13 7 39 | 89 4 2 |
		// | 9 234 2347 | 235 8 23 | 1 357 6 |
		// |-------------------------+-------------------------+-------------------------|
		// | 7 1349 134 | 123 6 5 | 349 123 8 |
		// | 136 134589 13468 | 1238 13 2378 | 34679 12367 139 |
		// | 2 138 1368 | 9 4 378 | 367 1367 5 |
		// |-------------------------+-------------------------+-------------------------|
		// | 5 138 9 | 368 2 4 | 368 1368 7 |
		// | 4 7 1368 | 3568 35 368 | 2 9 13 |
		// | 36 238 2368 | 7 9 1 | 3568 3568 4 |
		// *-----------------------------------------------------------------------------*

		// Split input in lines, identify border lines (SudoCue uses '.' in borders,
		// gives an error) and erase markup characters
		// a line counts as border line, if it contains at least one occurence of
		// "---"
		String lineEnd = null;
		final int[][] cands = new int[9][9];
		if (init.contains("\r\n")) {
			lineEnd = "\r\n";
		} else if (init.contains("\r")) {
			lineEnd = "\r";
		} else if (init.contains("\n")) {
			lineEnd = "\n";
		}
		String[] lines = null;
		if (lineEnd != null) {
			lines = init.split(lineEnd);
		} else {
			lines = new String[1];
			lines[0] = init;
		}
		int anzLines = lines.length;

		// Check for library format: a one liner with 6 or 7 ":"
		boolean libraryFormat = false;
		String libraryCandStr = null;
		if (anzLines == 1) {
			final int anzDoppelpunkt = this.getAnzPatternInString(init, ":");
			if (anzDoppelpunkt == 6 || anzDoppelpunkt == 7) {
				libraryFormat = true;
				final String[] libLines = init.split(":");
				lines[0] = libLines[3];
				if (libLines.length >= 5) {
					libraryCandStr = libLines[4];
				} else {
					libraryCandStr = "";
				}
			}
		}

		// many formats append additional info after a '#', but are one liners ->
		// check
		if (anzLines == 1) {
			if (lines[0].contains("#")) {
				final String tmpStr = lines[0].substring(0, lines[0].indexOf("#")).trim();
				if (tmpStr.length() >= 81) {
					// was comment at end of line
					lines[0] = tmpStr;
				}
			}
		}

		// gsf's q2-taxonomy: more than 6 ',' in one line
		if (anzLines == 1) {
			if (this.getAnzPatternInString(init, ",") >= 6) {
				final String[] gsfLines = init.split(",");
				lines[0] = gsfLines[4];
			}
		}

		// In the library format solved cells, that are not givens, can be marked
		// with '+'
		// solvedButNotGivens is initialized with 'false'
		final boolean[] solvedButNotGivens = new boolean[81];
		if (libraryFormat) {
			// in library format the sudoku itself is always in the form
			// "81.37.6..4..18....53....8.1.73...51..65...98..84...36..5.....29...561....48792156"
			final StringBuilder tmp = new StringBuilder(lines[0]);
			for (int i = 0; i < tmp.length(); i++) {
				final char ch = tmp.charAt(i);
				if (ch == '+') {
					// cell is not a given!
					solvedButNotGivens[i] = true;
					tmp.deleteCharAt(i);
					if (i >= 0) {
						i--;
					}
				}
			}
		}

		// delete markup characters, parse the candidates and set them
		for (int i = 0; i < lines.length; i++) {
			if (lines[i] != null) {
				// all characters except digits, '.' and ' ' are deleted (consecutive
				// blanks
				// are reduced to one blank only).
				// '|' is practically always used as block delimiter -> replaced by
				// blank
				final StringBuilder tmp = new StringBuilder(lines[i].trim());
				// border lines have to contain "---"
				int tmpIndex = -1;
				while ((tmpIndex = tmp.indexOf("---")) >= 0) {
					if (tmpIndex > 0) {
						final char ch = tmp.charAt(tmpIndex - 1);
						if (!Character.isDigit(ch) && ch != ' ' && ch != '|') {
							tmpIndex--;
						}
					}
					int endIndex = tmpIndex + 1;
					while (endIndex < tmp.length() && tmp.charAt(endIndex) == '-') {
						endIndex++;
					}
					if (endIndex < tmp.length() - 1) {
						final char ch = tmp.charAt(endIndex + 1);
						if (!Character.isDigit(ch) && ch != ' ' && ch != '|') {
							endIndex++;
						}
					}
					tmp.delete(tmpIndex, endIndex + 1);
				}
				// throw out garbage
				for (int j = 0; j < tmp.length(); j++) {
					final char ch = tmp.charAt(j);
					if (ch == '|') {
						tmp.setCharAt(j, ' ');
					} else if (!Character.isDigit(ch) && ch != '.' && ch != ' ') {
						tmp.deleteCharAt(j);
						if (j >= 0) {
							j--;
						}
					}
				}
				// remove consecutive blanks
				int index = 0;
				while ((index = tmp.indexOf("  ")) != -1) {
					tmp.deleteCharAt(index);
				}
				lines[i] = tmp.toString().trim();
				// if lines[i] is now empty it is removed
				if (lines[i].length() == 0) {
					for (int j = i; j < lines.length - 1; j++) {
						lines[j] = lines[j + 1];
					}
					lines[lines.length - 1] = null;
					anzLines--;
					i--;
				}
			}
		}

		// special case SimpleSudoku: contains PM grid and one liner -> ignore one
		// liner
		if (anzLines == 10) {
			anzLines--;
		}
		// SimpleSudoku can contain 3 grids: givens, solved cells and PM
		boolean ssGivensRead = false;
		String ssGivens = null;
		boolean ssCellsRead = false;
		String ssCells = null;
		while (anzLines > 9 && anzLines % 9 == 0) {
			if (!ssGivensRead) {
				ssGivens = this.getSSString(lines);
				ssGivensRead = true;
				ssCellsRead = true;
				ssCells = ssGivens;
			} else {
				ssCells = this.getSSString(lines);
				ssCellsRead = true;
			}
			for (int i = 9; i < anzLines; i++) {
				lines[i - 9] = lines[i];
				if (i >= anzLines - 9) {
					lines[i] = null;
				}
			}
			anzLines -= 9;
		}

		// if we have a PM grid, candidates are parsed to cands; for one liners the
		// cells are set directly
		int sRow = 0;
		int sCol = 0;
		int sIndex = 0;
		boolean singleDigits = true;
		boolean isPmGrid = false;
		String sInit = lines[0];
		for (int i = 1; i < anzLines; i++) {
			sInit += " " + lines[i];
		}
		if (sInit.length() > 81) {
			singleDigits = false;
		}
		if (sInit.length() > 2 * 81) {
			isPmGrid = true;
		}
		while (sIndex < sInit.length()) {
			// jump to next block of digits
			char ch = sInit.charAt(sIndex);
			while (sIndex < sInit.length() && !(Character.isDigit(ch) || ch == '.')) {
				sIndex++;
				ch = sInit.charAt(sIndex);
			}
			if (sIndex >= sInit.length()) {
				break;
			}
			if (isPmGrid) {
				if (ch == '.' || ch == '0') {
					cands[sRow][sCol] = 0;
					sIndex++;
				} else {
					if (singleDigits) {
						cands[sRow][sCol] = Integer.parseInt(sInit.substring(sIndex, sIndex + 1));
						sIndex++;
					} else {
						int endIndex = sInit.indexOf(' ', sIndex);
						if (endIndex < 0) {
							endIndex = sInit.length();
						}
						cands[sRow][sCol] = Integer.parseInt(sInit.substring(sIndex, endIndex));
						sIndex = endIndex;
					}
				}
			} else {
				if (Character.isDigit(ch) && Character.digit(ch, 10) > 0) {
					boolean given = true;
					if (libraryFormat) {
						given = !solvedButNotGivens[sRow * 9 + sCol];
					}
					this.setCell(sRow, sCol, Character.digit(ch, 10), given);
				}
				sIndex++;
			}
			sCol++;
			if (sCol == 9) {
				sCol = 0;
				sRow++;
			}
		}

		if (isPmGrid) {
			// set the sudoku: set all candidates in a first pass; then check for all
			// cells,
			// that contain only one candidate, if that candidate is set in a buddy;
			// if not,
			// the cell is set
			final int[] cands1 = new int[10];
			for (int row = 0; row < cands.length; row++) {
				for (int col = 0; col < cands[row].length; col++) {
					Arrays.fill(cands1, 0);
					int sum = cands[row][col];
					while (sum > 0) {
						cands1[sum % 10] = 1;
						sum /= 10;
					}
					final int cellIndex = getIndex(row, col);
					for (int i = 1; i < cands1.length; i++) {
						if (cands1[i] == 0 && this.isCandidate(cellIndex, i)) {
							this.setCandidate(row, col, i, false);
						} else if (cands1[i] == 1 && !this.isCandidate(cellIndex, i)) {
							this.setCandidate(row, col, i, true);
						}
					}
				}
			}
			for (int i = 0; i < this.values.length; i++) {
				if (this.getNumberOfCandidates(i) == 1) {
					if (ssCellsRead) {
						// special case SimpleSudoku: a 81 character string with all
						// cell values is available
						final char ch = ssCells.charAt(i);
						if (ch != '0' && ch != '.') {
							// cell must be set
							this.setCell(i, Character.digit(ch, 10), true);
						}
					} else {
						// check if the candidate is set in one of the buddies
						for (int j = 1; j <= 9; j++) {
							if (!this.isCandidate(i, j)) {
								continue;
							}
							int count = 0;
							for (int k = 0; k < buddies[i].size(); k++) {
								final int buddyIndex = buddies[i].get(k);
								if (this.values[buddyIndex] == 0 && this.isCandidate(buddyIndex, j)) {
									count++;
									break;
								}
							}
							if (count == 0) {
								// no buddies -> set the cell
								this.setCell(i, j, true);
							}
						}
					}
				}
			}
		}
		if (libraryFormat && libraryCandStr.length() > 0) {
			final String[] candArr = libraryCandStr.split(" ");
			for (int i = 0; i < candArr.length; i++) {
				if (candArr[i].length() == 0) {
					continue;
				}
				int candPos = Integer.parseInt(candArr[i]);
				final int col = candPos % 10;
				candPos /= 10;
				final int row = candPos % 10;
				candPos /= 10;
				this.setCandidate(row - 1, col - 1, candPos, false);
			}
		}

		// for SimpleSudoku the givens are set in an extra pass
		if (ssGivensRead) {
			this.setGivens(ssGivens);
		}

		if (saveInitialState) {
			this.setInitialState(this.getSudoku(ClipboardMode.LIBRARY));
		}

		// we simply assume the sudoku is valid; for batch use, status
		// is ignored and statusGivens has to be VALID (no checks are made).
		// for the GUI, status and statusGivens are checked elsewhere
		this.status = SudokuStatus.VALID;
		this.statusGivens = SudokuStatus.VALID;
	}

	/**
	 * Takes the first 9 Strings of <code>lines</code> and condenses it into one
	 * 81 character string.
	 */
	private String getSSString(final String[] lines) {
		final StringBuilder ssTemp = new StringBuilder();
		for (int i = 0; i < 9; i++) {
			ssTemp.append(lines[i]);
		}
		for (int i = 0; i < ssTemp.length(); i++) {
			final char ch = ssTemp.charAt(i);
			if (!Character.isDigit(ch) && ch != '.') {
				ssTemp.deleteCharAt(i);
				i--;
			}
		}
		return ssTemp.toString();
	}

	/**
	 * Calculates the number of candidates in a cell, that is not set.<br>
	 * If the cell is already set, <code>cells[index]</code> will contain 0, which
	 * gives a return code of 0 as well.
	 */
	public int getNumberOfCandidates(final int index) {
		return ANZ_VALUES[this.cells[index]];
	}

	/**
	 * Returns an array that holds all candidate values that are still possible in
	 * cell <code>index</code>.
	 */
	public int[] getAllCandidates(final int index) {
		return POSSIBLE_VALUES[this.cells[index]];
	}

	/**
	 * Returns an array that holds all candidate values that are still possible in
	 * cell <code>index</code>.
	 */
	public int[] getAllCandidates(final int index, final boolean user) {
		if (user) {
			return POSSIBLE_VALUES[this.userCells[index]];
		} else {
			return this.getAllCandidates(index);
		}
	}

	/**
	 * Calculates the number of candidates in a cell, that is not set.
	 */
	public int getAnzCandidates(final int index, final boolean user) {
		if (user) {
			return ANZ_VALUES[this.userCells[index]];
		} else {
			return this.getNumberOfCandidates(index);
		}
	}

	/**
	 * Search for <code>pattern</code> in string <code>str</code>. Return the
	 * number of occurrencies.
	 */
	private int getAnzPatternInString(final String str, final String pattern) {
		int anzPattern = 0;
		int index = -1;
		while ((index = str.indexOf(pattern, index + 1)) >= 0) {
			anzPattern++;
		}
		return anzPattern;
	}

	/**
	 * {@link #unsolvedCellsAnz} is checked and {@link #free} and the queues for
	 * Naked and Hidden Singles are rebuilt.
	 *
	 */
	public void rebuildInternalData() {
		this.nsQueue.clear();
		this.hsQueue.clear();
		for (int i = 0; i < this.free.length; i++) {
			for (int j = 0; j < this.free[i].length; j++) {
				this.free[i][j] = 0;
			}
		}
		// now check all cells
		int anz = 0;
		for (int index = 0; index < this.values.length; index++) {
			if (this.values[index] != 0) {
				// just to be sure
				this.cells[index] = 0;
			} else {
				// one more unsolved cell
				anz++;
				// check the candidates and rebuild the Naked Single queue
				final int[] cands = POSSIBLE_VALUES[this.cells[index]];
				for (int i = 0; i < cands.length; i++) {
					// add candidate to free
					for (int j = 0; j < CONSTRAINTS[index].length; j++) {
						this.free[CONSTRAINTS[index][j]][cands[i]]++;
					}
				}
				// Naked Single?
				if (ANZ_VALUES[this.cells[index]] == 1) {
					this.addNakedSingle(index, CAND_FROM_MASK[this.cells[index]]);
				}
			}
		}
		this.unsolvedCellsAnz = anz;
		// now rebuild the Hidden Single queue
		for (int i = 0; i < this.free.length; i++) {
			for (int j = 1; j <= 9; j++) {
				if (this.free[i][j] == 1) {
					while (!this.addHiddenSingle(i, j))
						;
				}
			}
		}
	}

	/**
	 * Check if the sudoku is valid. If {@link #solution} has already been set,
	 * the sudoku is checked against the solution.<br>
	 * For candidates every candidate set must be allowed (not invalidated by an
	 * already set cell) and no candidate, that is part of the solution, must be
	 * missing. {@link #unsolvedCellsAnz} is checked and {@link #free} and the
	 * queues for Naked and Hidden Singles are rebuilt.
	 */
	public boolean checkSudoku() {
		// rebuild the internal data
		this.rebuildInternalData();
		// now check all cells
		for (int index = 0; index < this.values.length; index++) {
			if (this.values[index] != 0) {
				// check values: must be valid and equal the solution
				if (!this.isValidValue(index, this.values[index])) {
					// value is invalid
					return false;
				}
				if (this.solutionSet && this.solution[index] != this.values[index]) {
					// value is valid but deviates from the solution
					return false;
				}
			} else {
				// check the candidates
				final int[] cands = POSSIBLE_VALUES[this.cells[index]];
				for (int i = 0; i < cands.length; i++) {
					// all candidates must be valid
					if (!this.isValidValue(index, cands[i])) {
						// candidate is invalid (value set in a buddy)
						return false;
					}
				}
				// the candidate for the solution must be still there
				if (this.solutionSet && !this.isCandidate(index, this.solution[index])) {
					// sudoku cannot be solved
					return false;
				}
			}
		}
		return true;
	}

	/**
	 * Returns the current state of the sudoku as string. The desired format is
	 * given by <code>mode</code>.
	 */
	public String getSudoku(final ClipboardMode mode) {
		return this.getSudoku(mode, null);
	}

	/**
	 * Returns the current state of the sudoku as string. The desired format is
	 * given by <code>mode</code>. If <code>step</code> is not null, it is
	 * included in the output.
	 */
	public String getSudoku(final ClipboardMode mode, final SolutionStep step) {

		final StringBuilder out = new StringBuilder();
		if (mode == ClipboardMode.LIBRARY) {
			if (step == null) {
				out.append(":0000:x:");
			} else {
				String type = step.getType().getLibraryType();
				if (step.getType().isFish() && step.isIsSiamese()) {
					type += "1";
				}
				out.append(":").append(type).append(":");
				final SortedSet<Integer> candToDeleteSet = new TreeSet<Integer>();
				if (step.getType().useCandToDelInLibraryFormat()) {
					for (final Candidate cand : step.getCandidatesToDelete()) {
						candToDeleteSet.add(cand.getValue());
					}
				}
				// if nothing can be deleted, append the cells, that can be set
				if (candToDeleteSet.isEmpty()) {
					for (int i = 0; i < step.getValues().size(); i++) {
						candToDeleteSet.add(step.getValues().get(i));
					}
				}
				for (final int cand : candToDeleteSet) {
					out.append(cand);
				}
				out.append(":");
			}
		}
		if (mode == ClipboardMode.CLUES_ONLY || mode == ClipboardMode.VALUES_ONLY || mode == ClipboardMode.LIBRARY) {
			for (int i = 0; i < LENGTH; i++) {
				if (this.getValue(i) == 0 || (mode == ClipboardMode.CLUES_ONLY && !this.isFixed(i))) {
					out.append(NON_GIVEN_CELL);
				} else {
					if (mode == ClipboardMode.LIBRARY && !this.isFixed(i)) {
						out.append("+");
					}
					out.append(Integer.toString(this.getValue(i)));
				}
			}
		}
		if (mode == ClipboardMode.PM_GRID || mode == ClipboardMode.PM_GRID_WITH_STEP
				|| mode == ClipboardMode.CLUES_ONLY_FORMATTED || mode == ClipboardMode.VALUES_ONLY_FORMATTED) {
			// new: create one StringBuilder per cell with all candidates/values; add
			// special characters for step if necessary; if a '*' is added to a cell,
			// insert a blank in all other cells of that col that don't have a '*'.
			// calculate fieldLength and write it
			final StringBuilder[] cellBuffers = new StringBuilder[this.cells.length];
			for (int i = 0; i < this.cells.length; i++) {
				cellBuffers[i] = new StringBuilder();
				int value = this.getValue(i);
				if (mode == ClipboardMode.CLUES_ONLY_FORMATTED && !this.isFixed(i)) {
					// only clues!
					value = 0;
				}
				if (value != 0) {
					cellBuffers[i].append(String.valueOf(value));
				} else {
					String candString = "";
					if (mode != ClipboardMode.CLUES_ONLY_FORMATTED && mode != ClipboardMode.VALUES_ONLY_FORMATTED) {
						candString = this.getCandidateString(i);
					}
					if (candString.isEmpty()) {
						candString = NON_GIVEN_CELL;
					}
					cellBuffers[i].append(candString);
				}
			}

			// now add markings for step
			if (mode == ClipboardMode.PM_GRID_WITH_STEP && step != null) {
				final boolean[] cellsWithExtraChar = new boolean[this.cells.length];
				// indices
				for (final int index : step.getIndices()) {
					this.insertOrReplaceChar(cellBuffers[index], '*');
					cellsWithExtraChar[index] = true;
				}
				// fins and endo-fins
				if (SolutionType.isFish(step.getType()) || step.getType() == SolutionType.W_WING) {
					for (final Candidate cand : step.getFins()) {
						final int index = cand.getIndex();
						this.insertOrReplaceChar(cellBuffers[index], '#');
						cellsWithExtraChar[index] = true;
					}
				}
				if (SolutionType.isFish(step.getType())) {
					for (final Candidate cand : step.getEndoFins()) {
						final int index = cand.getIndex();
						this.insertOrReplaceChar(cellBuffers[index], '@');
						cellsWithExtraChar[index] = true;
					}
				}
				// chains
				for (final Chain chain : step.getChains()) {
					for (int i = chain.getStart(); i <= chain.getEnd(); i++) {
						if (chain.getNodeType(i) == Chain.ALS_NODE) {
							// ALS are handled separately
							continue;
						}
						int index = chain.getCellIndex(i);
						this.insertOrReplaceChar(cellBuffers[index], '*');
						cellsWithExtraChar[index] = true;
						if (chain.getNodeType(i) == Chain.GROUP_NODE) {
							index = Chain.getSCellIndex2(chain.getChain()[i]);
							if (index != -1) {
								this.insertOrReplaceChar(cellBuffers[index], '*');
								cellsWithExtraChar[index] = true;
							}
							index = Chain.getSCellIndex3(chain.getChain()[i]);
							if (index != -1) {
								this.insertOrReplaceChar(cellBuffers[index], '*');
								cellsWithExtraChar[index] = true;
							}
						}
					}
				}

				// ALS
				char alsChar = 'A';
				for (final AlsInSolutionStep als : step.getAlses()) {
					for (final int index : als.getIndices()) {
						this.insertOrReplaceChar(cellBuffers[index], alsChar);
						cellsWithExtraChar[index] = true;
					}
					alsChar++;
				}

				// candidates to delete
				for (final Candidate cand : step.getCandidatesToDelete()) {
					final int index = cand.getIndex();
					final char candidate = Character.forDigit(cand.getValue(), 10);
					for (int i = 0; i < cellBuffers[index].length(); i++) {
						if (cellBuffers[index].charAt(i) == candidate
								&& (i == 0 || (i > 0 && cellBuffers[index].charAt(i - 1) != '-'))) {
							cellBuffers[index].insert(i, '-');
							if (i == 0) {
								cellsWithExtraChar[index] = true;
							}
						}
					}
				}

				// now adjust columns, where a character was added
				for (int i = 0; i < cellsWithExtraChar.length; i++) {
					if (cellsWithExtraChar[i]) {
						final int[] indices = COLS[Sudoku2.getCol(i)];
						for (int j = 0; j < indices.length; j++) {
							if (Character.isDigit(cellBuffers[indices[j]].charAt(0))) {
								cellBuffers[indices[j]].insert(0, ' ');
							}
						}
					}
				}
			}

			final int[] fieldLengths = new int[COLS.length];
			for (int i = 0; i < cellBuffers.length; i++) {
				final int col = getCol(i);
				if (cellBuffers[i].length() > fieldLengths[col]) {
					fieldLengths[col] = cellBuffers[i].length();
				}
			}
			for (int i = 0; i < fieldLengths.length; i++) {
				fieldLengths[i] += 2;
			}
			final String separator = System.getProperty("line.separator");
			for (int i = 0; i < 9; i++) {
				if ((i % 3) == 0) {
					this.writeLine(out, i, fieldLengths, null, true, separator);
				}
				this.writeLine(out, i, fieldLengths, cellBuffers, false, separator);
			}
			this.writeLine(out, 9, fieldLengths, null, true, separator);

			if (mode == ClipboardMode.PM_GRID_WITH_STEP && step != null) {
				out.append(step.toString(2));
			}
		}
		if (mode == ClipboardMode.LIBRARY) {
			boolean first = true;
			out.append(":");
			for (int i = 0; i < this.cells.length; i++) {
				if (this.getValue(i) == 0) {
					for (int j = 1; j <= 9; j++) {
						if (this.isValidValue(i, j) && !this.isCandidate(i, j)) {
							if (first) {
								first = false;
							} else {
								out.append(" ");
							}
							out.append(Integer.toString(j)).append(Integer.toString((i / 9) + 1))
									.append(Integer.toString((i % 9) + 1));
						}
					}
				}
			}
			if (step == null) {
				out.append("::");
			} else {
				final String candString = step.getCandidateString(true);
				out.append(":").append(candString).append(":");
				if (candString.isEmpty()) {
					out.append(step.getValueIndexString());
				}
				out.append(":");
				if (step.getType().isSimpleChainOrLoop()) {
					out.append((step.getChainLength() - 1));
				}
			}
		}
		return out.toString();
	}

	/**
	 * If the first character in <code>buffer</code> is a digit, <code>ch</code>
	 * is inserted before it. If it is not a digit, it is replaced by
	 * <code>ch</code>.
	 */
	private void insertOrReplaceChar(final StringBuilder buffer, final char ch) {
		if (Character.isDigit(buffer.charAt(0))) {
			buffer.insert(0, ch);
		} else {
			buffer.replace(0, 1, Character.toString(ch));
		}
	}

	/**
	 * Writes a line of a sudoku (cand be a border line).
	 * <code>fieldLengths</code> holds the width of each column.
	 */
	private void writeLine(final StringBuilder out, final int line, final int[] fieldLengths,
			final StringBuilder[] cellBuffers, final boolean drawOutline, final String separator) {
		if (drawOutline) {
			char leftRight = '.';
			char middle = '.';
			if (line == 3 || line == 6) {
				leftRight = ':';
				middle = '+';
			} else if (line == 9) {
				leftRight = '\'';
				middle = '\'';
			}
			out.append(leftRight);
			for (int i = 0; i < fieldLengths[0] + fieldLengths[1] + fieldLengths[2]; i++) {
				out.append('-');
			}
			out.append(middle);
			for (int i = 0; i < fieldLengths[3] + fieldLengths[4] + fieldLengths[5]; i++) {
				out.append('-');
			}
			out.append(middle);
			for (int i = 0; i < fieldLengths[6] + fieldLengths[7] + fieldLengths[8]; i++) {
				out.append('-');
			}
			out.append(leftRight);
		} else {
			for (int i = line * 9; i < (line + 1) * 9; i++) {
				if ((i % 3) == 0) {
					out.append("|");
					if ((i % 9) != 8) {
						out.append(' ');
					}
				} else {
					out.append(' ');
				}
				int tmp = fieldLengths[getCol(i)];
				out.append(cellBuffers[i]);
				tmp -= cellBuffers[i].length();
				for (int j = 0; j < tmp - 1; j++) {
					out.append(' ');
				}
			}
			out.append('|');
		}
		out.append(separator);
	}

	/**
	 * Returns the value set in <code>index</code> or 0, if the cell is not set.
	 */
	public int getValue(final int line, final int col) {
		return this.getValue(getIndex(line, col));
	}

	/**
	 * Returns the value set in <code>index</code> or 0, if the cell is not set.
	 */
	public int getValue(final int index) {
		return this.values[index];
	}

	/**
	 * Returns the solution set in <code>index</code> or 0, if the solution is
	 * unknown.
	 */
	public int getSolution(final int line, final int col) {
		return this.getSolution(getIndex(line, col));
	}

	/**
	 * Returns the solution set in <code>index</code> or 0, if the solution is
	 * unknown.
	 */
	public int getSolution(final int index) {
		if (!this.solutionSet) {
			return 0;
		}
		return this.solution[index];
	}

	/**
	 * Returns if <code>index</code> is a given.
	 */
	public boolean isFixed(final int line, final int col) {
		return this.isFixed(getIndex(line, col));
	}

	/**
	 * Returns if <code>index</code> is a given.
	 */
	public boolean isFixed(final int index) {
		return this.fixed[index];
	}

	/**
	 * Set a cell as given.
	 */
	public void setIsFixed(final int index, final boolean isFixed) {
		this.fixed[index] = isFixed;
	}

	/**
	 * Checks if <code>cand</code> is set as candidate in
	 * <code>line</code>/<code>col</code>.
	 */
	public boolean isCandidate(final int line, final int col, final int cand) {
		return this.isCandidate(getIndex(line, col), cand);
	}

	/**
	 * Checks if <code>cand</code> is set as candidate in <code>index</code>.
	 */
	public boolean isCandidate(final int index, final int cand) {
		return ((this.cells[index] & MASKS[cand]) != 0);
		// return candidates[cand].contains(index);
	}

	/**
	 * Checks if <code>cand</code> is set as candidate in
	 * <code>line</code>/<code>col</code>.
	 */
	public boolean isCandidate(final int line, final int col, final int cand, final boolean user) {
		return this.isCandidate(getIndex(line, col), cand, user);
	}

	/**
	 * Checks if <code>cand</code> is set as candidate in <code>index</code>. If
	 * <code>user</code> is <code>true</code>, the test is made against
	 * {@link #userCells}, if it is <code>false</code>, against {@link #cells}.
	 */
	public boolean isCandidate(final int index, final int cand, final boolean user) {
		if (user) {
			return ((this.userCells[index] & MASKS[cand]) != 0);
		} else {
			return this.isCandidate(index, cand);
		}
	}

	/**
	 * Checks, if a given candidate is set and valid; used for display.
	 */
	public boolean isCandidateValid(final int index, final int value, final boolean user) {
		if (this.isCandidate(index, value, user) && this.isValidValue(index, value)) {
			return true;
		}
		return false;
	}

	/**
	 * Checks, if a given set of candidates is present in the cell
	 */
	public boolean areCandidatesValid(final int index, final boolean[] candidates, final boolean user) {
		if (this.values[index] != 0) {
			return false;
		}
		if (candidates[candidates.length - 1]) {
			return this.getNumberOfCandidates(index) == 2;
		}
		if (!Options.getInstance().isUseOrInsteadOfAndForFilter()) {
			for (int i = 1; i < candidates.length - 1; i++) {
				if (candidates[i] && !this.isCandidate(index, i, user)) {
					return false;
				}
			}
			return true;
		} else {
			for (int i = 1; i < candidates.length; i++) {
				if (candidates[i] && this.isCandidate(index, i, user)) {
					return true;
				}
			}
			return false;
		}
	}

	/**
	 * Returns a string containing all candidates for the given cell.
	 */
	public String getCandidateString(final int index) {
		final StringBuilder tmp = new StringBuilder();
		final int[] cands = POSSIBLE_VALUES[this.cells[index]];
		for (int i = 0; i < cands.length; i++) {
			tmp.append(cands[i]);
		}
		return tmp.toString();
	}

	/**
	 * Fill a {@link SudokuSet} with the candidates for a cell.
	 */
	public void getCandidateSet(final int line, final int col, final SudokuSet candSet) {
		this.getCandidateSet(getIndex(line, col), candSet);
	}

	/**
	 * Fill a {@link SudokuSet} with the candidates for a cell.
	 */
	public void getCandidateSet(final int index, final SudokuSet candSet) {
		candSet.set(this.cells[index] << 1);
	}

	/**
	 * Deletes a candidate. Delegates to {@link #setCandidate(int, int, boolean)}.
	 *
	 * @return <code>false</code>, if the puzzle becomes invalid by deleting a
	 *         candidate
	 */
	public boolean delCandidate(final int index, final int value) {
		return this.setCandidate(index, value, false);
	}

	/**
	 * Deletes a candidate. Delegates to
	 * {@link #setCandidate(int, int, boolean, boolean)}.
	 *
	 * @return <code>false</code>, if the puzzle becomes invalid by deleting a
	 *         candidate
	 */
	public boolean delCandidate(final int index, final int value, final boolean user) {
		return this.setCandidate(index, value, false, user);
	}

	/**
	 * Sets a candidate. Delegates to {@link #setCandidate(int, int, boolean)}.
	 */
	public void setCandidate(final int index, final int value) {
		this.setCandidate(index, value, true);
	}

	/**
	 * Sets or deletes a candidate. Delegates to
	 * {@link #setCandidate(int, int, boolean)}.
	 *
	 * @return <code>false</code>, if the puzzle becomes invalid by deleting a
	 *         candidate
	 */
	public boolean setCandidate(final int line, final int col, final int value, final boolean set) {
		return this.setCandidate(getIndex(line, col), value, set);
	}

	/**
	 * Sets or deletes a candidate. The candidate is added to or removed from
	 * {@link #cells} and {@link #free} is updated accordingly. If the update of
	 * {@link #free} indicates a new single, it is added to the appropriate
	 * queue.<br>
	 * To support the {@link BacktrackingSolver} checks are made if the solution
	 * becomes invalid by the move.
	 *
	 * @return <code>false</code>, if the puzzle becomes invalid by deleting a
	 *         candidate
	 */
	public boolean setCandidate(final int index, final int value, final boolean set) {
		if (set) {
			if ((this.cells[index] & MASKS[value]) == 0) {
				this.cells[index] |= MASKS[value];
				final int newAnz = ANZ_VALUES[this.cells[index]];
				if (newAnz == 1) {
					this.addNakedSingle(index, value);
				} else if (newAnz == 2) {
					this.nsQueue.deleteNakedSingle(index);
				}
				for (int i = 0; i < CONSTRAINTS[index].length; i++) {
					final int newFree = ++this.free[CONSTRAINTS[index][i]][value];
					if (newFree == 1) {
						this.addHiddenSingle(CONSTRAINTS[index][i], value);
					} else if (newFree == 2) {
						this.hsQueue.deleteHiddenSingle(CONSTRAINTS[index][i], value);
					}
				}
			}
		} else {
			if ((this.cells[index] & MASKS[value]) != 0) {
				this.cells[index] &= ~MASKS[value];
				if (this.cells[index] == 0) {
					// puzzle invalid
					return false;
				}
				if (ANZ_VALUES[this.cells[index]] == 1) {
					this.addNakedSingle(index, CAND_FROM_MASK[this.cells[index]]);
				}
				for (int i = 0; i < CONSTRAINTS[index].length; i++) {
					final int newFree = --this.free[CONSTRAINTS[index][i]][value];
					if (newFree == 1) {
						this.addHiddenSingle(CONSTRAINTS[index][i], value);
					} else if (newFree == 0) {
						// can happen, if the candidate was invalid.
						// invalid candidates produce an entry in the HS queue
						// that has to be deleted again (BUG 3515379)
						this.hsQueue.deleteHiddenSingle(CONSTRAINTS[index][i], value);
					}
				}
			}
		}
		return true;
	}

	/**
	 * Sets or deletes a candidate. Most work is delegated to
	 * {@link #setCandidate(int, int, boolean)}. If <code>user</code> is set, the
	 * changes are made also in {@link #userCells}.
	 *
	 * @return <code>false</code>, if the puzzle becomes invalid by deleting a
	 *         candidate
	 */
	public boolean setCandidate(final int index, final int value, final boolean set, final boolean user) {
		final boolean ret = this.setCandidate(index, value, set);
		if (user) {
			if (set) {
				this.userCells[index] |= MASKS[value];
			} else {
				this.userCells[index] &= ~MASKS[value];
			}
		}
		return ret;
	}

	/**
	 * Sets or a value in or deletes a value from a cell. Delegates to
	 * {@link #setCell(int, int) }.
	 *
	 * @return <code>false</code>, if the puzzle becomes invalid by setting a cell
	 */
	public boolean setCell(final int line, final int col, final int value) {
		return this.setCell(getIndex(line, col), value);
	}

	/**
	 * Sets or a value in or deletes a value from a cell. Delegates to
	 * {@link #setCell(int, int, boolean, boolean) }.
	 *
	 * @return <code>false</code>, if the puzzle becomes invalid by setting a cell
	 */
	public boolean setCell(final int index, final int value) {
		return this.setCell(index, value, false, true);
	}

	/**
	 * Sets or a value in or deletes a value from a cell. Delegates to
	 * {@link #setCell(int, int, boolean, boolean) }.
	 *
	 * @param line
	 * @param col
	 * @param value
	 * @param isFixed
	 * @return <code>false</code>, if the puzzle becomes invalid by setting a cell
	 */
	public boolean setCell(final int line, final int col, final int value, final boolean isFixed) {
		return this.setCell(getIndex(line, col), value, isFixed, true);
	}

	/**
	 * Sets or a value in or deletes a value from a cell. Delegates to
	 * {@link #setCell(int, int, boolean, boolean) }.
	 *
	 * @param index
	 * @param value
	 * @param isFixed
	 * @return
	 */
	public boolean setCell(final int index, final int value, final boolean isFixed) {
		return this.setCell(index, value, isFixed, true);
	}

	/**
	 * Sets or a value in or deletes a value from a cell. The internal candidates
	 * are automatically adapted:
	 * <ul>
	 * <li>If a value is set, the candidate is removed from all buddies</li>
	 * <li>If a value is removed, the candidate is added to all unsolved cells in
	 * which it is not invalid.</li>
	 * </ul>
	 * Setting a value automatically affects {@link #userCells} as well, removing
	 * it leaves the user candidates unchanged. {@link #unsolvedCellsAnz} is
	 * changed accordingly.<br>
	 * Eliminating candidates in the buddies automatically makes the correct
	 * entries in the Hidden Singles queue. If a cell is set, a manual check for
	 * Hidden Singles in the cell's constraints is done.
	 *
	 * @return <code>false</code>, if the puzzle becomes invalid by setting a cell
	 */
	public boolean setCell(final int index, final int value, final boolean isFixed, final boolean user) {
		if (this.values[index] == value) {
			// nothing to do
			return true;
		}
		boolean valid = true;
		final int oldValue = this.values[index];
		this.values[index] = value;
		this.fixed[index] = isFixed;
		if (value != 0) {
			final int[] cands = POSSIBLE_VALUES[this.cells[index]];
			this.cells[index] = 0;
			if (user) {
				this.userCells[index] = 0;
			}
			this.unsolvedCellsAnz--;
			// check the buddies
			for (int i = 0; i < buddies[index].size(); i++) {
				final int buddyIndex = buddies[index].get(i);
				// candidates are deleted in userCells as well
				// delCandidate does the check for Naked or Hidden Single
				if (!this.setCandidate(buddyIndex, value, false)) {
					valid = false;
				}
				if (user) {
					this.userCells[buddyIndex] &= ~MASKS[value];
				}
			}
			// now check all candidates from the cell itself
			for (int i = 0; i < cands.length; i++) {
				final int cand = cands[i];
				for (int j = 0; j < CONSTRAINTS[index].length; j++) {
					final int constr = CONSTRAINTS[index][j];
					final int newFree = --this.free[constr][cand];
					if (newFree == 1 && value != cand) {
						this.addHiddenSingle(constr, cand);
					} else if (newFree == 0 && cand != value) {
						valid = false;
					}
				}
			}
		} else {
			// in the cell itself all candidates that are possible are set
			// userCandidates is not changed
			for (int cand = 1; cand <= 9; cand++) {
				if (this.isValidValue(index, cand)) {
					this.setCandidate(index, cand);
				}
			}
			// the deleted value is a candidate in all buddies that are not set and
			// not invalid
			for (int i = 0; i < buddies[index].size(); i++) {
				final int buddyIndex = buddies[index].get(i);
				if (this.getValue(buddyIndex) == 0 && this.isValidValue(buddyIndex, oldValue)) {
					this.setCandidate(buddyIndex, oldValue);
				}
			}
			// the singles queues get invalid by deleting a value from a cell
			// -> rebuild everything from scratch!
			// adjusts unsolvedCellsAnz as well!
			this.rebuildInternalData();
		}
		return valid;
	}

	public void setCellBS(final int index, final int value) {
		this.values[index] = value;
		// adjust mask
		this.cells[index] = 0;
		// check the buddies
		for (int i = 0; i < buddies[index].size(); i++) {
			final int buddyIndex = buddies[index].get(i);
			this.cells[buddyIndex] &= ~MASKS[value];
		}
	}

	/**
	 * Checks if a certain value is valid for a certain index.
	 */
	public boolean isValidValue(final int line, final int col, final int value) {
		return this.isValidValue(getIndex(line, col), value);
	}

	/**
	 * Checks if a certain value is valid for a certain index. The value is
	 * invalid if one of the buddies contains that value already.<br>
	 * This method works for candidates too.
	 */
	public boolean isValidValue(final int index, final int value) {
		for (int i = 0; i < buddies[index].size(); i++) {
			if (this.values[buddies[index].get(i)] == value) {
				// value set in a buddy -> invalid
				return false;
			}
		}
		return true;
	}

	/**
	 * Calculates the index into {@link #LINES} from the cell index.
	 */
	public static int getLine(final int index) {
		return index / UNITS;
	}

	/**
	 * Calculates the index into {@link #COLS} from the cell index.
	 */
	public static int getCol(final int index) {
		return index % UNITS;
	}

	/**
	 * Calculates the index into {@link #BLOCKS} from the cell index.
	 */
	public static int getBlock(final int index) {
		return BLOCK_FROM_INDEX[index];
	}

	/**
	 * Calculates the cell index. <code>line</code> and <code>col</code> are zero
	 * based.
	 */
	public static int getIndex(final int line, final int col) {
		return line * 9 + col;
	}

	/**
	 * Checks if the sudoku has been solved completely.
	 */
	public boolean isSolved() {
		return this.unsolvedCellsAnz == 0;
	}

	/**
	 * Determines the number of cells that have already been set.
	 */
	public int getSolvedCellsAnz() {
		return LENGTH - this.unsolvedCellsAnz;
	}

	/**
	 * Determines the number of givens.
	 */
	public int getFixedCellsAnz() {
		int anz = 0;
		for (int i = 0; i < this.fixed.length; i++) {
			if (this.fixed[i]) {
				anz++;
			}
		}
		return anz;
	}

	/**
	 * Returns the number of candidates in all unsolved cells. Needed for progress
	 * bar when solving puzzles.
	 */
	public int getUnsolvedCandidatesAnz() {
		int anz = 0;
		for (int i = 0; i < this.cells.length; i++) {
			anz += ANZ_VALUES[this.cells[i]];
		}
		return anz;
	}

	/**
	 * Calculates buddies. Needed for checks, if cells see each other ("are
	 * buddies"). Two cells <code>index1</code> and <code>index2</code> can see
	 * each other if
	 * <code>buddies[index1].contains(index2)</codes> returns <code>true</code>.
	 */
	private static void initBuddies() {
		if (buddies[0] != null) {
			return;
		}

		for (int i = 0; i < 81; i++) {
			buddies[i] = new SudokuSet();
			for (int j = 0; j < 81; j++) {
				if (i != j && (Sudoku2.getLine(i) == Sudoku2.getLine(j) || Sudoku2.getCol(i) == Sudoku2.getCol(j)
						|| Sudoku2.getBlock(i) == Sudoku2.getBlock(j))) {
					buddies[i].add(j);
				}
			}
			buddiesM1[i] = buddies[i].getMask1();
			buddiesM2[i] = buddies[i].getMask2();
		}

		for (int i = 0; i < UNITS; i++) {
			LINE_TEMPLATES[i] = new SudokuSet();
			for (int j = 0; j < LINES[i].length; j++) {
				LINE_TEMPLATES[i].add(LINES[i][j]);
			}
			LINE_BLOCK_TEMPLATES[i] = LINE_TEMPLATES[i];
			ALL_CONSTRAINTS_TEMPLATES[i] = LINE_TEMPLATES[i];
			COL_TEMPLATES[i] = new SudokuSet();
			for (int j = 0; j < COLS[i].length; j++) {
				COL_TEMPLATES[i].add(COLS[i][j]);
			}
			COL_BLOCK_TEMPLATES[i] = COL_TEMPLATES[i];
			ALL_CONSTRAINTS_TEMPLATES[i + 9] = COL_TEMPLATES[i];
			BLOCK_TEMPLATES[i] = new SudokuSet();
			for (int j = 0; j < BLOCKS[i].length; j++) {
				BLOCK_TEMPLATES[i].add(BLOCKS[i][j]);
			}
			LINE_BLOCK_TEMPLATES[i + 9] = BLOCK_TEMPLATES[i];
			COL_BLOCK_TEMPLATES[i + 9] = BLOCK_TEMPLATES[i];
			ALL_CONSTRAINTS_TEMPLATES[i + 18] = BLOCK_TEMPLATES[i];
		}
		for (int i = 0; i < ALL_CONSTRAINTS_TEMPLATES.length; i++) {
			ALL_CONSTRAINTS_TEMPLATES_M1[i] = ALL_CONSTRAINTS_TEMPLATES[i].getMask1();
			ALL_CONSTRAINTS_TEMPLATES_M2[i] = ALL_CONSTRAINTS_TEMPLATES[i].getMask2();
		}
	}

	/**
	 * Optimization: For every group of 8 cells all possible buddies -> 11 * 256
	 * combinations. These group buddies are used by SudokuSetBase: might speed up
	 * the search for all possible buddies of multiple units (mainly in fish and
	 * ALS search)
	 */
	private static void initGroupedBuddies() {
		for (int i = 0; i < 11; i++) {
			initGroupForGroupedBuddies(i * 8, groupedBuddies[i]);
		}
		for (int i = 0; i < groupedBuddies.length; i++) {
			for (int j = 0; j < groupedBuddies[i].length; j++) {
				groupedBuddiesM1[i][j] = groupedBuddies[i][j].getMask1();
				groupedBuddiesM2[i][j] = groupedBuddies[i][j].getMask2();
			}
		}
	}

	/**
	 * First compute all possible combinations of 8 cells starting with
	 * groupOffset, then get a set with all budies for every combination.
	 *
	 * @param groupOffset
	 *          The first index in the group of 8 cells
	 * @param groupArray
	 *          The array that stores all possible buddy sets
	 */
	private static void initGroupForGroupedBuddies(final int groupOffset, final SudokuSetBase[] groupArray) {
		final SudokuSet groupSet = new SudokuSet();
		for (int i = 0; i < 256; i++) {
			groupSet.clear();
			int mask = 0x01;
			for (int j = 0; j < 8; j++) {
				if ((i & mask) != 0 && (groupOffset + j + 1) <= 81) {
					groupSet.add(groupOffset + j);
				}
				mask <<= 1;
			}
			final SudokuSetBase buddiesSet = new SudokuSetBase(true);
			for (int j = 0; j < groupSet.size(); j++) {
				buddiesSet.and(buddies[groupSet.get(j)]);
			}
			groupArray[i] = buddiesSet;
		}
	}

	/**
	 * Calculates all common buddies of all cells in <code>cells</code> and
	 * returns them in <code>buddies</code>. groupedBuddies is used for
	 * calculations.
	 *
	 * @param cells
	 *          The cells for which the buddies should be calculated
	 * @param buddiesOut
	 *          The resulting buddies
	 */
	public static void getBuddies(final SudokuSetBase cells, final SudokuSetBase buddiesOut) {
		buddiesOut.setAll();
		if (cells.getMask1() != 0) {
			for (int i = 0, j = 0; i < 8; i++, j += 8) {
				final int mIndex = (int) ((cells.getMask1() >> j) & 0xFF);
				buddiesOut.and(groupedBuddies[i][mIndex]);
			}
		}
		if (cells.getMask2() != 0) {
			for (int i = 8, j = 0; i < 11; i++, j += 8) {
				final int mIndex = (int) ((cells.getMask2() >> j) & 0xFF);
				buddiesOut.and(groupedBuddies[i][mIndex]);
			}
		}
	}

	/**
	 * Calculates all common buddies of all cells in <code>cells</code> and
	 * returns them in <code>buddies</code>. groupedBuddies is used for
	 * calculations.
	 *
	 * @param mask1
	 * @param mask2
	 * @param buddiesOut
	 *          The resulting buddies
	 */
	public static void getBuddies(final long mask1, final long mask2, final SudokuSetBase buddiesOut) {
		long outM1 = SudokuSetBase.MAX_MASK1;
		long outM2 = SudokuSetBase.MAX_MASK2;
		if (mask1 != 0) {
			for (int i = 0, j = 0; i < 8; i++, j += 8) {
				final int mIndex = (int) ((mask1 >> j) & 0xFF);
				outM1 &= groupedBuddiesM1[i][mIndex];
				outM2 &= groupedBuddiesM2[i][mIndex];
			}
		}
		if (mask2 != 0) {
			for (int i = 8, j = 0; i < 11; i++, j += 8) {
				final int mIndex = (int) ((mask2 >> j) & 0xFF);
				outM1 &= groupedBuddiesM1[i][mIndex];
				outM2 &= groupedBuddiesM2[i][mIndex];
			}
		}
		buddiesOut.set(outM1, outM2);
	}

	/**
	 * Create all 46656 possible templates. Since the calculation has become
	 * incredibly slow on Windows 7 64bit, the templates are read from a file.
	 */
	private static void initTemplates() {
		for (int i = 0; i < LINES.length; i++) {
			for (int j = 0; j < LINES[i].length; j++) {
				LINE_TEMPLATES[i].add(LINES[i][j]);
				COL_TEMPLATES[i].add(COLS[i][j]);
				BLOCK_TEMPLATES[i].add(BLOCKS[i][j]);
			}
		}
	}

	/**
	 * Makes all cells editable; needed to edit a puzzle
	 */
	public void setNoClues() {
		for (int i = 0; i < this.fixed.length; i++) {
			this.fixed[i] = false;
		}
		this.setStatusGivens(SudokuStatus.INVALID);
	}

	/**
	 * Gets a 81 character string. For every digit in that string, the
	 * corresponding cell is set as a given.<br>
	 *
	 * Since the givens are changed, the {@link #statusGivens} has to be
	 * rechecked.
	 */
	public void setGivens(final String givens) {
		for (int i = 0; i < givens.length(); i++) {
			final char ch = givens.charAt(i);
			if (Character.isDigit(ch) && ch != '0') {
				this.fixed[i] = true;
			} else {
				this.fixed[i] = false;
			}
		}
		final Sudoku2 act = new Sudoku2();
		act.set(this);
		final SudokuGenerator generator = SudokuGeneratorFactory.getDefaultGeneratorInstance();
		final int anzSol = generator.getNumberOfSolutions(act);
		this.setStatusGivens(anzSol);
	}

	/**
	 * Adds a new Naked Single to the Naked Single queue formed by the
	 * synchronized arrays {@link #nsIndices} and {@link #nsValues}.
	 */
	private void addNakedSingle(final int index, final int value) {
		this.nsQueue.addSingle(index, value);
	}

	/**
	 * Adds a new Hidden Single to the Hidden Single queue formed by the
	 * synchronized arrays {@link #hsIndices} and {@link #hsValues}. The cell
	 * containing the single has to be searched for in the corresponding
	 * constraint.
	 *
	 * @return if Hidden Single could be found
	 */
	private boolean addHiddenSingle(final int constraint, final int value) {
		for (int i = 0; i < ALL_UNITS[constraint].length; i++) {
			// Hidden Single: The candidate in question is present in only one cell of
			// the constraint
			final int hsIndex = ALL_UNITS[constraint][i];
			if (this.isCandidate(hsIndex, value)) {
				// Hidden Single found -> store it
				this.hsQueue.addSingle(hsIndex, value);
				return true;
			}
		}
		return false;
	}

	public int getScore() {
		return this.score;
	}

	public void setScore(final int score) {
		this.score = score;
	}

	public DifficultyLevel getLevel() {
		return this.level;
	}

	public void setLevel(final DifficultyLevel level) {
		this.level = level;
	}

	public String getInitialState() {
		return this.initialState;
	}

	public void setInitialState(final String initialState) {
		this.initialState = initialState;
	}

	public int[] getValues() {
		return this.values;
	}

	public void setValues(final int[] values) {
		this.values = values;
	}

	public int[] getSolution() {
		return this.solution;
	}

	public void setSolution(final int[] solution) {
		this.solution = solution;
		this.solutionSet = true;
	}

	public boolean isSolutionSet() {
		return this.solutionSet;
	}

	public void setSolutionSet(final boolean solutionSet) {
		this.solutionSet = solutionSet;
	}

	public boolean[] getFixed() {
		return this.fixed;
	}

	public void setFixed(final boolean[] fixed) {
		this.fixed = fixed;
	}

	public short getCell(final int index) {
		return this.cells[index];
	}

	public short[] getCells() {
		return this.cells;
	}

	public void setCells(final short[] cells) {
		this.cells = cells;
	}

	public short[] getUserCells() {
		return this.userCells;
	}

	public void setUserCells(final short[] userCells) {
		this.userCells = userCells;
	}

	public byte[][] getFree() {
		return this.free;
	}

	public void setFree(final byte[][] free) {
		this.free = free;
	}

	public int getUnsolvedCellsAnz() {
		return this.unsolvedCellsAnz;
	}

	public void setUnsolvedCellsAnz(final int unsolvedCellsAnz) {
		this.unsolvedCellsAnz = unsolvedCellsAnz;
	}

	public SudokuSinglesQueue getNsQueue() {
		return this.nsQueue;
	}

	public void setNsQueue(final SudokuSinglesQueue nsQueue) {
		this.nsQueue = nsQueue;
	}

	public SudokuSinglesQueue getHsQueue() {
		return this.hsQueue;
	}

	public void setHsQueue(final SudokuSinglesQueue hsQueue) {
		this.hsQueue = hsQueue;
	}

	public SudokuStatus getStatus() {
		return this.status;
	}

	public void setStatus(final SudokuStatus status) {
		this.status = status;
	}

	public void setStatus(final int numberOfSolutions) {
		switch (numberOfSolutions) {
		case 0:
			this.status = SudokuStatus.INVALID;
			break;
		case 1:
			this.status = SudokuStatus.VALID;
			break;
		default:
			this.status = SudokuStatus.MULTIPLE_SOLUTIONS;
			break;
		}
	}

	public SudokuStatus getStatusGivens() {
		return this.statusGivens;
	}

	public void setStatusGivens(final SudokuStatus statusGivens) {
		this.statusGivens = statusGivens;
	}

	public void setStatusGivens(final int numberOfSolutions) {
		switch (numberOfSolutions) {
		case 0:
			this.statusGivens = SudokuStatus.INVALID;
			break;
		case 1:
			this.statusGivens = SudokuStatus.VALID;
			break;
		default:
			this.statusGivens = SudokuStatus.MULTIPLE_SOLUTIONS;
			break;
		}
	}

	/**
	 * Checks, if user candidate have been set in the Sudoku. Needed for
	 * determining, how to switch between {@link #cells} and {@link #userCells}.
	 */
	public boolean userCandidatesEmpty() {
		for (int i = 0; i < this.userCells.length; i++) {
			if (this.userCells[i] != 0) {
				// at least one candidate has already been set
				return false;
			}
		}
		return true;
	}

	/**
	 * Switches from user candidates to all candidates: candidates already
	 * eliminated by the user stay eliminated. As a precaution, missing necessary
	 * candidates are added first. This will only work, if a solution has already
	 * been set. It is the responsibility of the caller to ensure that.
	 */
	public void switchToAllCandidates() {
		// first add necessary candidates (might not be necessary)
		for (int i = 0; i < this.userCells.length; i++) {
			if (this.values[i] == 0 && this.solution[i] != 0) {
				this.userCells[i] |= MASKS[this.solution[i]];
			}
		}
		// now simply copy the user candidates over
		System.arraycopy(this.userCells, 0, this.cells, 0, LENGTH);
		// rebuild internal data
		this.rebuildInternalData();
	}

	/**
	 * Reset {@link #cells} to all possible candidates.
	 */
	public void rebuildAllCandidates() {
		for (int i = 0; i < this.cells.length; i++) {
			if (this.values[i] != 0) {
				this.cells[i] = 0;
			} else {
				for (int cand = 1; cand <= 9; cand++) {
					if (this.isValidValue(i, cand)) {
						this.cells[i] |= MASKS[cand];
					}
				}
			}
		}
		this.rebuildInternalData();
	}

	/**
	 * Calculates, which candidates are still present in the unset cells of the
	 * sudoku.
	 */
	public short getRemainingCandidates() {
		short result = 0;
		for (int i = 0; i < this.cells.length; i++) {
			if (this.values[i] == 0) {
				result |= this.cells[i];
			}
		}
		return result;
	}
}
