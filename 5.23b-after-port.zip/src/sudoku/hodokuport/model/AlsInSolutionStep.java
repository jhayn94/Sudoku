/*
 * Copyright (C) 2008-12  Bernhard Hobiger
 *
 * This file is part of HoDoKu.
 *
 * HoDoKu is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * HoDoKu is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with HoDoKu. If not, see <http://www.gnu.org/licenses/>.
 */

package sudoku.hodokuport.model;

import java.util.ArrayList;
import java.util.List;

import sudoku.hodokuport.solver.Als;

public class AlsInSolutionStep implements Cloneable {
	private List<Integer> indices = new ArrayList<>();
	private List<Integer> candidates = new ArrayList<>();
	private int chainPenalty = -1;

	public AlsInSolutionStep() {
		// Nothing to do.
	}

	public void addIndex(final int index) {
		this.indices.add(index);
	}

	public void addCandidate(final int cand) {
		this.candidates.add(cand);
	}

	@Override
	@SuppressWarnings("unchecked")
	public Object clone() throws CloneNotSupportedException {
		final AlsInSolutionStep newAls = (AlsInSolutionStep) super.clone();
		newAls.indices = (List<Integer>) ((ArrayList<Integer>) this.indices).clone();
		newAls.candidates = (List<Integer>) ((ArrayList<Integer>) this.candidates).clone();
		return newAls;
	}

	public List<Integer> getIndices() {
		return this.indices;
	}

	public void setIndices(final List<Integer> indices) {
		this.indices = indices;
	}

	public List<Integer> getCandidates() {
		return this.candidates;
	}

	public void setCandidates(final List<Integer> candidates) {
		this.candidates = candidates;
	}

	public int getChainPenalty() {
		if (this.chainPenalty == -1) {
			this.chainPenalty = Als.getChainPenalty(this.indices.size());
		}
		return this.chainPenalty;
	}

	public void setChainPenalty(final int chainPenalty) {
		this.chainPenalty = chainPenalty;
	}
}
