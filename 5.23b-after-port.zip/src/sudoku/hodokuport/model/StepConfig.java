/*
 * Copyright (C) 2008-12  Bernhard Hobiger
 *
 * This file is part of HoDoKu.
 *
 * HoDoKu is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * HoDoKu is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with HoDoKu. If not, see <http://www.gnu.org/licenses/>.
 */

package sudoku.hodokuport.model;

public final class StepConfig implements Cloneable, Comparable<StepConfig> {
	private int index; // search order when solving
	private SolutionType type; // which step
	private int level; // Index in Options.difficultyLevels
	private SolutionCategory category; // which category (used for configuration)
	private int baseScore; // score for every instance of step in solution
	private int adminScore; // currently not used
	private boolean enabled; // used in solution?
	private boolean allStepsEnabled; // searched for when all steps are found?
	private int indexProgress; // search order when rating the efficiency of steps
	private boolean enabledProgress; // enabled when rating the efficiency of
																		// steps
	private boolean enabledTraining; // enabled for traing/practising mode

	/** Creates a new instance of StepConfig */
	public StepConfig() {
	}

	public StepConfig(final int index, final SolutionType type, final int level, final SolutionCategory category,
			final int baseScore, final int adminScore, final boolean enabled, final boolean allStepsEnabled,
			final int indexProgress, final boolean enabledProgress, final boolean enabledTraining) {
		this.setIndex(index);
		this.setType(type);
		this.setLevel(level);
		this.setCategory(category);
		this.setBaseScore(baseScore);
		this.setAdminScore(adminScore);
		this.setEnabled(enabled);
		this.setAllStepsEnabled(allStepsEnabled);
		this.setIndexProgress(indexProgress);
		this.setEnabledProgress(enabledProgress);
		this.setEnabledTraining(enabledTraining);
	}

	@Override
	public String toString() {
		return this.type.getStepName();
	}

	public SolutionType getType() {
		return this.type;
	}

	public static String getLevelName(final int level) {
		return Options.getInstance().getDifficultyLevels()[level].getName();
	}

	public static String getLevelName(final DifficultyLevel level) {
		return Options.getInstance().getDifficultyLevels()[level.getOrdinal()].getName();
	}

	public void setType(final SolutionType type) {
		this.type = type;
	}

	public int getLevel() {
		return this.level;
	}

	public void setLevel(final int level) {
		this.level = level;
	}

	public int getBaseScore() {
		return this.baseScore;
	}

	public void setBaseScore(final int baseScore) {
		this.baseScore = baseScore;
	}

	public int getAdminScore() {
		return this.adminScore;
	}

	public void setAdminScore(final int adminScore) {
		this.adminScore = adminScore;
	}

	public boolean isEnabled() {
		return this.enabled;
	}

	public void setEnabled(final boolean enabled) {
		this.enabled = enabled;
	}

	public SolutionCategory getCategory() {
		return this.category;
	}

	public void setCategory(final SolutionCategory category) {
		this.category = category;
	}

	public String getCategoryName() {
		return this.category.getCategoryName();
	}

	public int getIndex() {
		return this.index;
	}

	public void setIndex(final int index) {
		this.index = index;
	}

	@Override
	public int compareTo(final StepConfig o) {
		return this.index - o.getIndex();
	}

	public boolean isAllStepsEnabled() {
		return this.allStepsEnabled;
	}

	public void setAllStepsEnabled(final boolean allStepsEnabled) {
		this.allStepsEnabled = allStepsEnabled;
	}

	public int getIndexProgress() {
		return this.indexProgress;
	}

	public void setIndexProgress(final int indexProgress) {
		this.indexProgress = indexProgress;
	}

	public boolean isEnabledProgress() {
		return this.enabledProgress;
	}

	public void setEnabledProgress(final boolean enabledProgress) {
		this.enabledProgress = enabledProgress;
	}

	/**
	 * @return the enabledTraining
	 */
	public boolean isEnabledTraining() {
		return this.enabledTraining;
	}

	/**
	 * @param enabledTraining
	 *          the enabledTraining to set
	 */
	public void setEnabledTraining(final boolean enabledTraining) {
		this.enabledTraining = enabledTraining;
	}
}
