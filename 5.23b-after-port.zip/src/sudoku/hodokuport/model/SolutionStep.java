/*
 * Copyright (C) 2008-12  Bernhard Hobiger
 *
 * This file is part of HoDoKu.
 *
 * HoDoKu is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * HoDoKu is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with HoDoKu. If not, see <http://www.gnu.org/licenses/>.
 */
package sudoku.hodokuport.model;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.SortedMap;
import java.util.SortedSet;
import java.util.TreeMap;
import java.util.TreeSet;
import java.util.logging.Level;
import java.util.logging.Logger;

import sudoku.hodokuport.solver.Als;
import sudoku.hodokuport.solver.RestrictedCommon;
import sudoku.model.SudokuSet;

public class SolutionStep implements Comparable<SolutionStep>, Cloneable {

	private static final String NEW_LINE = "\r\n  ";
	private static final String UNKNOWN_ALS = "UNKNOWN ALS";
	private static final String INTL_SOLUTION_STEP = "intl/SolutionStep";
	private static final String[] entityNames = {
			java.util.ResourceBundle.getBundle(INTL_SOLUTION_STEP).getString("SolutionStep.block"),
			java.util.ResourceBundle.getBundle(INTL_SOLUTION_STEP).getString("SolutionStep.line"),
			java.util.ResourceBundle.getBundle(INTL_SOLUTION_STEP).getString("SolutionStep.col"),
			java.util.ResourceBundle.getBundle(INTL_SOLUTION_STEP).getString("SolutionStep.cell") };
	private static final String[] entityShortNames = { "b", "r", "c", "" };
	private static final DecimalFormat FISH_FORMAT = new DecimalFormat("#00");
	private SolutionType type;

	// For kraken fish: holds the underlying fish type
	private SolutionType subType;
	private int entity;
	private int entityNumber;
	private int entity2;
	private int entity2Number;
	private boolean isSiamese;
	private int progressScoreSingles = -1;
	private int progressScoreSinglesOnly = -1;
	private int progressScore = -1;
	private List<Integer> values = new ArrayList<>();
	private List<Integer> indices = new ArrayList<>();
	private List<Candidate> candidatesToDelete = new ArrayList<>();
	private List<Candidate> cannibalistic = new ArrayList<>();
	private List<Candidate> fins = new ArrayList<>();
	private List<Candidate> endoFins = new ArrayList<>();
	private List<Entity> baseEntities = new ArrayList<>();
	private List<Entity> coverEntities = new ArrayList<>();
	private List<Chain> chains = new ArrayList<Chain>();
	private List<AlsInSolutionStep> alses = new ArrayList<>();
	private SortedMap<Integer, Integer> colorCandidates = new TreeMap<>();
	private List<RestrictedCommon> restrictedCommons = new ArrayList<>();
	private SudokuSet potentialCannibalisticEliminations = new SudokuSet();
	private SudokuSet potentialEliminations = new SudokuSet();

	public SolutionStep() {
	}

	/**
	 * Creates a new instance of SolutionStep
	 *
	 * @param type
	 */
	public SolutionStep(final SolutionType type) {
		this.setType(type);
	}

	@Override
	@SuppressWarnings("unchecked")
	public Object clone() {
		SolutionStep newStep = null;
		try {
			newStep = (SolutionStep) super.clone();
			newStep.type = this.type;
			newStep.entity = this.entity;
			newStep.entityNumber = this.entityNumber;
			newStep.entity2 = this.entity2;
			newStep.entity2Number = this.entity2Number;
			newStep.isSiamese = this.isSiamese;
			newStep.progressScoreSingles = this.progressScoreSingles;
			newStep.progressScoreSinglesOnly = this.progressScoreSinglesOnly;
			newStep.progressScore = this.progressScore;
			newStep.values = (List<Integer>) ((ArrayList<Integer>) this.values).clone();
			newStep.indices = (List<Integer>) ((ArrayList<Integer>) this.indices).clone();
			newStep.candidatesToDelete = (List<Candidate>) ((ArrayList<Candidate>) this.candidatesToDelete).clone();
			newStep.cannibalistic = (List<Candidate>) ((ArrayList<Candidate>) this.cannibalistic).clone();
			newStep.fins = (List<Candidate>) ((ArrayList<Candidate>) this.fins).clone();
			newStep.endoFins = (List<Candidate>) ((ArrayList<Candidate>) this.endoFins).clone();
			newStep.baseEntities = (List<Entity>) ((ArrayList<Entity>) this.baseEntities).clone();
			newStep.coverEntities = (List<Entity>) ((ArrayList<Entity>) this.coverEntities).clone();
			newStep.chains = (List<Chain>) ((ArrayList<Chain>) this.chains).clone();
			newStep.alses = (List<AlsInSolutionStep>) ((ArrayList<AlsInSolutionStep>) this.alses).clone();
			newStep.colorCandidates = (SortedMap<Integer, Integer>) ((TreeMap<Integer, Integer>) this.getColorCandidates())
					.clone();
			newStep.restrictedCommons = (List<RestrictedCommon>) ((ArrayList<RestrictedCommon>) this.restrictedCommons)
					.clone();
			newStep.potentialCannibalisticEliminations = this.potentialCannibalisticEliminations.clone();
			newStep.potentialEliminations = this.potentialEliminations.clone();
		} catch (final CloneNotSupportedException ex) {
			Logger.getLogger(this.getClass().getName()).log(Level.SEVERE, "Error while cloning", ex);
		}

		return newStep;
	}

	public void reset() {
		this.type = SolutionType.HIDDEN_SINGLE;
		this.entity = 0;
		this.entityNumber = 0;
		this.entity2 = 0;
		this.entity2Number = 0;
		this.isSiamese = false;
		this.progressScoreSingles = -1;
		this.progressScoreSinglesOnly = -1;
		this.progressScore = -1;
		this.values.clear();
		this.indices.clear();
		this.candidatesToDelete.clear();
		this.cannibalistic.clear();
		this.fins.clear();
		this.endoFins.clear();
		this.baseEntities.clear();
		this.coverEntities.clear();
		this.chains.clear();
		this.alses.clear();
		this.colorCandidates.clear();
		this.restrictedCommons.clear();
		this.potentialCannibalisticEliminations.clear();
		this.potentialEliminations.clear();
	}

	public StringBuffer getForcingChainString(final Chain chain) {
		return this.getForcingChainString(chain.getChain(), chain.getStart(), chain.getEnd(), true);
	}

	public StringBuffer getForcingChainString(final int[] chain, final int start, final int end,
			final boolean weakLinks) {
		final StringBuffer tmp = new StringBuffer();
		boolean inMin = false;
		this.appendForcingChainEntry(tmp, chain[start]);
		for (int i = start + 1; i <= end - 1; i++) {
			boolean blank = true;
			if (chain[i] == Integer.MIN_VALUE) {
				tmp.append(")");
				inMin = false;
				continue;
			}
			if (!weakLinks && !Chain.isSStrong(chain[i])
					&& (chain[i] > 0 || chain[i] < 0 && chain[i + 1] < 0 && chain[i + 1] != Integer.MIN_VALUE)) {
				if (Chain.getSNodeType(chain[i]) == Chain.NORMAL_NODE) {
					continue;
				}
			}
			if (chain[i] < 0 && !inMin) {
				tmp.append(" (");
				inMin = true;
				blank = false;
			}
			if (chain[i] > 0 && inMin) {
				tmp.append(")");
				inMin = false;
			}
			if (blank) {
				tmp.append(" ");
			}
			this.appendForcingChainEntry(tmp, chain[i]);
		}
		tmp.append(" ");
		this.appendForcingChainEntry(tmp, chain[end]);
		return tmp;
	}

	public void appendForcingChainEntry(final StringBuffer buf, final int chainEntry) {
		final int entry = chainEntry < 0 ? -chainEntry : chainEntry;
		switch (Chain.getSNodeType(entry)) {
		case Chain.NORMAL_NODE:
			buf.append(getCellPrint(Chain.getSCellIndex(entry), false));
			break;
		case Chain.GROUP_NODE:
			buf.append(
					getCompactCellPrint(Chain.getSCellIndex(entry), Chain.getSCellIndex2(entry), Chain.getSCellIndex3(entry)));
			break;
		case Chain.ALS_NODE:
			final int alsIndex = Chain.getSCellIndex2(entry);
			if (alsIndex >= 0 && alsIndex < this.alses.size()) {
				buf.append("ALS:");
				this.getAls(buf, alsIndex, false);
			} else {
				buf.append(UNKNOWN_ALS);
			}
			break;
		default: // Nothing to do.
		}
		if (!Chain.isSStrong(entry)) {
			buf.append("<>");
		} else {
			buf.append("=");
		}
		buf.append(Chain.getSCandidate(entry));
	}

	public StringBuffer getChainString(final Chain chain) {
		return this.getChainString(chain.getChain(), chain.getStart(), chain.getEnd(), false, true, true, false);
	}

	public StringBuffer getChainString(final Chain chain, final boolean internalFormat) {
		return this.getChainString(chain.getChain(), chain.getStart(), chain.getEnd(), true, true, true, internalFormat);
	}

	public StringBuffer getChainString(final int[] chain, final int start, final int end, final boolean alternate,
			final boolean up) {
		return this.getChainString(chain, start, end, alternate, up, true, false);
	}

	public StringBuffer getChainString(final int[] chain, final int start, final int end, final boolean alternate,
			final boolean up, final boolean asNiceLoop, final boolean internalFormat) {
		final StringBuffer tmp = new StringBuffer();
		boolean isStrong = false;
		int lastIndex = -1;
		if (up) {
			for (int i = start; i <= end; i++) {
				if (internalFormat) {
					if (i > start) {
						tmp.append("-");
					}
					tmp.append(chain[i]);
				} else {
					if (i == start + 1) {
						isStrong = Chain.isSStrong(chain[i]);
					} else {
						isStrong = !isStrong;
					}
					if (asNiceLoop && Chain.getSCellIndex(chain[i]) == lastIndex) {
						continue;
					} else {
						lastIndex = Chain.getSCellIndex(chain[i]);
					}
					if (i > start) {
						final int cand = Chain.getSCandidate(chain[i]);
						if (!Chain.isSStrong(chain[i]) || (alternate && !isStrong)) {
							tmp.append(" -");
							tmp.append(cand);
							tmp.append("- ");
						} else {
							tmp.append(" =");
							tmp.append(cand);
							tmp.append("= ");
						}
					}
					switch (Chain.getSNodeType(chain[i])) {
					case Chain.NORMAL_NODE:
						tmp.append(getCellPrint(Chain.getSCellIndex(chain[i]), false));
						break;
					case Chain.GROUP_NODE:
						tmp.append(getCompactCellPrint(Chain.getSCellIndex(chain[i]), Chain.getSCellIndex2(chain[i]),
								Chain.getSCellIndex3(chain[i])));
						break;
					case Chain.ALS_NODE:
						final int alsIndex = Chain.getSCellIndex2(chain[i]);
						if (alsIndex < this.alses.size()) {
							tmp.append("ALS:");
							this.getAls(tmp, alsIndex, false);
						} else {
							tmp.append(UNKNOWN_ALS);
						}
						break;
					default:
						tmp.append("INV");
					}
				}
			}
		} else {
			for (int i = end; i >= start; i--) {
				if (internalFormat) {
					if (i > start) {
						tmp.append("-");
					}
					tmp.append(chain[i]);
				} else {
					if (i == end - 1) {
						isStrong = Chain.isSStrong(chain[i + 1]);
					} else {
						isStrong = !isStrong;
					}
					if (Chain.getSCellIndex(chain[i + 1]) == lastIndex) {
						continue;
					} else {
						lastIndex = Chain.getSCellIndex(chain[i + 1]);
					}
					if (i < end) {
						final int cand = Chain.getSCandidate(chain[i]);
						if (!Chain.isSStrong(chain[i + 1]) || (alternate && !isStrong)) {
							tmp.append(" -");
							tmp.append(cand);
							tmp.append("- ");
						} else {
							tmp.append(" =");
							tmp.append(cand);
							tmp.append("= ");
						}
					}
					switch (Chain.getSNodeType(chain[i])) {
					case Chain.NORMAL_NODE:
						tmp.append(getCellPrint(Chain.getSCellIndex(chain[i]), false));
						break;
					case Chain.GROUP_NODE:
						tmp.append(getCompactCellPrint(Chain.getSCellIndex(chain[i]), Chain.getSCellIndex2(chain[i]),
								Chain.getSCellIndex3(chain[i])));
						break;
					case Chain.ALS_NODE:
						final int alsIndex = Chain.getSCellIndex2(chain[i]);
						if (alsIndex < this.alses.size()) {
							tmp.append("ALS:");
							this.getAls(tmp, alsIndex, false);
						} else {
							tmp.append(UNKNOWN_ALS);
						}
						break;
					default: // Nothing to do.
					}
				}
			}
		}
		return tmp;
	}

	/**
	 * indices and values hold candidates, that should be marked or set; the two
	 * lists are not necessarily of the same length. The method has to return all
	 * combinations of values and indices.
	 *
	 * @return A string containing all combinations of values and indices in
	 *         library format
	 */
	public String getValueIndexString() {
		final StringBuilder tmp = new StringBuilder();
		for (int i = 0; i < this.values.size(); i++) {
			final int value = this.values.get(i);
			for (int j = 0; j < this.indices.size(); j++) {
				final int index = this.indices.get(j);
				tmp.append(value);
				tmp.append(Integer.toString(Sudoku2.getLine(index) + 1));
				tmp.append(Integer.toString(Sudoku2.getCol(index) + 1));
				tmp.append(" ");
			}
		}
		return tmp.toString().trim();
	}

	public String getSingleCandidateString() {
		return this.getStepName() + ": " + getCompactCellPrint(this.indices) + "=" + this.values.get(0);
	}

	public String getCandidateString() {
		return this.getCandidateString(false, false);
	}

	public String getCandidateString(final boolean library) {
		return this.getCandidateString(library, false);
	}

	public String getCandidateString(final boolean library, final boolean statistics) {
		Collections.sort(this.candidatesToDelete);
		this.eliminateDoubleCandidatesToDelete();
		final StringBuilder candBuff = new StringBuilder();
		int lastCand = -1;
		StringBuffer delPos = new StringBuffer();
		for (final Candidate cand : this.candidatesToDelete) {
			if (cand.getValue() != lastCand) {
				if (lastCand != -1) {
					candBuff.append("/");
				}
				candBuff.append(cand.getValue());
				lastCand = cand.getValue();
			}
			delPos.append(" ");
			if (library) {
				delPos.append(Integer.toString(cand.getValue())).append(Integer.toString(Sudoku2.getLine(cand.getIndex()) + 1))
						.append(Integer.toString(Sudoku2.getCol(cand.getIndex()) + 1));
			}
		}
		if (library) {
			return delPos.toString().trim();
		} else {
			delPos = new StringBuffer();
			this.getCandidatesToDelete(delPos);
			delPos.delete(0, 4);
			if (statistics) {
				return candBuff.toString() + " (" + this.getAnzCandidatesToDelete() + ")" + " (0/0)";
			} else {
				String tmpStepName = this.getStepName();
				if (this.isSiamese) {
					tmpStepName = java.util.ResourceBundle.getBundle(INTL_SOLUTION_STEP).getString("SolutionStep.siamese") + " "
							+ this.getStepName();
				}
				return candBuff.toString() + " (" + this.getAnzCandidatesToDelete() + "):" + delPos.toString() + " ("
						+ tmpStepName + ")";
			}
		}
	}

	private void eliminateDoubleCandidatesToDelete() {
		final Set<Candidate> candSet = new TreeSet<>();
		for (int i = 0; i < this.candidatesToDelete.size(); i++) {
			candSet.add(this.candidatesToDelete.get(i));
		}
		this.candidatesToDelete.clear();
		for (final Candidate cand : candSet) {
			this.candidatesToDelete.add(cand);
		}
	}

	public static String getCellPrint(final int index) {
		return getCellPrint(index, true);
	}

	public static String getCellPrint(final int index, final boolean withParen) {
		if (withParen) {
			return "[r" + (Sudoku2.getLine(index) + 1) + "c" + (Sudoku2.getCol(index) + 1) + "]";
		} else {
			return "r" + (Sudoku2.getLine(index) + 1) + "c" + (Sudoku2.getCol(index) + 1);
		}
	}

	public static String getCompactCellPrint(final int index1, final int index2, final int index3) {
		final TreeSet<Integer> tmpSet = new TreeSet<>();
		tmpSet.add(index1);
		tmpSet.add(index2);
		if (index3 != -1) {
			tmpSet.add(index3);
		}
		return getCompactCellPrint(tmpSet);
	}

	public static String getCompactCellPrint(final SudokuSet set) {
		final TreeSet<Integer> tmpSet = new TreeSet<>();
		for (int i = 0; i < set.size(); i++) {
			tmpSet.add(set.get(i));
		}
		return getCompactCellPrint(tmpSet);
	}

	public static String getCompactCellPrint(final List<Integer> indices) {
		return getCompactCellPrint(indices, 0, indices.size() - 1);
	}

	public static String getCompactCellPrint(final List<Integer> indices, final int start, final int end) {
		final TreeSet<Integer> tmpSet = new TreeSet<>();
		for (int i = start; i <= end; i++) {
			tmpSet.add(indices.get(i));
		}
		return getCompactCellPrint(tmpSet);
	}

	public static String getCompactCellPrint(final TreeSet<Integer> tmpSet) {
		final StringBuilder tmp = new StringBuilder();
		boolean first = true;
		while (!tmpSet.isEmpty()) {
			final int index = tmpSet.pollFirst();
			final int line = Sudoku2.getLine(index);
			final int col = Sudoku2.getCol(index);
			int anzLines = 1;
			int anzCols = 1;
			if (first) {
				first = false;
			} else {
				tmp.append(",");
			}
			tmp.append(getCellPrint(index));
			final Iterator<Integer> it = tmpSet.iterator();
			while (it.hasNext()) {
				final int i1 = it.next();
				final int l1 = Sudoku2.getLine(i1);
				final int c1 = Sudoku2.getCol(i1);
				if (l1 == line && anzLines == 1) {
					final int pIndex = tmp.lastIndexOf("]");
					tmp.insert(pIndex, c1 + 1);
					it.remove();
					anzCols++;
				} else if (c1 == col && anzCols == 1) {
					final int pIndex = tmp.lastIndexOf("c");
					tmp.insert(pIndex, l1 + 1);
					it.remove();
					anzLines++;
				}
			}
		}
		int index = 0;
		while ((index = tmp.indexOf("[")) != -1) {
			tmp.deleteCharAt(index);
		}
		while ((index = tmp.indexOf("]")) != -1) {
			tmp.deleteCharAt(index);
		}
		return tmp.toString();
	}

	public final void setType(final SolutionType type) {
		boolean found = false;
		for (final SolutionType t : SolutionType.values()) {
			if (t == type) {
				found = true;
				break;
			}
		}
		if (!found) {
			throw new RuntimeException(
					java.util.ResourceBundle.getBundle(INTL_SOLUTION_STEP).getString("SolutionStep.invalid_setType") + " (" + type
							+ ")");
		}
		this.type = type;
	}

	public void addValue(final int value) {
		if (value < 1 || value > 9) {
			throw new RuntimeException(
					java.util.ResourceBundle.getBundle(INTL_SOLUTION_STEP).getString("SolutionStep.invalid_setValue") + " ("
							+ value + ")");
		}
		this.values.add(value);
	}

	public void addIndex(final int index) {
		if (index < 0 || index > 80) {
			throw new RuntimeException(
					java.util.ResourceBundle.getBundle(INTL_SOLUTION_STEP).getString("SolutionStep.invalid_setIndex") + " ("
							+ index + ")");
		}
		this.indices.add(index);
	}

	public void addCandidateToDelete(final Candidate cand) {
		this.candidatesToDelete.add(cand);
	}

	public void addCandidateToDelete(final int index, final int candidate) {
		this.candidatesToDelete.add(new Candidate(index, candidate));
	}

	public void addCannibalistic(final Candidate cand) {
		this.cannibalistic.add(cand);
	}

	public void addCannibalistic(final int index, final int candidate) {
		this.cannibalistic.add(new Candidate(index, candidate));
	}

	public void addFin(final int index, final int candidate) {
		this.addFin(new Candidate(index, candidate));
	}

	public void addFin(final Candidate fin) {
		this.fins.add(fin);
	}

	public void addEndoFin(final int index, final int candidate) {
		this.endoFins.add(new Candidate(index, candidate));
	}

	public int getAnzCandidatesToDelete() {
		SortedSet<Candidate> tmpSet = new TreeSet<>();
		for (int i = 0; i < this.candidatesToDelete.size(); i++) {
			tmpSet.add(this.candidatesToDelete.get(i));
		}
		final int anz = tmpSet.size();
		tmpSet.clear();
		tmpSet = null;
		return anz;
	}

	public int getAnzSet() {
		if (this.type.isSingle()) {
			return 1;
		}
		if (this.type == SolutionType.FORCING_CHAIN || this.type == SolutionType.FORCING_CHAIN_CONTRADICTION
				|| this.type == SolutionType.FORCING_CHAIN_VERITY || this.type == SolutionType.FORCING_NET
				|| this.type == SolutionType.FORCING_NET_CONTRADICTION || this.type == SolutionType.FORCING_NET_VERITY) {
			if (!this.indices.isEmpty()) {
				return 1;
			}
		}
		if (this.type == SolutionType.TEMPLATE_SET) {
			return this.indices.size();
		}
		return 0;
	}

	public SolutionType getType() {
		return this.type;
	}

	public List<Integer> getValues() {
		return this.values;
	}

	public List<Integer> getIndices() {
		return this.indices;
	}

	public List<Candidate> getCandidatesToDelete() {
		return this.candidatesToDelete;
	}

	public List<Candidate> getCannibalistic() {
		return this.cannibalistic;
	}

	public List<Candidate> getFins() {
		return this.fins;
	}

	public List<Candidate> getEndoFins() {
		return this.endoFins;
	}

	public String getStepName() {
		return this.type.getStepName();
	}

	public static String getStepName(final SolutionType type) {
		return type.getStepName();
	}

	public static String getStepName(final int type) {
		return SolutionType.values()[type].getStepName();
	}

	public String getEntityName(final int name) {
		return entityNames[name];
	}

	public String getEntityShortName(final int name) {
		return entityShortNames[name];
	}

	public String getEntityName() {
		return entityNames[this.entity];
	}

	public String getEntityName2() {
		return entityNames[this.entity2];
	}

	public String getEntityShortName() {
		return entityShortNames[this.entity];
	}

	public String getEntityShortNameNumber() {
		if (this.entity == Sudoku2.CELL) {
			return getCellPrint(this.entityNumber, false);
		} else {
			return entityShortNames[this.entity] + Integer.toString(this.entityNumber + 1);
		}
	}

	public String getEntityShortName2() {
		return entityShortNames[this.entity2];
	}

	@Override
	public String toString() {
		return this.toString(2);
	}

	public String toString(final int art) {
		String str = null;
		int index = 0;
		StringBuffer tmp;
		switch (this.type) {
		case FULL_HOUSE:
		case HIDDEN_SINGLE:
		case NAKED_SINGLE:
			index = this.indices.get(0);
			str = this.getStepName();
			if (art == 1) {
				str += ": " + this.values.get(0);
			} else if (art == 2) {
				str += ": " + getCellPrint(index, false) + "=" + this.values.get(0);
			}
			break;
		case HIDDEN_QUADRUPLE:
		case NAKED_QUADRUPLE:
		case HIDDEN_TRIPLE:
		case NAKED_TRIPLE:
		case LOCKED_TRIPLE:
		case HIDDEN_PAIR:
		case NAKED_PAIR:
		case LOCKED_PAIR:
			str = this.getStepName();
			tmp = new StringBuffer(str);
			if (art >= 1) {
				tmp.append(": ");
				if (this.type == SolutionType.HIDDEN_PAIR || this.type == SolutionType.NAKED_PAIR
						|| this.type == SolutionType.LOCKED_PAIR) {
					tmp.append(this.values.get(0));
					tmp.append(",");
					tmp.append(this.values.get(1));
				} else if (this.type == SolutionType.HIDDEN_TRIPLE || this.type == SolutionType.NAKED_TRIPLE
						|| this.type == SolutionType.LOCKED_TRIPLE) {
					tmp.append(this.values.get(0));
					tmp.append(",");
					tmp.append(this.values.get(1));
					tmp.append(",");
					tmp.append(this.values.get(2));
				} else if (this.type == SolutionType.HIDDEN_QUADRUPLE || this.type == SolutionType.NAKED_QUADRUPLE) {
					tmp.append(this.values.get(0));
					tmp.append(",");
					tmp.append(this.values.get(1));
					tmp.append(",");
					tmp.append(this.values.get(2));
					tmp.append(",");
					tmp.append(this.values.get(3));
				}
			}
			if (art >= 2) {
				tmp.append(" ");
				tmp.append(java.util.ResourceBundle.getBundle(INTL_SOLUTION_STEP).getString("SolutionStep.in"));
				tmp.append(" ");
				tmp.append(getCompactCellPrint(this.indices));
				this.getCandidatesToDelete(tmp);
			}
			str = tmp.toString();
			break;
		case LOCKED_CANDIDATES:
		case LOCKED_CANDIDATES_1:
		case LOCKED_CANDIDATES_2:
			str = this.getStepName();
			if (art >= 1) {
				str += ": " + this.values.get(0);
			}
			if (art >= 2) {
				str += " " + java.util.ResourceBundle.getBundle(INTL_SOLUTION_STEP).getString("SolutionStep.in") + " "
						+ this.getEntityShortName() + this.getEntityNumber();
				tmp = new StringBuffer(str);
				this.getCandidatesToDelete(tmp);
				str = tmp.toString();
			}
			break;
		case SKYSCRAPER:
		case TWO_STRING_KITE:
		case DUAL_TWO_STRING_KITE:
			str = this.getStepName();
			if (art >= 1) {
				str += ": " + this.values.get(0);
			}
			if (art >= 2) {
				str += " " + java.util.ResourceBundle.getBundle(INTL_SOLUTION_STEP).getString("SolutionStep.in") + " "
						+ getCompactCellPrint(this.indices, 0, 1);
				if (this.type == SolutionType.DUAL_TWO_STRING_KITE) {
					str += "/" + java.util.ResourceBundle.getBundle(INTL_SOLUTION_STEP).getString("SolutionStep.in") + " "
							+ getCompactCellPrint(this.indices, 4, 5);
				}
				str += " (" + java.util.ResourceBundle.getBundle(INTL_SOLUTION_STEP).getString("SolutionStep.connected_by")
						+ " " + getCompactCellPrint(this.indices, 2, 3) + ")";
				tmp = new StringBuffer(str);
				this.getCandidatesToDelete(tmp);
				str = tmp.toString();
			}
			break;
		case EMPTY_RECTANGLE:
		case DUAL_EMPTY_RECTANGLE:
			str = this.getStepName();
			if (art >= 1) {
				str += ": " + this.values.get(0);
			}
			if (art >= 2) {
				str += " " + java.util.ResourceBundle.getBundle(INTL_SOLUTION_STEP).getString("SolutionStep.in") + " "
						+ this.getEntityShortName() + this.getEntityNumber() + " (" + getCompactCellPrint(this.indices, 0, 1);
				if (this.type == SolutionType.DUAL_EMPTY_RECTANGLE) {
					str += "/" + getCompactCellPrint(this.indices, 2, 3);
				}
				str += ")";
				tmp = new StringBuffer(str);
				this.getCandidatesToDelete(tmp);
				str = tmp.toString();
			}
			break;
		case W_WING:
			str = this.getStepName();
			if (art >= 1) {
				str += ": " + this.values.get(0) + "/" + this.values.get(1);
			}
			if (art >= 2) {
				tmp = new StringBuffer(str);
				tmp.append(" ");
				tmp.append(java.util.ResourceBundle.getBundle(INTL_SOLUTION_STEP).getString("SolutionStep.in"));
				tmp.append(" ");
				tmp.append(getCompactCellPrint(this.indices, 0, 1));
				tmp.append(" ");
				tmp.append(java.util.ResourceBundle.getBundle(INTL_SOLUTION_STEP).getString("SolutionStep.connected_by"));
				tmp.append(" ");
				tmp.append(this.values.get(1));
				tmp.append(" ");
				tmp.append(java.util.ResourceBundle.getBundle(INTL_SOLUTION_STEP).getString("SolutionStep.in"));
				tmp.append(" ");
				this.getFinSet(tmp, this.fins, false);
				this.getCandidatesToDelete(tmp);
				str = tmp.toString();
			}
			break;
		case XY_WING:
		case XYZ_WING:
			str = this.getStepName();
			if (art >= 1) {
				str += ": " + this.values.get(0) + "/" + this.values.get(1);
			}
			if (art >= 2) {
				str += "/" + this.values.get(2) + " "
						+ java.util.ResourceBundle.getBundle(INTL_SOLUTION_STEP).getString("SolutionStep.in") + " "
						+ getCompactCellPrint(this.indices);
				tmp = new StringBuffer(str);
				this.getCandidatesToDelete(tmp);
				str = tmp.toString();
			}
			break;
		case SIMPLE_COLORS:
		case SIMPLE_COLORS_TRAP:
		case SIMPLE_COLORS_WRAP:
		case MULTI_COLORS:
		case MULTI_COLORS_1:
		case MULTI_COLORS_2:
			str = this.getStepName();
			if (art >= 1) {
				str += ": " + this.values.get(0);
			}
			if (art >= 2) {
				tmp = new StringBuffer(str);
				this.getColorCellPrint(tmp);
				this.getCandidatesToDelete(tmp);
				str = tmp.toString();
			}
			break;
		case X_CHAIN:
		case XY_CHAIN:
		case REMOTE_PAIR:
		case TURBOT_FISH:
		case NICE_LOOP:
		case CONTINUOUS_NICE_LOOP:
		case DISCONTINUOUS_NICE_LOOP:
		case GROUPED_NICE_LOOP:
		case GROUPED_CONTINUOUS_NICE_LOOP:
		case GROUPED_DISCONTINUOUS_NICE_LOOP:
		case AIC:
		case GROUPED_AIC:
			str = this.getStepName();
			if (art >= 1) {
				if (this.type == SolutionType.REMOTE_PAIR) {
					str += ": " + this.values.get(0) + "/" + this.values.get(1);
				} else {
					str += ": " + this.getCandidatesToDeleteDigits();
				}
			}
			if (art >= 2) {
				final StringBuffer tmpChain = this.getChainString(this.getChains().get(0));
				// adjust nice loop notation
				if (this.type == SolutionType.CONTINUOUS_NICE_LOOP || this.type == SolutionType.GROUPED_CONTINUOUS_NICE_LOOP) {
					final Chain ch = this.getChains().get(0);
					int start = ch.getStart();
					int cellIndex = ch.getCellIndex(start);
					while (ch.getCellIndex(start) == cellIndex) {
						start++;
					}
					int end = ch.getEnd();
					cellIndex = ch.getCellIndex(end);
					while (ch.getCellIndex(end) == cellIndex) {
						end--;
					}
					end++;
					tmpChain.insert(0, ch.getCandidate(end) + "= ");
					tmpChain.append(" =").append(ch.getCandidate(start));
				}
				if (this.type == SolutionType.AIC || this.type == SolutionType.GROUPED_AIC
						|| this.type == SolutionType.XY_CHAIN) {
					final Chain ch = this.getChains().get(0);
					tmpChain.insert(0, ch.getCandidate(ch.getStart()) + "- ");
					tmpChain.append(" -").append(ch.getCandidate(ch.getEnd()));
				}
				str += " " + tmpChain;
				tmp = new StringBuffer(str);
				this.getCandidatesToDelete(tmp);
				str = tmp.toString();
			}
			break;
		case FORCING_CHAIN:
		case FORCING_CHAIN_CONTRADICTION:
		case FORCING_CHAIN_VERITY:
		case FORCING_NET:
		case FORCING_NET_CONTRADICTION:
		case FORCING_NET_VERITY:
			str = this.getStepName();
			if (art >= 2) {
				if (this.type == SolutionType.FORCING_CHAIN_CONTRADICTION
						|| this.type == SolutionType.FORCING_NET_CONTRADICTION) {
					str += " " + java.util.ResourceBundle.getBundle(INTL_SOLUTION_STEP).getString("SolutionStep.in") + " "
							+ this.getEntityShortNameNumber();
				}
				if (!this.indices.isEmpty()) {
					str += " => " + getCellPrint(this.indices.get(0), false) + "=" + this.values.get(0);
				} else {
					tmp = new StringBuffer(str);
					this.getCandidatesToDelete(tmp);
					str = tmp.toString();
				}
				for (int i = 0; i < this.chains.size(); i++) {
					str += NEW_LINE + this.getForcingChainString(this.getChains().get(i));
				}
			}
			break;
		case UNIQUENESS_1:
		case UNIQUENESS_2:
		case UNIQUENESS_3:
		case UNIQUENESS_4:
		case UNIQUENESS_5:
		case UNIQUENESS_6:
		case HIDDEN_RECTANGLE:
		case AVOIDABLE_RECTANGLE_1:
		case AVOIDABLE_RECTANGLE_2:
			str = this.getStepName();
			if (art >= 1) {
				str += ": " + this.values.get(0) + "/" + this.values.get(1);
			}
			if (art >= 2) {
				str += " in " + getCompactCellPrint(this.indices);
				tmp = new StringBuffer(str);
				this.getCandidatesToDelete(tmp);
				str = tmp.toString();
			}
			break;
		case BUG_PLUS_1:
			str = this.getStepName();
			if (art >= 2) {
				tmp = new StringBuffer(str);
				this.getCandidatesToDelete(tmp);
				str = tmp.toString();
			}
			break;
		case X_WING:
		case SWORDFISH:
		case JELLYFISH:
		case SQUIRMBAG:
		case WHALE:
		case LEVIATHAN:
		case FINNED_X_WING:
		case FINNED_SWORDFISH:
		case FINNED_JELLYFISH:
		case FINNED_SQUIRMBAG:
		case FINNED_WHALE:
		case FINNED_LEVIATHAN:
		case SASHIMI_X_WING:
		case SASHIMI_SWORDFISH:
		case SASHIMI_JELLYFISH:
		case SASHIMI_SQUIRMBAG:
		case SASHIMI_WHALE:
		case SASHIMI_LEVIATHAN:
		case FRANKEN_X_WING:
		case FRANKEN_SWORDFISH:
		case FRANKEN_JELLYFISH:
		case FRANKEN_SQUIRMBAG:
		case FRANKEN_WHALE:
		case FRANKEN_LEVIATHAN:
		case FINNED_FRANKEN_X_WING:
		case FINNED_FRANKEN_SWORDFISH:
		case FINNED_FRANKEN_JELLYFISH:
		case FINNED_FRANKEN_SQUIRMBAG:
		case FINNED_FRANKEN_WHALE:
		case FINNED_FRANKEN_LEVIATHAN:
		case MUTANT_X_WING:
		case MUTANT_SWORDFISH:
		case MUTANT_JELLYFISH:
		case MUTANT_SQUIRMBAG:
		case MUTANT_WHALE:
		case MUTANT_LEVIATHAN:
		case FINNED_MUTANT_X_WING:
		case FINNED_MUTANT_SWORDFISH:
		case FINNED_MUTANT_JELLYFISH:
		case FINNED_MUTANT_SQUIRMBAG:
		case FINNED_MUTANT_WHALE:
		case FINNED_MUTANT_LEVIATHAN:
		case KRAKEN_FISH:
		case KRAKEN_FISH_TYPE_1:
		case KRAKEN_FISH_TYPE_2:
			tmp = new StringBuffer();
			if (this.isSiamese) {
				tmp.append(java.util.ResourceBundle.getBundle(INTL_SOLUTION_STEP).getString("SolutionStep.siamese"))
						.append(" ");
			}
			tmp.append(this.getStepName());
			if (art >= 1) {
				if (this.type.isKrakenFish()) {
					tmp.append(": ");
					this.getCandidatesToDelete(tmp);
					tmp.append(NEW_LINE).append(this.subType.getStepName());
				}
				tmp.append(": ").append(this.values.get(0));
			}
			if (art >= 2) {
				tmp.append(" ");
				this.getEntities(tmp, this.baseEntities, true, false);
				tmp.append(" ");
				this.getEntities(tmp, this.coverEntities, true, true);
				int displayMode = Options.getInstance().getFishDisplayMode();
				if (this.type.isKrakenFish()) {
					// no statistics
					displayMode = 0;
				}
				switch (displayMode) {
				case 0:
					if (!this.fins.isEmpty()) {
						tmp.append(" ");
						this.getFins(tmp, false, true);
					}
					if (!this.endoFins.isEmpty()) {
						tmp.append(" ");
						this.getFins(tmp, true, true);
					}
					break;
				case 1:
					this.getFishStatistics(tmp, false);
					break;
				case 2:
					this.getFishStatistics(tmp, true);
					break;
				default: // Nothing to do.
				}
				if (!this.type.isKrakenFish()) {
					this.getCandidatesToDelete(tmp);
				}
			}
			if (this.type.isKrakenFish()) {
				for (int i = 0; i < this.chains.size(); i++) {
					tmp.append(NEW_LINE).append(this.getChainString(this.chains.get(i)));
				}
			}
			str = tmp.toString();
			break;
		case SUE_DE_COQ:
			str = this.getStepName();
			tmp = new StringBuffer(str + ": ");
			if (art >= 1) {
				this.getIndexValueSet(tmp);
				str = tmp.toString();
			}
			if (art >= 2) {
				tmp.append(" (");
				this.getFinSet(tmp, this.fins);
				tmp.append(", ");
				this.getFinSet(tmp, this.endoFins);
				tmp.append(")");
				this.getCandidatesToDelete(tmp);
				str = tmp.toString();
			}
			break;
		case ALS_XZ:
			str = this.getStepName();
			tmp = new StringBuffer(str + ": ");
			if (art >= 1) {
				tmp.append("A=");
				this.getAls(tmp, 0);
				str = tmp.toString();
			}
			if (art >= 2) {
				tmp.append(", B=");
				this.getAls(tmp, 1);
				tmp.append(", X=");
				this.getAlsXorZ(tmp, true);
				if (!this.fins.isEmpty()) {
					tmp.append(", Z=");
					this.getAlsXorZ(tmp, false);
				}
				this.getCandidatesToDelete(tmp);
				str = tmp.toString();
			}
			break;
		case ALS_XY_WING:
			str = this.getStepName();
			if (art == 1) {
				tmp = new StringBuffer(str + ": ");
				tmp.append("C=");
				this.getAls(tmp, 2);
				str = tmp.toString();
			}
			if (art >= 2) {
				tmp = new StringBuffer(str + ": ");
				tmp.append("A=");
				this.getAls(tmp, 0);
				tmp.append(", B=");
				this.getAls(tmp, 1);
				tmp.append(", C=");
				this.getAls(tmp, 2);
				tmp.append(", X,Y=");
				this.getAlsXorZ(tmp, true);
				tmp.append(", Z=");
				this.getAlsXorZ(tmp, false);
				this.getCandidatesToDelete(tmp);
				str = tmp.toString();
			}
			break;
		case ALS_XY_CHAIN:
			str = this.getStepName();
			if (this.restrictedCommons.isEmpty()) {
				// old code -> has to remain for correctly displaying saved files
				if (art == 1) {
					tmp = new StringBuffer(str + ": ");
					tmp.append(java.util.ResourceBundle.getBundle(INTL_SOLUTION_STEP).getString("SolutionStep.start"))
							.append("=");
					this.getAls(tmp, 0);
					tmp.append(", ").append(java.util.ResourceBundle.getBundle(INTL_SOLUTION_STEP).getString("SolutionStep.end"))
							.append("=");
					this.getAls(tmp, this.alses.size() - 1);
					str = tmp.toString();
				}
				if (art >= 2) {
					tmp = new StringBuffer(str + ": ");
					char alsChar = 'A';
					boolean first = true;
					for (int i = 0; i < this.alses.size(); i++) {
						if (first) {
							first = false;
						} else {
							tmp.append(", ");
						}
						tmp.append(alsChar++);
						tmp.append("=");
						this.getAls(tmp, i);
					}
					tmp.append(", RCs=");
					this.getAlsXorZ(tmp, true);
					tmp.append(", X=");
					this.getAlsXorZ(tmp, false);
					this.getCandidatesToDelete(tmp);
					str = tmp.toString();
				}
			} else {
				if (art == 1) {
					tmp = new StringBuffer(str + ": ");
					tmp.append(java.util.ResourceBundle.getBundle(INTL_SOLUTION_STEP).getString("SolutionStep.start"))
							.append("=");
					this.getAls(tmp, 0);
					tmp.append(", ").append(java.util.ResourceBundle.getBundle(INTL_SOLUTION_STEP).getString("SolutionStep.end"))
							.append("=");
					this.getAls(tmp, this.alses.size() - 1);
					str = tmp.toString();
				}
				if (art >= 2) {
					tmp = new StringBuffer(str + ": ");
					this.getCandidatesToDeleteDigits(tmp);
					tmp.append("- ");
					for (int i = 0; i < this.alses.size(); i++) {
						this.getAls(tmp, i);
						if (i < this.restrictedCommons.size()) {
							this.getRestrictedCommon(this.restrictedCommons.get(i), tmp);
						}
					}
					tmp.append(" -");
					this.getCandidatesToDeleteDigits(tmp);
					this.getCandidatesToDelete(tmp);
					str = tmp.toString();
				}
			}
			break;
		case DEATH_BLOSSOM:
			str = this.getStepName();
			tmp = new StringBuffer(str + ": ");
			if (art >= 1) {
				tmp.append(getCellPrint(this.indices.get(0)));
				str = tmp.toString();
			}
			if (art >= 2) {
				for (int i = 0; i < this.alses.size(); i++) {
					tmp.append(", ");
					this.getRestrictedCommon(this.restrictedCommons.get(i), tmp);
					this.getAls(tmp, i);
				}
				this.getCandidatesToDelete(tmp);
				str = tmp.toString();
			}
			break;
		case TEMPLATE_SET:
		case BRUTE_FORCE:
			str = this.getStepName();
			if (art == 1) {
				str += ": " + this.values.get(0);
			}
			if (art >= 2) {
				tmp = new StringBuffer(str + ": ");
				tmp.append(getCompactCellPrint(this.indices)).append("=").append(this.values.get(0));
				str = tmp.toString();
			}
			break;
		case TEMPLATE_DEL:
			str = this.getStepName();
			if (art >= 2) {
				tmp = new StringBuffer(str + ": ");
				this.getCandidatesToDelete(tmp);
				str = tmp.toString();
			}
			break;
		case INCOMPLETE:
			str = java.util.ResourceBundle.getBundle(INTL_SOLUTION_STEP).getString("SolutionStep.incomplete_solution");
			break;
		case GIVE_UP:
			tmp = new StringBuffer();
			tmp.append(this.getStepName());
			if (art >= 1) {
				tmp.append(": ")
						.append(java.util.ResourceBundle.getBundle(INTL_SOLUTION_STEP).getString("SolutionStep.dont_know"));
			}
			str = tmp.toString();
			break;
		default:
			throw new RuntimeException(
					java.util.ResourceBundle.getBundle(INTL_SOLUTION_STEP).getString("SolutionStep.invalid_type") + " ("
							+ this.type + ")!");
		}
		return str;
	}

	/**
	 * Gets information about vertices, fins, eliminations...
	 */
	private void getFishStatistics(final StringBuffer tmp, final boolean cells) {
		tmp.append(" ");
		final SudokuSet set = new SudokuSet();
		// Vertices: all indices minus potential cannibalistic eliminations
		for (int i = 0; i < this.indices.size(); i++) {
			set.add(this.indices.get(i));
		}
		set.andNot(this.potentialCannibalisticEliminations);
		this.appendFishData(tmp, set, "V", cells);
		// exo fins
		set.clear();
		for (int i = 0; i < this.fins.size(); i++) {
			set.add(this.fins.get(i).getIndex());
		}
		for (int i = 0; i < this.endoFins.size(); i++) {
			set.remove(this.endoFins.get(i).getIndex());
		}
		this.appendFishData(tmp, set, "XF", cells);
		// endo fins
		set.clear();
		for (int i = 0; i < this.endoFins.size(); i++) {
			set.add(this.endoFins.get(i).getIndex());
		}
		this.appendFishData(tmp, set, "NF", cells);
		// eventual eliminations
		set.clear();
		for (int i = 0; i < this.candidatesToDelete.size(); i++) {
			set.add(this.candidatesToDelete.get(i).getIndex());
		}
		this.appendFishData(tmp, set, "EE", cells);
		// cannibalistic eventual eliminations
		set.clear();
		for (int i = 0; i < this.cannibalistic.size(); i++) {
			set.add(this.cannibalistic.get(i).getIndex());
		}
		this.appendFishData(tmp, set, "CE", cells);
		// potential eliminations
		set.set(this.potentialEliminations);
		set.or(this.potentialCannibalisticEliminations);
		this.appendFishData(tmp, set, "PE", cells);
	}

	private void appendFishData(final StringBuffer tmp, final SudokuSet set, final String prefix, final boolean cells) {
		tmp.append(prefix);
		tmp.append("(");
		if (cells) {
			tmp.append(getCompactCellPrint(set));
		} else {
			tmp.append(FISH_FORMAT.format(set.size()));
		}
		tmp.append(") ");
	}

	private void getColorCellPrint(final StringBuffer tmp) {
		tmp.append(" ");
		final StringBuffer[] bufs = new StringBuffer[Options.getInstance().getColoringColors().length];
		for (final int index : this.getColorCandidates().keySet()) {
			final int color = this.getColorCandidates().get(index);
			if (bufs[color] == null) {
				bufs[color] = new StringBuffer();
				bufs[color].append("(");
			} else {
				bufs[color].append(",");
			}
			bufs[color].append(getCellPrint(index, false));
		}
		for (int i = 0; i < bufs.length; i++) {
			if (bufs[i] != null) {
				bufs[i].append(")");
				if ((i % 2) != 0) {
					tmp.append(" / ");
				} else if (i > 0) {
					tmp.append(", ");
				}
				tmp.append(bufs[i]);
			}
		}
	}

	private void getAlsXorZ(final StringBuffer tmp, final boolean x) {
		final List<Candidate> list = x ? this.endoFins : this.fins;
		final TreeSet<Integer> cands = new TreeSet<>();
		for (int i = 0; i < list.size(); i++) {
			cands.add(list.get(i).getValue());
		}
		boolean first = true;
		for (final int cand : cands) {
			if (first) {
				first = false;
			} else {
				tmp.append(",");
			}
			tmp.append(cand);
		}
	}

	public static String getAls(final Als als) {
		return getAls(als, true);
	}

	public static String getAls(final Als als, final boolean withCandidates) {
		final StringBuilder result = new StringBuilder();
		final TreeSet<Integer> set = new TreeSet<>();
		for (int i = 0; i < als.indices.size(); i++) {
			set.add(als.indices.get(i));
		}
		result.append(getCompactCellPrint(set));
		if (withCandidates) {
			result.append(" {");
			final int[] cands = Sudoku2.POSSIBLE_VALUES[als.candidates];
			for (int i = 0; i < cands.length; i++) {
				result.append(cands[i]);
			}
			result.append("}");
		}
		return result.toString();
	}

	public void getAls(final StringBuffer stringBuffer, final int alsIndex) {
		this.getAls(stringBuffer, alsIndex, true);
	}

	public void getAls(final StringBuffer stringBuffer, final int alsIndex, final boolean withCandidates) {
		final AlsInSolutionStep als = this.alses.get(alsIndex);
		stringBuffer.append(getCompactCellPrint(als.getIndices()));
		if (withCandidates) {
			stringBuffer.append(" {");
			for (final Integer cand : als.getCandidates()) {
				stringBuffer.append(cand);
			}
			stringBuffer.append("}");
		}
	}

	private void getIndexValueSet(final StringBuffer tmp) {
		tmp.append(getCompactCellPrint(this.indices));
		tmp.append(" - {");
		for (final Integer value : this.values) {
			tmp.append(value);
		}
		tmp.append("}");
	}

	private void getFinSet(final StringBuffer stringBuffer, final List<Candidate> fins) {
		this.getFinSet(stringBuffer, fins, true);
	}

	private void getFinSet(final StringBuffer tmp, final List<Candidate> fins, final boolean withCandidates) {
		final TreeSet<Integer> indexes = new TreeSet<>();
		final TreeSet<Integer> candidates = new TreeSet<>();
		for (final Candidate cand : fins) {
			indexes.add(cand.getIndex());
			candidates.add(cand.getValue());
		}
		for (final int index : this.indices) {
			indexes.remove(index);
		}
		tmp.append(getCompactCellPrint(indexes));
		if (withCandidates) {
			tmp.append(" - {");
			for (final int value : candidates) {
				tmp.append(value);
			}
			tmp.append("}");
		}
	}

	public void getEntities(final StringBuffer stringBuffer, final List<Entity> entities) {
		this.getEntities(stringBuffer, entities, false);
	}

	public void getEntities(final StringBuffer stringBuffer, final List<Entity> entities, final boolean library) {
		this.getEntities(stringBuffer, entities, library, false);
	}

	public void getEntities(final StringBuffer tmp, final List<Entity> entities, final boolean library,
			final boolean checkSiamese) {
		boolean first = true;
		if (!library) {
			tmp.append("(");
		}
		final int siameseIndex = entities.size() / 2 - 1;
		int lastEntityName = -1;
		int index = 0;
		for (final Entity act : entities) {
			if (first) {
				first = false;
			} else {
				if (!library) {
					tmp.append(", ");
				}
			}
			if (library) {
				if (lastEntityName != act.getEntityName()) {
					tmp.append(this.getEntityShortName(act.getEntityName()));
				}
				tmp.append(act.getEntityNumber());
			} else {
				tmp.append(this.getEntityName(act.getEntityName())).append(" ").append(act.getEntityNumber());
			}
			lastEntityName = act.getEntityName();
			if (checkSiamese && this.isSiamese && index == siameseIndex) {
				tmp.append("/");
				lastEntityName = -1;
			}
			index++;
		}
		if (!library) {
			tmp.append(")");
		}
	}

	/**
	 * Calculates the String representation of an RC: -ARC- ARC are the actual RCs
	 * depending on the value of actualRC.
	 *
	 * @param rc
	 *          The Restricted Common to be displayed
	 * @param stringBuffer
	 *          Result is appended to tmp
	 */
	private void getRestrictedCommon(final RestrictedCommon rc, final StringBuffer stringBuffer) {
		stringBuffer.append(" -");
		if (rc.getActualRC() == 1 || rc.getActualRC() == 3) {
			stringBuffer.append(rc.getCand1());
		}
		if (rc.getActualRC() == 2 || rc.getActualRC() == 3) {
			stringBuffer.append(rc.getCand2());
		}
		stringBuffer.append("- ");
	}

	/**
	 * Returns all candidates that are deleted in this. Is needed for displaying
	 * ALS Chains (chain should start and end with the deleted candidates (no
	 * indices").
	 *
	 * @param tmp
	 *          Result is appended to tmp
	 */
	private void getCandidatesToDeleteDigits(final StringBuffer tmp) {
		final SortedSet<Integer> candSet = new TreeSet<>();
		for (int i = 0; i < this.candidatesToDelete.size(); i++) {
			candSet.add(this.candidatesToDelete.get(i).getValue());
		}
		for (final int value : candSet) {
			tmp.append(value);
		}
	}

	/**
	 * Similar to {@link #getCandidatesToDeleteDigits(java.lang.StringBuffer) },
	 * but inserts slashes between the digits
	 */
	private String getCandidatesToDeleteDigits() {
		final StringBuffer tmp = new StringBuffer();
		this.getCandidatesToDeleteDigits(tmp);
		final int compactLength = tmp.length();
		for (int i = 0; i < compactLength - 1; i++) {
			tmp.insert(i * 2 + 1, "/");
		}
		return tmp.toString();
	}

	private void getCandidatesToDelete(final StringBuffer stringBuffer) {
		stringBuffer.append(" => ");
		@SuppressWarnings("unchecked")
		final ArrayList<Candidate> tmpList = (ArrayList<Candidate>) ((ArrayList<Candidate>) this.candidatesToDelete)
				.clone();
		boolean first = true;
		final ArrayList<Integer> candList = new ArrayList<>();
		while (tmpList.isEmpty()) {
			final Candidate firstCand = tmpList.remove(0);
			candList.clear();
			candList.add(firstCand.getIndex());
			final Iterator<Candidate> it = tmpList.iterator();
			while (it.hasNext()) {
				final Candidate c1 = it.next();
				if (c1.getValue() == firstCand.getValue()) {
					candList.add(c1.getIndex());
					it.remove();
				}
			}
			if (first) {
				first = false;
			} else {
				stringBuffer.append(", ");
			}
			stringBuffer.append(getCompactCellPrint(candList));
			stringBuffer.append("<>");
			stringBuffer.append(firstCand.getValue());
		}
	}

	public void getFins(final StringBuffer stringBuffer, final boolean endo) {
		this.getFins(stringBuffer, endo, false);
	}

	public void getFins(final StringBuffer stringBuffer, final boolean endo, final boolean library) {
		final List<Candidate> list = endo ? this.endoFins : this.fins;
		if (list.isEmpty()) {
			return;
		}
		if (!library) {
			if (list.size() == 1) {
				if (endo) {
					stringBuffer.append(" ")
							.append(java.util.ResourceBundle.getBundle(INTL_SOLUTION_STEP).getString("SolutionStep.endofin_in"))
							.append(" ");
				} else {
					stringBuffer.append(" ")
							.append(java.util.ResourceBundle.getBundle(INTL_SOLUTION_STEP).getString("SolutionStep.fin_in"))
							.append(" ");
				}
			} else {
				if (endo) {
					stringBuffer.append(" ")
							.append(java.util.ResourceBundle.getBundle(INTL_SOLUTION_STEP).getString("SolutionStep.endofins_in"))
							.append(" ");
				} else {
					stringBuffer.append(" ")
							.append(java.util.ResourceBundle.getBundle(INTL_SOLUTION_STEP).getString("SolutionStep.fins_in"))
							.append(" ");
				}
			}
		}
		final String finStr = endo ? "ef" : "f";
		boolean first = true;
		for (final Candidate cand : list) {
			if (first) {
				first = false;
			} else {
				if (library) {
					stringBuffer.append(" ");
				} else {
					stringBuffer.append(", ");
				}
			}
			if (library) {
				stringBuffer.append(finStr).append(getCellPrint(cand.getIndex(), false));
			} else {
				stringBuffer.append(getCellPrint(cand.getIndex(), false));
			}
		}
	}

	public int getEntity() {
		return this.entity;
	}

	public void setEntity(final int entity) {
		if (entity != Sudoku2.BLOCK && entity != Sudoku2.LINE && entity != Sudoku2.COL && entity != Sudoku2.CELL) {
			throw new RuntimeException(
					java.util.ResourceBundle.getBundle(INTL_SOLUTION_STEP).getString("SolutionStep.invalid_setEntity") + " ("
							+ entity + java.util.ResourceBundle.getBundle(INTL_SOLUTION_STEP).getString(")"));
		}
		this.entity = entity;
	}

	public int getEntityNumber() {
		return this.entityNumber;
	}

	public void setEntityNumber(final int entityNumber) {
		this.entityNumber = entityNumber;
	}

	public int getEntity2() {
		return this.entity2;
	}

	public void setEntity2(final int entity2) {
		this.entity2 = entity2;
	}

	public int getEntity2Number() {
		return this.entity2Number;
	}

	public void setEntity2Number(final int entity2Number) {
		this.entity2Number = entity2Number;
	}

	public void addBaseEntity(final int name, final int number) {
		this.baseEntities.add(new Entity(name, number));
	}

	public void addBaseEntity(final Entity e) {
		this.baseEntities.add(e);
	}

	public void addCoverEntity(final int name, final int number) {
		this.coverEntities.add(new Entity(name, number));
	}

	public void addCoverEntity(final Entity e) {
		this.coverEntities.add(e);
	}

	public void addChain(final int start, final int end, final int[] chain) {
		this.chains.add(new Chain(start, end, chain));
	}

	public void addChain(final Chain chain) {
		chain.resetLength();
		this.chains.add(chain);
	}

	public List<Chain> getChains() {
		return this.chains;
	}

	public int getChainLength() {
		int length = 0;
		for (int i = 0; i < this.chains.size(); i++) {
			length += this.chains.get(i).getLength(this.alses);
		}
		return length;
	}

	public int getChainAnz() {
		return this.chains.size();
	}

	public boolean isNet() {
		if (!this.chains.isEmpty()) {
			for (int i = 0; i < this.chains.size(); i++) {
				final Chain tmp = this.chains.get(i);
				for (int j = tmp.getStart(); j <= tmp.getEnd(); j++) {
					if (tmp.getChain()[j] < 0) {
						return true;
					}
				}
			}
		}
		return false;
	}

	public int getAlsesIndexCount() {
		int count = 0;
		for (final AlsInSolutionStep als : this.alses) {
			count += als.getIndices().size();
		}
		return count;
	}

	public List<AlsInSolutionStep> getAlses() {
		return this.alses;
	}

	public AlsInSolutionStep getAls(final int index) {
		return this.alses.get(index);
	}

	public void addAls(final AlsInSolutionStep newAls) {
		this.alses.add(newAls);
	}

	public void addAls(final SudokuSet indices, final SudokuSet candidates) {
		final AlsInSolutionStep als = new AlsInSolutionStep();
		for (int i = 0; i < indices.size(); i++) {
			als.addIndex(indices.get(i));
		}
		for (int i = 0; i < candidates.size(); i++) {
			als.addCandidate(candidates.get(i));
		}
		this.alses.add(als);
	}

	public void addAls(final SudokuSet indices, final short candidates) {
		final AlsInSolutionStep als = new AlsInSolutionStep();
		for (int i = 0; i < indices.size(); i++) {
			als.addIndex(indices.get(i));
		}
		final int[] cands = Sudoku2.POSSIBLE_VALUES[candidates];
		for (int i = 0; i < cands.length; i++) {
			als.addCandidate(cands[i]);
		}
		this.alses.add(als);
	}

	public void addRestrictedCommon(final RestrictedCommon rc) {
		this.restrictedCommons.add(rc);
	}

	public int getAlsIndex(final int index, final int chainIndex) {
		if (chainIndex == -1) {
			for (int i = 0; i < this.alses.size(); i++) {
				if (this.alses.get(i).getIndices().contains(index)) {
					return i;
				}
			}
		} else {
			final Chain chain = this.chains.get(chainIndex);
			for (int i = chain.getStart(); i <= chain.getEnd(); i++) {
				if (chain.getNodeType(i) == Chain.ALS_NODE) {
					final int alsIndex = Chain.getSAlsIndex(chain.getChain()[i]);
					final AlsInSolutionStep als = this.alses.get(alsIndex);
					if (als.getIndices().contains(index)) {
						return alsIndex;
					}
				}
			}
		}
		return -1;
	}

	/**
	 * Adds a new colored candidate
	 */
	public void addColorCandidate(final int index, final int color) {
		this.getColorCandidates().put(index, color);
	}

	public void addColorCandidates(final SudokuSet indices, final int color) {
		for (int i = 0; i < indices.size(); i++) {
			this.addColorCandidate(indices.get(i), color);
		}
	}

	public boolean isEqual(final SolutionStep s) {
		if (!this.isEquivalent(s)) {
			return false;
		}

		if (!this.isEqualInteger(this.values, s.values)) {
			return false;
		}
		if (!this.isEqualInteger(this.indices, s.indices)) {
			return false;
		}
		if (!this.isEqualCandidate(this.fins, s.fins)) {
			return false;
		}

		return true;
	}

	public boolean isEquivalent(final SolutionStep s) {
		if (this.type.isFish() && s.getType().isFish()) {
			return true;
		}
		if (this.type.isKrakenFish() && s.getType().isKrakenFish()) {
			return true;
		}
		if (this.getType() != s.getType()) {
			return false;
		}

		if (!this.candidatesToDelete.isEmpty()) {
			return this.isEqualCandidate(this.candidatesToDelete, s.candidatesToDelete);
		}
		return this.isEqualInteger(this.indices, s.indices);
	}

	public boolean isSubStep(final SolutionStep s) {
		if (s.candidatesToDelete.size() < this.candidatesToDelete.size()) {
			return false;
		}
		for (final Candidate cand : this.candidatesToDelete) {
			if (!s.candidatesToDelete.contains(cand)) {
				return false;
			}
		}
		return true;
	}

	public boolean isSingle() {
		return this.isSingle(this.type);
	}

	public boolean isSingle(final SolutionType type) {
		return (type == SolutionType.FULL_HOUSE || type == SolutionType.HIDDEN_SINGLE || type == SolutionType.NAKED_SINGLE
				|| type == SolutionType.TEMPLATE_SET);
	}

	public boolean isForcingChainSet() {
		if ((this.type == SolutionType.FORCING_CHAIN || this.type == SolutionType.FORCING_CHAIN_CONTRADICTION
				|| this.type == SolutionType.FORCING_CHAIN_VERITY) && !this.indices.isEmpty()) {
			return true;
		}
		if ((this.type == SolutionType.FORCING_NET || this.type == SolutionType.FORCING_NET_CONTRADICTION
				|| this.type == SolutionType.FORCING_NET_VERITY) && !this.indices.isEmpty()) {
			return true;
		}
		return false;
	}

	public int compareChainLengths(final SolutionStep o) {
		return this.getChainLength() - o.getChainLength();
	}

	@Override
	public int compareTo(final SolutionStep o) {
		int sum1 = 0;
		int sum2 = 0;

		if (this.isSingle(this.type) && !this.isSingle(o.type)) {
			return -1;
		} else if (!this.isSingle(this.type) && this.isSingle(o.type)) {
			return 1;
		}

		final int result = o.candidatesToDelete.size() - this.candidatesToDelete.size();
		if (result != 0) {
			return result;
		}

		if (!this.isEquivalent(o)) {

			sum1 = this.getIndexSumme(this.candidatesToDelete);
			sum2 = this.getIndexSumme(o.candidatesToDelete);
			return (sum1 - sum2);
		}

		// SPECIAL STEPS
		// fish general: sort for
		// - fish type
		// - fish size
		// - cannibalism
		// - number of endo fins
		// - number of fins
		if (this.type.isFish() && o.getType().isFish()) {
			int ret = this.type.compare(o.getType());
			if (ret != 0) {
				// different type or different size
				return ret;
			}
			ret = this.getCannibalistic().size() - o.getCannibalistic().size();
			if (ret != 0) {
				return ret;
			}
			ret = this.getEndoFins().size() - o.getEndoFins().size();
			if (ret != 0) {
				return ret;
			}
			ret = this.getFins().size() - o.getFins().size();
			if (ret != 0) {
				return ret;
			}
			if (!this.isEqualInteger(this.values, o.values)) {
				sum1 = this.getSumme(this.values);
				sum2 = this.getSumme(o.values);
				return sum1 - sum2;
			}
			return 0;
		}

		if (this.type.isKrakenFish() && o.getType().isKrakenFish()) {
			final int ret = this.subType.compare(o.getSubType());
			if (ret != 0) {
				return ret;
			}
			return this.compareChainLengths(o);
		}

		final int chainDiff = this.compareChainLengths(o);
		if (chainDiff != 0) {
			return chainDiff;
		}

		if (!this.isEqualInteger(this.values, o.values)) {
			sum1 = this.getSumme(this.values);
			sum2 = this.getSumme(o.values);
			return sum1 - sum2;
		}

		if (!this.isEqualInteger(this.indices, o.indices)) {
			if (this.indices.size() != o.indices.size()) {
				return this.indices.size() - o.indices.size();
			}
			sum1 = this.getSumme(this.indices);
			sum2 = this.getSumme(o.indices);
			return sum2 - sum1;
		}
		return this.type.compare(o.getType());
	}

	public boolean isEqualValues(final SolutionStep s) {
		return this.isEqualInteger(this.values, s.getValues());
	}

	private boolean isEqualInteger(final List<Integer> l1, final List<Integer> l2) {
		if (l1.size() != l2.size()) {
			return false;
		}
		final int anz = l1.size();
		for (int i = 0; i < anz; i++) {
			final int i1 = l1.get(i);
			boolean found = false;
			for (int j = 0; j < anz; j++) {
				final int i2 = l2.get(j);
				if (i1 == i2) {
					found = true;
					break;
				}
			}
			if (!found) {
				return false;
			}
		}
		return true;
	}

	public boolean isEqualCandidate(final SolutionStep s) {
		return this.isEqualCandidate(this.candidatesToDelete, s.getCandidatesToDelete());
	}

	private boolean isEqualCandidate(final List<Candidate> l1, final List<Candidate> l2) {
		if (l1.size() != l2.size()) {
			return false;
		}
		final int anz = l1.size();
		for (int i = 0; i < anz; i++) {
			final Candidate c1 = l1.get(i);
			boolean found = false;
			for (int j = 0; j < anz; j++) {
				final Candidate c2 = l2.get(j);
				if (c1.getIndex() == c2.getIndex() && c1.getValue() == c2.getValue()) {
					found = true;
					break;
				}
			}
			if (!found) {
				return false;
			}
		}
		return true;
	}

	/**
	 * The sum of the indices of a collection of candidates is used as a sorting
	 * criteria. For this to work, the indices have to be weighted or else two
	 * combinations of different indices could lead to the same sum.<br>
	 */
	public int getIndexSumme(final List<Candidate> list) {
		int sum = 0;
		int offset = 1;
		for (int i = 0; i < list.size(); i++) {
			sum += list.get(i).getIndex() * offset + list.get(i).getValue();
			offset += 80;
		}
		return sum;
	}

	public int getSumme(final List<Integer> list) {
		int sum = 0;
		for (int i = 0; i < list.size(); i++) {
			sum += list.get(i);
		}
		return sum;
	}

	public int compareCandidatesToDelete(final SolutionStep o) {
		final int size1 = this.candidatesToDelete.size();
		final int size2 = o.candidatesToDelete.size();
		if (size1 != size2) {
			return size2 - size1;
		}
		int result = 0;
		for (int i = 0; i < size1; i++) {
			final Candidate c1 = this.candidatesToDelete.get(i);
			final Candidate c2 = o.candidatesToDelete.get(i);
			result = (c1.getIndex() * 10 + c1.getValue()) - (c2.getIndex() * 10 + c2.getValue());
			if (result != 0) {
				return result;
			}
		}
		return 0;
	}

	public List<Entity> getBaseEntities() {
		return this.baseEntities;
	}

	public List<Entity> getCoverEntities() {
		return this.coverEntities;
	}

	public void setValues(final List<Integer> values) {
		this.values = values;
	}

	public void setIndices(final List<Integer> indices) {
		this.indices = indices;
	}

	public void setCandidatesToDelete(final List<Candidate> candidatesToDelete) {
		this.candidatesToDelete = candidatesToDelete;
	}

	public void setCannibalistic(final List<Candidate> cannibalistic) {
		this.cannibalistic = cannibalistic;
	}

	public void setFins(final List<Candidate> fins) {
		this.fins = fins;
	}

	public void setEndoFins(final List<Candidate> endoFins) {
		this.endoFins = endoFins;
	}

	public void setBaseEntities(final List<Entity> baseEntities) {
		this.baseEntities = baseEntities;
	}

	public void setCoverEntities(final List<Entity> coverEntities) {
		this.coverEntities = coverEntities;
	}

	public void setChains(final List<Chain> chains) {
		this.chains = chains;
	}

	public void setAlses(final List<AlsInSolutionStep> alses) {
		this.alses = alses;
	}

	public SortedMap<Integer, Integer> getColorCandidates() {
		return this.colorCandidates;
	}

	public void setColorCandidates(final SortedMap<Integer, Integer> colorCandidates) {
		this.colorCandidates = colorCandidates;
	}

	public SolutionType getSubType() {
		return this.subType;
	}

	public void setSubType(final SolutionType subType) {
		this.subType = subType;
	}

	public boolean isIsSiamese() {
		return this.isSiamese;
	}

	public void setIsSiamese(final boolean isSiamese) {
		this.isSiamese = isSiamese;
	}

	public List<RestrictedCommon> getRestrictedCommons() {
		return this.restrictedCommons;
	}

	public void setRestrictedCommons(final List<RestrictedCommon> restrictedCommons) {
		this.restrictedCommons = restrictedCommons;
	}

	public int getProgressScoreSingles() {
		return this.progressScoreSingles;
	}

	public void setProgressScoreSingles(final int progressScoreSingles) {
		this.progressScoreSingles = progressScoreSingles;
	}

	public int getProgressScoreSinglesOnly() {
		return this.progressScoreSinglesOnly;
	}

	public void setProgressScoreSinglesOnly(final int progressScoreSinglesOnly) {
		this.progressScoreSinglesOnly = progressScoreSinglesOnly;
	}

	public int getProgressScore() {
		return this.progressScore;
	}

	public void setProgressScore(final int progressScore) {
		this.progressScore = progressScore;
	}

	public SudokuSet getPotentialCannibalisticEliminations() {
		return this.potentialCannibalisticEliminations;
	}

	public void setPotentialCannibalisticEliminations(final SudokuSet potentialCannibalisticEliminations) {
		this.potentialCannibalisticEliminations = potentialCannibalisticEliminations;
	}

	public SudokuSet getPotentialEliminations() {
		return this.potentialEliminations;
	}

	public void setPotentialEliminations(final SudokuSet potentialEliminations) {
		this.potentialEliminations = potentialEliminations;
	}
}
