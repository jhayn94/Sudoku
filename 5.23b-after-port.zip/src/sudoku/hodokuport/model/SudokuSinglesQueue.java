/*
 * Copyright (C) 2008-12  Bernhard Hobiger
 *
 * This file is part of HoDoKu.
 *
 * HoDoKu is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * HoDoKu is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with HoDoKu. If not, see <http://www.gnu.org/licenses/>.
 */
package sudoku.hodokuport.model;

import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * A queue that can hold possible Singles (naked or hidden). For Hidden Singles
 * the unit is not stored, Full houses are treated as Naked Singles. <br>
 * Since every (Hidden) Single can appear in three houses, the maximum size of
 * the queue is three times the number of cells in the Sudoku.<br>
 * The queue is not built as ring buffer, but the indices are reset to 0 every
 * time the queue is empty.<br>
 * It is possible to delete Singles from the queue. This is used by class
 * {@link Sudoku2} when setting candidates or deleting values from cells.
 */
public class SudokuSinglesQueue implements Cloneable {
	/** The indices of newly detected Singles */
	private int[] indices = new int[Sudoku2.LENGTH * 3];
	/** The values of newly detected Singles */
	private int[] values = new int[Sudoku2.LENGTH * 3];
	/** The index of the next Single to put into the queue. */
	private int putIndex = 0;
	/** The index of the next Single to get from the queue. */
	private int getIndex = 0;
	/** An index for iterating the queue without removing Singles. */
	private int iterateIndex = 0;

	public SudokuSinglesQueue() {
		// Nothing to do.
	}

	/**
	 * Clones a SudokuSinglesQueue. Makes a valid deep copy.
	 */
	@Override
	public SudokuSinglesQueue clone() {
		SudokuSinglesQueue newSudokuSinglesQueue = null;
		try {
			newSudokuSinglesQueue = (SudokuSinglesQueue) super.clone();
			newSudokuSinglesQueue.indices = this.indices.clone();
			newSudokuSinglesQueue.values = this.values.clone();
		} catch (final CloneNotSupportedException ex) {
			Logger.getLogger(this.getClass().getName()).log(Level.SEVERE, "Error while cloning", ex);
		}
		return newSudokuSinglesQueue;
	}

	/**
	 * Set the queue with the values of queue <code>src</code>.
	 */
	public void set(final SudokuSinglesQueue src) {
		System.arraycopy(src.indices, 0, this.indices, 0, this.indices.length);
		System.arraycopy(src.values, 0, this.values, 0, this.values.length);
		this.getIndex = src.getIndex;
		this.putIndex = src.putIndex;
		this.iterateIndex = src.iterateIndex;
	}

	/**
	 * Checks if the queue is empty.
	 */
	public boolean isEmpty() {
		return this.getIndex >= this.putIndex;
	}

	/**
	 * Add a new Single to the queue
	 */
	public void addSingle(final int index, final int value) {
		this.indices[this.putIndex] = index;
		this.values[this.putIndex++] = value;
	}

	/**
	 * Gets the index of the next Single or -1, if the queue is empty. The index
	 * is incremented, which removes the oldest Single from the queue.
	 */
	public int getSingle() {
		if (this.getIndex >= this.putIndex) {
			// queue is empty
			return -1;
		}
		final int ret = this.getIndex++;
		if (this.getIndex >= this.putIndex) {
			this.getIndex = this.putIndex = 0;
		}
		return ret;
	}

	/**
	 * Returns the cell index at queue position <code>queueIndex</code>.
	 */
	public int getIndex(final int queueIndex) {
		return this.indices[queueIndex];
	}

	/**
	 * Returns the cell value at queue position <code>queueIndex</code>.
	 */
	public int getValue(final int queueIndex) {
		return this.values[queueIndex];
	}

	/**
	 * Used together with {@link #getNextIndex() } to iterate the queue without
	 * removing elements. If the queue is empty, -1 is returned.
	 */
	public int getFirstIndex() {
		this.iterateIndex = this.getIndex;
		return this.getNextIndex();
	}

	/**
	 * Used together with {@link #getFirstIndex() } to iterate the queue without
	 * removing elements. If the queue is empty, -1 is returned. The method does
	 * not check for concurrent modifications of the queue!
	 */
	public int getNextIndex() {
		if (this.iterateIndex >= this.putIndex) {
			return -1;
		}
		return this.iterateIndex++;
	}

	/**
	 * Checks, if the queue contains an entry for the cell with index
	 * <code>index</code>. If an entry is found, it is deleted.
	 */
	public void deleteNakedSingle(final int index) {
		for (int i = this.getIndex; i < this.putIndex; i++) {
			if (this.indices[i] == index) {
				for (int j = i + 1; j < this.putIndex; j++) {
					this.indices[j - 1] = this.indices[j];
					this.values[j - 1] = this.values[j];
				}
				this.putIndex--;
				break;
			}
		}
	}

	/**
	 * Checks, if the queue contains an entry for a cell within constraint
	 * <code>constraint</code> for candidate <code>value</code>. If it does, that
	 * entry is removed.
	 */
	public void deleteHiddenSingle(final int constraint, final int value) {
		for (int i = this.getIndex; i < this.putIndex; i++) {
			final int actIndex = this.indices[i];
			if (this.values[i] == value && (Sudoku2.CONSTRAINTS[actIndex][0] == constraint
					|| Sudoku2.CONSTRAINTS[actIndex][1] == constraint || Sudoku2.CONSTRAINTS[actIndex][2] == constraint)) {
				for (int j = i + 1; j < this.putIndex; j++) {
					this.indices[j - 1] = this.indices[j];
					this.values[j - 1] = this.values[j];
				}
				this.putIndex--;
				break;
			}
		}
	}

	/**
	 * Deletes all entries in the queue.
	 */
	public void clear() {
		this.getIndex = this.putIndex = 0;
	}

	/**
	 * Return a formatted String containing the contents of the queue. For
	 * debugging only.
	 */
	@Override
	public String toString() {
		final StringBuilder tmp = new StringBuilder();
		tmp.append("Singles Queue START\r\n");
		for (int i = this.getIndex; i < this.putIndex; i++) {
			tmp.append("   ").append(this.indices[i]).append("/").append(this.values[i]).append("\r\n");
		}
		tmp.append("Singles Queue END\r\n");
		return tmp.toString();
	}
}
