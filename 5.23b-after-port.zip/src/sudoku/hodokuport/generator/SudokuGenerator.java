/*
 * Copyright (C) 2008-12  Bernhard Hobiger
 *
 * This file is part of HoDoKu.
 *
 * HoDoKu is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * HoDoKu is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with HoDoKu. If not, see <http://www.gnu.org/licenses/>.
 *
 * This code is actually a Java port of code posted by Glenn Fowler
 * in the Sudoku Player's Forum (http://www.setbb.com/sudoku).
 * Many thanks for letting me use it!
 */
package sudoku.hodokuport.generator;

import java.util.Arrays;
import java.util.List;
import java.util.Random;
import java.util.logging.Level;
import java.util.logging.Logger;

import sudoku.hodokuport.model.Options;
import sudoku.hodokuport.model.Sudoku2;
import sudoku.hodokuport.model.SudokuSinglesQueue;
import sudoku.hodokuport.model.SudokuStatus;

/**
 * Bit based backtracking solver.
 *
 * @author hobiwan
 */
public class SudokuGenerator {
	/** Maximum number of tries when generating a puzzle using a pattern */
	private static final int MAX_TRIES = 1000000;

	/** Empty sudoku for initialization */
	private static Sudoku2 EMPTY_GRID = new Sudoku2();

	/**
	 * One entry in recursion stack
	 */
	private class RecursionStackEntry {

		/** The current state of the sudoku */
		Sudoku2 sudoku = new Sudoku2();
		/** The index of the cell thats being tried */
		int index;
		/** The candidates for cells {@link #index}. */
		int[] candidates;
		/** The index of the last tried candidate in {@link #candidates}. */
		int candIndex;
	}

	/** The cells values of the first solution */
	private int[] solution = new int[81];
	/** Number of solutions already found */
	private int solutionCount = 0;
	/** The recursion stack */
	private final RecursionStackEntry[] stack = new RecursionStackEntry[82];
	/** The order in which cells are set when generating a full grid. */
	private final int[] generateIndices = new int[81];
	/** The cells of a newly generated sudoku (full board) */
	private final int[] newFullSudoku = new int[81];
	/** The cells of a newly generated valid sudoku. */
	private final int[] newValidSudoku = new int[81];
	/** A random generator for creating new puzzles. */
	private final Random rand = new Random();

	/** Creates a new instance of SudokuGenerator */
	protected SudokuGenerator() {
		for (int i = 0; i < this.stack.length; i++) {
			this.stack[i] = new RecursionStackEntry();
		}
	}

	/**
	 * Checks if <code>sudoku</code> has exactly one solution. If it has, the
	 * solution is stored in the sudoku.
	 *
	 * @param sudoku
	 * @return 0 (invalid), 1 (valid), or 2 (multiple solutions)
	 */
	public int getNumberOfSolutions(final Sudoku2 sudoku) {
		long ticks = System.currentTimeMillis();
		this.solve(sudoku);
		if (this.solutionCount == 1) {
			sudoku.setSolution(Arrays.copyOf(this.solution, this.solution.length));
		}
		ticks = System.currentTimeMillis() - ticks;
		Logger.getLogger(this.getClass().getName()).log(Level.FINE, "validSolution() {0}ms", ticks);
		return this.solutionCount;
	}

	/**
	 * Checks if <code>sudoku</code> has exactly one solution. If it has, the
	 * solution is stored in the sudoku.
	 *
	 * @param sudoku
	 * @return
	 */
	public boolean validSolution(final Sudoku2 sudoku) {
		long ticks = System.currentTimeMillis();
		this.solve(sudoku);
		final boolean unique = this.solutionCount == 1;
		if (unique) {
			sudoku.setSolution(Arrays.copyOf(this.solution, this.solution.length));
		}
		ticks = System.currentTimeMillis() - ticks;
		Logger.getLogger(this.getClass().getName()).log(Level.FINE, "validSolution() {0}ms", ticks);
		return unique;
	}

	/**
	 * Solves <code>sudoku</code>.
	 *
	 * @param sudoku
	 */
	private void solve(final Sudoku2 sudoku) {
		// start with the current state of the sudoku
		this.stack[0].sudoku.set(sudoku);
		this.stack[0].index = 0;
		this.stack[0].candidates = null;
		this.stack[0].candIndex = 0;

		// solve it
		this.solve();
	}

	/**
	 * Solves a sudoku given by a 81 character string.
	 *
	 * @param sudokuString
	 */
	public void solve(final String sudokuString) {
		// start with an empty sudoku
		this.stack[0].sudoku.set(EMPTY_GRID);
		this.stack[0].candidates = null;
		this.stack[0].candIndex = 0;

		// set up the sudoku
		for (int i = 0; i < sudokuString.length() && i < Sudoku2.LENGTH; i++) {
			final int value = sudokuString.charAt(i) - '0';
			if (value >= 1 && value <= 9) {
				this.stack[0].sudoku.setCell(i, value, false, false);
				this.setAllExposedSingles(this.stack[0].sudoku);
			}
		}
		// solve it
		this.solve();
	}

	/**
	 * Solves a sudoku given by a 81 int array.
	 *
	 * @param cellValues
	 */
	public void solve(final int[] cellValues) {
		this.stack[0].sudoku.set(EMPTY_GRID);
		this.stack[0].candidates = null;
		this.stack[0].candIndex = 0;
		for (int i = 0; i < cellValues.length; i++) {
			final int value = cellValues[i];
			if (value >= 1 && value <= 9) {
				this.stack[0].sudoku.setCellBS(i, value);
			}
		}
		this.stack[0].sudoku.rebuildInternalData();
		this.setAllExposedSingles(this.stack[0].sudoku);
		this.solve();
	}

	/**
	 * The real backtracking solver: Recursion is simulated by a recursion stack
	 * ({@link #stack}), if Singles are exposed during solving, they are set.
	 */
	private void solve() {
		this.solutionCount = 0;
		// first set all Singles exposed by building up the Sudoku grid
		if (!this.setAllExposedSingles(this.stack[0].sudoku)) {
			// puzzle was invalid all along
			return;
		}
		if (this.stack[0].sudoku.getUnsolvedCellsAnz() == 0) {
			// already solved, nothing to do
			this.solution = Arrays.copyOf(this.stack[0].sudoku.getValues(), Sudoku2.LENGTH);
			this.solutionCount++;
			return;
		}
		int level = 0;
		while (true) {
			// get the next unsolved cells with the fewest number of candidates
			if (this.stack[level].sudoku.getUnsolvedCellsAnz() == 0) {
				// sudoku is solved
				this.solutionCount++;
				// count the solutions
				if (this.solutionCount == 1) {
					// first solution is recorded
					this.solution = Arrays.copyOf(this.stack[level].sudoku.getValues(), Sudoku2.LENGTH);
				} else if (this.solutionCount > 1) {
					return;
				}
			} else {
				int index = -1;
				int anzCand = 9;
				final Sudoku2 sudoku = this.stack[level].sudoku;
				for (int i = 0; i < Sudoku2.LENGTH; i++) {
					if (sudoku.getCell(i) != 0 && Sudoku2.ANZ_VALUES[sudoku.getCell(i)] < anzCand) {
						index = i;
						anzCand = Sudoku2.ANZ_VALUES[sudoku.getCell(i)];
					}
				}
				level++;
				// missing candidates lead to exception -> avoid that
				if (index < 0) {
					this.solutionCount = 0;
					return;
				}
				this.stack[level].index = (short) index;
				this.stack[level].candidates = Sudoku2.POSSIBLE_VALUES[this.stack[level - 1].sudoku.getCell(index)];
				this.stack[level].candIndex = 0;
			}

			// go to the next level
			boolean done = false;
			do {
				// this loop runs as long as the next candidate tried produces an
				// invalid sudoku or until all possibilities have been tried

				// fall back all levels, where nothing is to do anymore
				while (this.stack[level].candIndex >= this.stack[level].candidates.length) {
					level--;
					if (level <= 0) {
						// no level with candidates left
						done = true;
						break;
					}
				}
				if (done) {
					break;
				}
				// try the next candidate
				final int nextCand = this.stack[level].candidates[this.stack[level].candIndex++];
				// start with a fresh sudoku
				this.stack[level].sudoku.setBS(this.stack[level - 1].sudoku);
				if (!this.stack[level].sudoku.setCell(this.stack[level].index, nextCand, false, false)) {
					// invalid -> try next candidate
					continue;
				}
				if (this.setAllExposedSingles(this.stack[level].sudoku)) {
					// valid move, break from the inner loop to advance to the next level
					break;
				}
			} while (true);
			if (done) {
				break;
			}
		}
	}

	/**
	 * Generates a new valid sudoku. If a pattern is set in {@link Options} and it
	 * has already be checked for validity, it is used automatically.<br>
	 * <br>
	 *
	 * This method is used by the {@link PuzzleGenerator}.
	 *
	 * @param symmetric
	 * @return
	 */
	public Sudoku2 generateSudoku(final boolean symmetric) {
		final int index = Options.getInstance().getGeneratorPatternIndex();
		boolean[] pattern = null;
		final List<GeneratorPattern> patterns = Options.getInstance().getGeneratorPatterns();
		if (index != -1 && index < patterns.size() && patterns.get(index).isValid()) {
			pattern = patterns.get(index).getPattern();
		}
		return this.generateSudoku(symmetric, pattern);
	}

	/**
	 * Generates a new valid sudoku. If <code>pattern</code> is not
	 * <code>null</code>, it is used to determine the positions of the givens. If
	 * no sudoku could be generated (only possible if a <code>pattern</code> is
	 * applied), the method returns <code>null</code>.<br>
	 * <br>
	 *
	 * This method is used by the validity checker in the
	 * {@link ConfigGeneratorPanel}.
	 *
	 * @param symmetric
	 * @param pattern
	 * @return
	 */
	public Sudoku2 generateSudoku(final boolean symmetric, final boolean[] pattern) {
		this.generateFullGrid();
		if (pattern == null) {
			this.generateInitPos(symmetric);
		} else {
			boolean ok = false;
			for (int i = 0; i < MAX_TRIES; i++) {
				if ((ok = this.generateInitPos(pattern))) {
					break;
				}
			}
			if (!ok) {
				// no puzzle found in MAX_TRIES iterations
				return null;
			}
		}
		// construct the new sudoku
		final Sudoku2 sudoku = new Sudoku2();
		for (int i = 0; i < this.newValidSudoku.length; i++) {
			if (this.newValidSudoku[i] != 0) {
				sudoku.setCell(i, this.newValidSudoku[i]);
				sudoku.setIsFixed(i, true);
			}
		}
		// this sudoku is valid and has givens
		sudoku.setStatus(SudokuStatus.VALID);
		sudoku.setStatusGivens(SudokuStatus.VALID);
		return sudoku;
	}

	/**
	 * Generates a new valid randomized grid. The real work is done by
	 * {@link #doGenerateFullGrid()}, but since this method can fail, we have to
	 * check for errors.
	 */
	private void generateFullGrid() {
		while (!this.doGenerateFullGrid())
			;
	}

	/**
	 * Generates a new valid full sudoku grid. Works exactly like the backtracking
	 * solver ({@link #solve()}), the cells are set in random order.<br>
	 * The method works very well most of the times, but somtimes (about 1.5% of
	 * all cases) it can take extremely long to get a solution. It is then better
	 * to abort and try with a new randomized index set.
	 */
	private boolean doGenerateFullGrid() {
		// limit the number of tries
		int actTries = 0;
		// generate a random order for setting the cells
		final int max = this.generateIndices.length;
		for (int i = 0; i < max; i++) {
			this.generateIndices[i] = i;
		}
		for (int i = 0; i < max; i++) {
			final int index1 = this.rand.nextInt(max);
			int index2 = this.rand.nextInt(max);
			while (index1 == index2) {
				index2 = this.rand.nextInt(max);
			}
			final int dummy = this.generateIndices[index1];
			this.generateIndices[index1] = this.generateIndices[index2];
			this.generateIndices[index2] = dummy;
		}
		// first set a new empty Sudoku
		this.stack[0].sudoku.set(EMPTY_GRID);
		int level = 0;
		this.stack[0].index = -1;
		while (true) {
			// get the next unsolved cell according to generateIndices
			if (this.stack[level].sudoku.getUnsolvedCellsAnz() == 0) {
				// generation is complete
				System.arraycopy(this.stack[level].sudoku.getValues(), 0, this.newFullSudoku, 0, this.newFullSudoku.length);
				return true;
			} else {
				int index = -1;
				final int[] actValues = this.stack[level].sudoku.getValues();
				for (int i = 0; i < Sudoku2.LENGTH; i++) {
					final int actTry = this.generateIndices[i];
					if (actValues[actTry] == 0) {
						index = actTry;
						break;
					}
				}
				level++;
				this.stack[level].index = (short) index;
				this.stack[level].candidates = Sudoku2.POSSIBLE_VALUES[this.stack[level - 1].sudoku.getCell(index)];
				this.stack[level].candIndex = 0;
			}

			// not too many tries...
			actTries++;
			if (actTries > 100) {
				return false;
			}

			// go to the next level
			boolean done = false;
			do {
				// this loop runs as long as the next candidate tried produces an
				// invalid sudoku or until all possibilities have been tried

				// fall back all levels, where nothing is to do anymore
				while (this.stack[level].candIndex >= this.stack[level].candidates.length) {
					level--;
					if (level <= 0) {
						// no level with candidates left
						done = true;
						break;
					}
				}
				if (done) {
					break;
				}
				// try the next candidate
				final int nextCand = this.stack[level].candidates[this.stack[level].candIndex++];
				// start with a fresh sudoku
				this.stack[level].sudoku.setBS(this.stack[level - 1].sudoku);
				if (!this.stack[level].sudoku.setCell(this.stack[level].index, nextCand, false, false)) {
					// invalid -> try next candidate
					continue;
				}
				if (this.setAllExposedSingles(this.stack[level].sudoku)) {
					// valid move, break from the inner loop to advance to the next level
					break;
				}
			} while (true);
			if (done) {
				break;
			}
		}
		// we should never get till here...
		return false;
	}

	/**
	 * Takes a full sudoku from {@link #newFullSudoku} and generates a valid
	 * puzzle by deleting the cells indicated by <code>pattern</code>. If the
	 * resulting puzzle is invalid, <code>false</code> is returned and the caller
	 * is responsible for continuing the search.
	 *
	 * @param pattern
	 * @return
	 */
	private boolean generateInitPos(final boolean[] pattern) {
		// we start with the full board
		System.arraycopy(this.newFullSudoku, 0, this.newValidSudoku, 0, this.newFullSudoku.length);
		// delete all cells indicated by pattern
		for (int i = 0; i < pattern.length; i++) {
			if (!pattern[i]) {
				this.newValidSudoku[i] = 0;
			}
		}
		this.solve(this.newValidSudoku);
		return this.solutionCount <= 1;
	}

	/**
	 * Takes a full sudoku and generates a valid puzzle by deleting cells. If a
	 * deletion produces a grid with more than one solution it is undone.
	 */
	private void generateInitPos(final boolean isSymmetric) {
		final int maxPosToFill = 17; // no less than 17 givens
		final boolean[] used = new boolean[81]; // try every cell only once
		int usedCount = used.length;
		Arrays.fill(used, false);

		// we start with the full board
		System.arraycopy(this.newFullSudoku, 0, this.newValidSudoku, 0, this.newFullSudoku.length);
		int remainingClues = this.newValidSudoku.length;

		// do until we have only 17 clues left or until all cells have been tried
		while (remainingClues > maxPosToFill && usedCount > 1) {
			// get the next position to try
			int i = this.rand.nextInt(81);
			do {
				if (i < 80) {
					i++;
				} else {
					i = 0;
				}
			} while (used[i]);
			used[i] = true;
			usedCount--;

			if (this.newValidSudoku[i] == 0) {
				// already deleted (symmetry)
				continue;
			}
			if (isSymmetric && (i / 9 != 4 || i % 9 != 4) && this.newValidSudoku[9 * (8 - i / 9) + (8 - i % 9)] == 0) {
				// the other end of our symmetric puzzle is already deleted
				continue;
			}
			// delete cell
			this.newValidSudoku[i] = 0;
			remainingClues--;
			int symm = 0;
			if (isSymmetric && (i / 9 != 4 || i % 9 != 4)) {
				symm = 9 * (8 - i / 9) + (8 - i % 9);
				this.newValidSudoku[symm] = 0;
				used[symm] = true;
				usedCount--;
				remainingClues--;
			}
			this.solve(this.newValidSudoku);
			if (this.solutionCount > 1) {
				this.newValidSudoku[i] = this.newFullSudoku[i];
				remainingClues++;
				if (isSymmetric && (i / 9 != 4 || i % 9 != 4)) {
					this.newValidSudoku[symm] = this.newFullSudoku[symm];
					remainingClues++;
				}
			}
		}
	}

	/**
	 * Sets all Singles that have been exposed by a previous operation. All
	 * Singles exposed by the method itself are set too.
	 *
	 * @param sudoku
	 * @return <code>false</code>, if the puzzle has become invalid.
	 */
	private boolean setAllExposedSingles(final Sudoku2 sudoku) {
		boolean valid = true;
		final SudokuSinglesQueue nsQueue = sudoku.getNsQueue();
		final SudokuSinglesQueue hsQueue = sudoku.getHsQueue();
		do {
			int singleIndex = 0;
			// first all Naked Singles
			while (valid && (singleIndex = nsQueue.getSingle()) != -1) {
				final int index = nsQueue.getIndex(singleIndex);
				final int value = nsQueue.getValue(singleIndex);
				if ((sudoku.getCell(index) & Sudoku2.MASKS[value]) != 0) {
					// only set the cell if the Single is still valid
					valid = sudoku.setCell(index, value, false, false);
				}
			}
			// then all Hidden Singles
			while (valid && (singleIndex = hsQueue.getSingle()) != -1) {
				final int index = hsQueue.getIndex(singleIndex);
				final int value = hsQueue.getValue(singleIndex);
				if ((sudoku.getCell(index) & Sudoku2.MASKS[value]) != 0) {
					// only set the cell if the Single is still valid
					valid = sudoku.setCell(index, value, false, false);
				}
			}
		} while (valid && !(nsQueue.isEmpty() && hsQueue.isEmpty()));
		return valid;
	}

	public int getSolutionCount() {
		return this.solutionCount;
	}

	public int[] getSolution() {
		return this.solution;
	}

	public String getSolutionAsString() {
		return this.getSolutionAsString(this.solution);
	}

	public String getSolutionAsString(final int[] array) {
		final StringBuilder temp = new StringBuilder();
		for (int i = 0; i < array.length; i++) {
			temp.append("").append(array[i]);
		}
		return temp.toString();
	}

}
