/*
 * Copyright (C) 2008-12  Bernhard Hobiger
 *
 * This file is part of HoDoKu.
 *
 * HoDoKu is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * HoDoKu is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with HoDoKu. If not, see <http://www.gnu.org/licenses/>.
 */

package sudoku.hodokuport.generator;

import java.util.List;

import sudoku.hodokuport.model.ClipboardMode;
import sudoku.hodokuport.model.DifficultyLevel;
import sudoku.hodokuport.model.GameMode;
import sudoku.hodokuport.model.Options;
import sudoku.hodokuport.model.SolutionStep;
import sudoku.hodokuport.model.Sudoku2;
import sudoku.hodokuport.solver.SudokuSolver;

/**
 * A BackgroundGenerator generates sudokus with a given {@link DifficultyLevel}
 * and for a given {@link GameMode}. An instance of this class can be contained
 * within a {@link BackgroundGeneratorThread} or within a
 * {@link GenerateSudokuProgressDialog}.<br>
 * If it is called from a {@link GenerateSudokuProgressDialog}, it uses the
 * default solver and reports the progress to the dialog. If a puzzle has been
 * found, the dialog is closed. The creation process can be aborted at any
 * time.<br>
 * If it is called from a {@link BackgroundGeneratorThread}, it simply delivers
 * the generated puzzle or <code>null</code>, if no puzzle could be found.
 */
public final class PuzzleGenerator {

	private static PuzzleGenerator instance;

	public static PuzzleGenerator getInstance() {
		if (instance == null) {
			instance = new PuzzleGenerator();
		}
		return instance;
	}

	public PuzzleGenerator() {
		// Nothing to do.
	}

	/**
	 * Creates a sudoku with the given difficulty level and game mode.
	 */
	public String generate(final DifficultyLevel level, final GameMode mode) {
		Sudoku2 sudoku = null;
		SudokuGenerator creator = null;
		SudokuSolver solver = null;
		solver = SudokuSolver.getInstance();
		creator = SudokuGeneratorFactory.getDefaultGeneratorInstance();
		sudoku = creator.generateSudoku(true);
		if (sudoku == null) {
			// impossible to create sudoku due to an invalid pattern
			return null;
		}
		final Sudoku2 solvedSudoku = sudoku.clone();
		final boolean ok = solver.solve(level, solvedSudoku, true, false, Options.getInstance().solverSteps, mode);
		boolean containsTrainingStep = true;
		if (mode != GameMode.PLAYING) {
			containsTrainingStep = false;
			final List<SolutionStep> steps = solver.getSteps();
			for (final SolutionStep step : steps) {
				if (step.getType().getStepConfig().isEnabledTraining()) {
					containsTrainingStep = true;
					break;
				}
			}
		}
		if (ok && containsTrainingStep
				&& (solvedSudoku.getLevel().getOrdinal() == level.getOrdinal() || mode == GameMode.LEARNING)) {
			sudoku.setLevel(solvedSudoku.getLevel());
			sudoku.setScore(solvedSudoku.getScore());
		}

		SudokuGeneratorFactory.giveBack(creator);
		return sudoku.getSudoku(ClipboardMode.CLUES_ONLY);
	}

}
