/*
 * Copyright (C) 2008-12  Bernhard Hobiger
 *
 * This file is part of HoDoKu.
 *
 * HoDoKu is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * HoDoKu is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with HoDoKu. If not, see <http://www.gnu.org/licenses/>.
 */

package solver;

import java.io.BufferedWriter;
import java.io.PrintStream;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import sudoku.DifficultyLevel;
import sudoku.DifficultyType;
import sudoku.GameMode;
import sudoku.Options;
import sudoku.SolutionCategory;
import sudoku.SolutionStep;
import sudoku.SolutionType;
import sudoku.StepConfig;
import sudoku.Sudoku2;
import sudoku.SudokuUtil;

/**
 *
 * @author hobiwan
 */
public class SudokuSolver {
	private final SudokuStepFinder stepFinder = new SudokuStepFinder();
	private Sudoku2 sudoku;
	private List<SolutionStep> steps = new ArrayList<SolutionStep>();
	private final List<SolutionStep> tmpSteps = new ArrayList<SolutionStep>(); // can
																																							// be
																																							// freely
																																							// changed
	private DifficultyLevel level = Options.getInstance().getDifficultyLevel(DifficultyType.EXTREME.ordinal());
	private DifficultyLevel maxLevel = Options.getInstance().getDifficultyLevel(DifficultyType.EXTREME.ordinal());
	private int score;
	private int[] anzSteps = new int[Options.getInstance().solverSteps.length];
	private final int[] anzStepsProgress = new int[Options.getInstance().solverSteps.length];
	private final long[] stepsNanoTime = new long[Options.getInstance().solverSteps.length];

	/** Creates a new instance of SudokuSolver */
	public SudokuSolver() {
	}

	/**
	 * If the time to solve the sudoku exceeds a certain limit (2s), a progress
	 * dialog is displayed. The dialog is created anyway, it starts the solver in
	 * a seperate thread. If the thread does not complete in a given time,
	 * setVisible(true) is called.
	 *
	 * @param withGui
	 * @return
	 */
	public boolean solve(final boolean withGui) {
		if (!withGui) {
			return this.solve();
		}

		return true;
	}

	/**
	 * Solves the sudoku without any restrictions.
	 *
	 * @return
	 */
	public boolean solve() {
		return this.solve(Options.getInstance().getDifficultyLevel(DifficultyType.EXTREME.ordinal()), null, false, false);
	}

	/**
	 * Tries to solve the sudoku using only singles.<br>
	 * The internal variables are not changed
	 *
	 * @param newSudoku
	 * @return
	 */
	public boolean solveSinglesOnly(final Sudoku2 newSudoku) {
		final Sudoku2 tmpSudoku = this.sudoku;
		final List<SolutionStep> oldList = this.steps;
		// sudoku = newSudoku;
		this.setSudoku(newSudoku);
		this.steps = this.tmpSteps;
		SudokuUtil.clearStepListWithNullify(this.steps);
		final boolean solved = this.solve(Options.getInstance().getDifficultyLevel(DifficultyType.EXTREME.ordinal()), null,
				false, true);
		this.steps = oldList;
		// sudoku = tmpSudoku;
		this.setSudoku(tmpSudoku);
		return solved;
	}

	/**
	 * Tries to solve the sudoku using only singles.<br>
	 * The internal variables are not changed
	 *
	 * @param newSudoku
	 * @param stepConfigs
	 * @return
	 */
	public boolean solveWithSteps(final Sudoku2 newSudoku, final StepConfig[] stepConfigs) {
		final Sudoku2 tmpSudoku = this.sudoku;
		final List<SolutionStep> oldList = this.steps;
		// sudoku = newSudoku;
		this.setSudoku(newSudoku);
		this.steps = this.tmpSteps;
		SudokuUtil.clearStepListWithNullify(this.steps);
		// boolean solved =
		// solve(Options.getInstance().getDifficultyLevels()[DifficultyType.EXTREME.ordinal()],
		// null, false, null, true);
		final boolean solved = this.solve(Options.getInstance().getDifficultyLevel(DifficultyType.EXTREME.ordinal()), null,
				false, false, stepConfigs, GameMode.PLAYING);
		this.steps = oldList;
		// sudoku = tmpSudoku;
		this.setSudoku(tmpSudoku);
		return solved;
	}

	/**
	 * Solves a sudoku using all available techniques.
	 *
	 * @param maxLevel
	 * @param tmpSudoku
	 * @param rejectTooLowScore
	 * @param dlg
	 * @return
	 */
	public boolean solve(final DifficultyLevel maxLevel, final Sudoku2 tmpSudoku, final boolean rejectTooLowScore) {
		return this.solve(maxLevel, tmpSudoku, rejectTooLowScore, false);
	}

	/**
	 * Solves a sudoku using all available techniques.
	 *
	 * @param maxLevel
	 * @param tmpSudoku
	 * @param rejectTooLowScore
	 * @param dlg
	 * @param singlesOnly
	 * @return
	 */
	public boolean solve(final DifficultyLevel maxLevel, final Sudoku2 tmpSudoku, final boolean rejectTooLowScore,
			final boolean singlesOnly) {
		return this.solve(maxLevel, tmpSudoku, rejectTooLowScore, singlesOnly, Options.getInstance().solverSteps,
				GameMode.PLAYING);
	}

	/**
	 * The real solver method. Can reject a possible solution if the
	 * {@link DifficultyLevel} doesnt match or if the score of the sudoku is too
	 * low. If a progress dialog is passed in, the counters in the dialog are
	 * updated.<br>
	 * If <code>stepConfig</code> is {@link Options#solverStepsProgress}, the
	 * method can be used to measure progress or find backdoors.<br>
	 * If the <code>gameMode</code> is any other than <code>PLAYING</code>, any
	 * puzzle is accepted, that contains at least one step with
	 * <code>StepConfig.isEnabledTraining()</code> true.
	 *
	 * @param maxLevel
	 * @param tmpSudoku
	 * @param rejectTooLowScore
	 * @param dlg
	 * @param singlesOnly
	 * @param stepConfigs
	 * @param gameMode
	 * @return
	 */
	public boolean solve(final DifficultyLevel maxLevel, final Sudoku2 tmpSudoku, final boolean rejectTooLowScore,
			final boolean singlesOnly, final StepConfig[] stepConfigs, final GameMode gameMode) {
		if (tmpSudoku != null) {
			this.setSudoku(tmpSudoku);
		}
		// System.out.println(" Solver started (" + maxLevel.getName() + "/" +
		// rejectTooLowScore + "/" + singlesOnly + "/" + gameMode.name() + ")!");

		// Eine Lösung wird nur gesucht, wenn zumindest 10 Kandidaten gesetzt sind
		final int anzCells = this.sudoku.getUnsolvedCellsAnz();
		if ((81 - anzCells) < 10) {
			// System.out.println(" less than 10 cells set!");
			return false;
		}
		final int anzCand = this.sudoku.getUnsolvedCandidatesAnz();

		this.maxLevel = maxLevel;
		this.score = 0;
		this.level = Options.getInstance().getDifficultyLevel(DifficultyType.EASY.ordinal());

		// SudokuUtil.clearStepList(steps);
		SolutionStep step = null;

		for (int i = 0; i < this.anzSteps.length; i++) {
			this.anzSteps[i] = 0;
		}

		boolean acceptAnyway = false;
		// System.out.println("Start solving (" + gameMode + ")!");

		do {
			// show progress if progress dialog is enabled

			// jetzt eine Methode nach der anderen, aber immer nur einmal; wenn etwas
			// gefunden wurde continue
			step = this.getHint(singlesOnly, stepConfigs, acceptAnyway);
			if (step != null) {
				// System.out.println("Step: " + step.toString(2));
				// System.out.println(sudoku.getSudoku(ClipboardMode.LIBRARY, step));
				if (gameMode != GameMode.PLAYING && step.getType().getStepConfig().isEnabledTraining()) {
					// System.out.println(" acceptAnyway = true!");
					acceptAnyway = true;
				}
				this.steps.add(step);
				this.getStepFinder().doStep(step);
				if (step.getType() == SolutionType.GIVE_UP) {
					step = null;
				}
			}
		} while (step != null);
		// wenn der Score größer als der MaxScore der aktuellen Stufe, dann wird
		// das
		// Puzzle höhergestuft.
		while (this.score > this.level.getMaxScore()) {
			this.level = Options.getInstance().getDifficultyLevel(this.level.getOrdinal() + 1);
		}
		// Puzzle zu schwer -> ungültig
		if (this.level.getOrdinal() > maxLevel.getOrdinal() && acceptAnyway == false) {
			// System.out.println(" rejected: to difficult");
			return false;
		}
		// umgekehrter Fall: Das Puzzle passt vom Level, aber der Score ist zu
		// niedrig (niedriger
		// als der MaxScore einer geringeren Stufe
		if (rejectTooLowScore && this.level.getOrdinal() > DifficultyType.EASY.ordinal() && acceptAnyway == false) {

			if (this.score < Options.getInstance().getDifficultyLevel(this.level.getOrdinal() - 1).getMaxScore()) {
				// System.out.println(" rejected: score too low");
				return false;
			}
		}
		this.sudoku.setScore(this.score);
		if (this.sudoku.isSolved()) {
			this.sudoku.setLevel(this.level);
			// System.out.println(" puzzle accepted!");
			return true;
		} else {
			this.sudoku.setLevel(Options.getInstance().getDifficultyLevel(DifficultyType.EXTREME.ordinal()));
			// System.out.println(" rejected: puzzle not solved!");
			return false;
		}
	}

	/**
	 * Calculates the progress scores of all steps in <code>steps</code> (see
	 * {@link #getProgressScoreSingles(sudoku.Sudoku2, sudoku.SolutionStep) }).
	 *
	 * @param tmpSudoku
	 * @param stepsTocheck
	 * @param dlg
	 */
	public void getProgressScore(final Sudoku2 tmpSudoku, final List<SolutionStep> stepsTocheck) {
		this.resetProgressStepCounters();
		int delta = stepsTocheck.size() / 10;
		if (delta == 0) {
			// avoid exceptions
			delta = 1;
		}
		final boolean oldCheckTemplates = Options.getInstance().isCheckTemplates();
		Options.getInstance().setCheckTemplates(false);
		long nanos = System.nanoTime();
		Sudoku2 workingSudoku = tmpSudoku.clone();
		for (int i = 0; i < stepsTocheck.size(); i++) {
			final SolutionStep step = stepsTocheck.get(i);
			workingSudoku.set(tmpSudoku);
			this.getProgressScore(workingSudoku, step);
		}
		Options.getInstance().setCheckTemplates(oldCheckTemplates);
		workingSudoku = null;
		nanos = System.nanoTime() - nanos;
		// System.out.println("getProgressScore(): " + (nanos / 1000000) + "ms (" +
		// steps.size() + ")");
		// for (SolutionStep step : steps) {
		// System.out.println("progressScore: " + step.getProgressScoreSinglesOnly()
		// + "/" +
		// step.getProgressScoreSingles() + "/" + step.getProgressScore() + " (" +
		// step + ")");
		// }
		// System.out.println("Timing:");
		// for (int i = 0; i < Options.getInstance().solverStepsProgress.length;
		// i++) {
		// if (anzStepsProgress[i] > 0) {
		// System.out.printf(" %5d/%8.2fus/%12.2fms: %s\r\n", anzStepsProgress[i],
		// (stepsNanoTime[i] / anzStepsProgress[i] / 1000.0),
		// (stepsNanoTime[i] / 1000000.0),
		// Options.getInstance().solverStepsProgress[i].getType().getStepName());
		// }
		// }
	}

	/**
	 * Calculates the progress score for <code>step</code>. The progress score is
	 * defined as the number of singles the step unlocks in the sudoku, if
	 * {@link Options#solverStepsProgress} is used.
	 *
	 * @param tmpSudoku
	 * @param orgStep
	 */
	public void getProgressScore(final Sudoku2 tmpSudoku, final SolutionStep orgStep) {
		final Sudoku2 save = this.sudoku;
		this.setSudoku(tmpSudoku);
		// System.out.println("getProgressScore start: " +
		// tmpSudoku.getSudoku(ClipboardMode.LIBRARY));
		// System.out.println(" Step = " + orgStep.toString(2));

		int progressScoreSingles = 0;
		int progressScoreSinglesOnly = 0;
		int progressScore = 0;
		boolean direct = true;
		// if step sets a cell it should count as single
		final SolutionType type = orgStep.getType();
		if (type == SolutionType.FORCING_CHAIN_VERITY || type == SolutionType.FORCING_NET_VERITY
				|| type == SolutionType.TEMPLATE_SET) {
			final int anz = orgStep.getIndices().size();
			progressScoreSingles += anz;
			progressScoreSinglesOnly += anz;
		}

		// execute the step
		this.getStepFinder().doStep(orgStep);
		// System.out.println(orgStep.getType().getStepName() + ":");
		// now solve as far as possible
		SolutionStep step = null;
		do {
			// jetzt eine Methode nach der anderen, aber immer nur einmal; wenn etwas
			// gefunden wurde continue
			step = this.getHint(false, Options.getInstance().solverStepsProgress, false);
			if (step != null) {
				// System.out.println(" step = " + step.toString(2));
				// System.out.println(" " + tmpSudoku.getSudoku(ClipboardMode.LIBRARY));
				if (step.getType().isSingle()) {
					progressScoreSingles++;
					if (direct) {
						progressScoreSinglesOnly++;
					}
				} else {
					direct = false;
				}
				progressScore += step.getType().getStepConfig().getBaseScore();
				// System.out.println(" " + step);
				this.getStepFinder().doStep(step);
				if (step.getType() == SolutionType.GIVE_UP) {
					step = null;
				}
			}
		} while (step != null);
		// set the score
		orgStep.setProgressScoreSingles(progressScoreSingles);
		orgStep.setProgressScoreSinglesOnly(progressScoreSinglesOnly);
		orgStep.setProgressScore(progressScore);

		this.setSudoku(save);
	}

	/**
	 * Get the next logical step for a given sudoku. If <code>singlesOnly</code>
	 * is set, only singles are tried.<br>
	 * The current state of the solver instance is saved and restored after the
	 * search is complete.
	 *
	 * @param sudoku
	 * @param singlesOnly
	 * @return
	 */
	public SolutionStep getHint(final Sudoku2 sudoku, final boolean singlesOnly) {
		final Sudoku2 save = this.sudoku;
		final DifficultyLevel oldMaxLevel = this.maxLevel;
		final DifficultyLevel oldLevel = this.level;
		this.maxLevel = Options.getInstance().getDifficultyLevel(DifficultyType.EXTREME.ordinal());
		this.level = Options.getInstance().getDifficultyLevel(DifficultyType.EASY.ordinal());
		this.setSudoku(sudoku);
		final SolutionStep step = this.getHint(singlesOnly);
		this.maxLevel = oldMaxLevel;
		this.level = oldLevel;
		this.setSudoku(save);
		return step;
	}

	/**
	 * Get the next logical step for the internal sudoku. If
	 * <code>singlesOnly</code> is set, only singles are tried.
	 *
	 * @param singlesOnly
	 * @return
	 */
	private SolutionStep getHint(final boolean singlesOnly) {
		return this.getHint(singlesOnly, Options.getInstance().solverSteps, false);
	}

	/**
	 * Get the next logical step for the internal sudoku. If
	 * <code>singlesOnly</code> is set, only singles are tried.<br>
	 * Since the steps are passed as argument this method can be used to calculate
	 * the next step and to calculate the progress measure for a given sudoku
	 * state.<br>
	 * Any step is accepted, if the GameMode is not GameMode.PLAYING and one of
	 * the training techniques is already in the solution.
	 *
	 * @param singlesOnly
	 * @param solverSteps
	 * @param acceptAnyway
	 * @return
	 */
	private SolutionStep getHint(final boolean singlesOnly, final StepConfig[] solverSteps, final boolean acceptAnyway) {
		if (this.sudoku.isSolved()) {
			return null;
		}
		SolutionStep hint = null;
		// System.out.println(" sudoku: " +
		// getStepFinder().getSudoku().getSudoku(ClipboardMode.VALUES_ONLY));

		for (int i = 0; i < solverSteps.length; i++) {
			if (solverSteps == Options.getInstance().solverStepsProgress) {
				if (solverSteps[i].isEnabledProgress() == false) {
					continue;
				}
			} else {
				if (solverSteps[i].isEnabled() == false) {
					// diesen Schritt nicht ausführen
					continue;
				}
			}
			final SolutionType type = solverSteps[i].getType();
			if (singlesOnly && (type != SolutionType.HIDDEN_SINGLE && type != SolutionType.NAKED_SINGLE
					&& type != SolutionType.FULL_HOUSE)) {
				continue;
			}
			Logger.getLogger(this.getClass().getName()).log(Level.FINER, "trying {0}: ", SolutionStep.getStepName(type));
			long nanos = System.nanoTime();
			hint = this.getStepFinder().getStep(type);
			nanos = System.nanoTime() - nanos;
			Logger.getLogger(this.getClass().getName()).log(Level.FINER, "{0}ms ({1})",
					new Object[] { nanos / 1000, hint != null ? hint.toString(2) : "-" });
			// if (nanos > 20000) {
			// Logger.getLogger(getClass().getName()).log(Level.FINE, "trying {0}:
			// {1}ms", new Object[]{SolutionStep.getStepName(type), nanos});
			// }
			this.anzStepsProgress[i]++;
			this.stepsNanoTime[i] += nanos;
			if (hint != null) {
				this.anzSteps[i]++;
				this.score += solverSteps[i].getBaseScore();
				if (Options.getInstance().getDifficultyLevels()[solverSteps[i].getLevel()].getOrdinal() > this.level
						.getOrdinal()) {
					this.level = Options.getInstance().getDifficultyLevels()[solverSteps[i].getLevel()];
				}
				// Wenn das Puzzle zu schwer ist, gleich abbrechen
				if (!acceptAnyway) {
					if (this.level.getOrdinal() > this.maxLevel.getOrdinal() || this.score >= this.maxLevel.getMaxScore()) {
						// zu schwer!
						return null;
					}
				}
				return hint;
			}
		}
		return null;
	}

	public void doStep(final Sudoku2 sudoku, final SolutionStep step) {
		// we mustnt call setSudoku() here or all internal
		// data structures get changed -> just set the field itself
		final Sudoku2 oldSudoku = this.getSudoku();
		// setSudoku(sudoku);
		this.getStepFinder().setSudoku(sudoku);
		this.getStepFinder().doStep(step);
		// setSudoku(oldSudoku);
		this.getStepFinder().setSudoku(oldSudoku);
	}

	public Sudoku2 getSudoku() {
		return this.sudoku;
	}

	public void setSudoku(final Sudoku2 sudoku, final List<SolutionStep> partSteps) {
		// not really sure whether the list may be cleared savely here...
		// SudokuUtil.clearStepList(steps);
		this.steps = new ArrayList<SolutionStep>();
		for (int i = 0; i < partSteps.size(); i++) {
			this.steps.add(partSteps.get(i));
		}
		this.sudoku = sudoku;
		this.getStepFinder().setSudoku(sudoku);
	}

	public void setSudoku(final Sudoku2 sudoku) {
		SudokuUtil.clearStepList(this.steps);
		for (int i = 0; i < this.anzSteps.length; i++) {
			this.anzSteps[i] = 0;
		}
		this.sudoku = sudoku;
		this.getStepFinder().setSudoku(sudoku);
	}

	public List<SolutionStep> getSteps() {
		return this.steps;
	}

	public int getAnzUsedSteps() {
		int anz = 0;
		for (int i = 0; i < this.anzSteps.length; i++) {
			if (this.anzSteps[i] > 0) {
				anz++;
			}
		}
		return anz;
	}

	public int[] getAnzSteps() {
		return this.anzSteps;
	}

	public int getScore() {
		return this.score;
	}

	public String getLevelString() {
		return StepConfig.getLevelName(this.level);
	}

	public DifficultyLevel getLevel() {
		return this.level;
	}

	public SolutionCategory getCategory(final SolutionType type) {
		for (final StepConfig configStep : Options.getInstance().solverSteps) {
			if (type == configStep.getType()) {
				return configStep.getCategory();
			}
		}
		return null;
	}

	public String getCategoryName(final SolutionType type) {
		final SolutionCategory cat = this.getCategory(type);
		if (cat == null) {
			return null;
		}
		return cat.getCategoryName();
	}

	public void setSteps(final List<SolutionStep> steps) {
		this.steps = steps;
	}

	public void setLevel(final DifficultyLevel level) {
		this.level = level;
	}

	public DifficultyLevel getMaxLevel() {
		return this.maxLevel;
	}

	public void setMaxLevel(final DifficultyLevel maxLevel) {
		this.maxLevel = maxLevel;
	}

	public void setScore(final int score) {
		this.score = score;
	}

	public void setAnzSteps(final int[] anzSteps) {
		this.anzSteps = anzSteps;
	}

	private void resetProgressStepCounters() {
		for (int i = 0; i < this.anzStepsProgress.length; i++) {
			this.anzStepsProgress[i] = 0;
			this.stepsNanoTime[i] = 0;
		}
	}

	/**
	 * @return the stepsNanoTime
	 */
	public long[] getStepsNanoTime() {
		return this.stepsNanoTime;
	}

	/**
	 * Prints runtime statistics for solver
	 *
	 * @param out
	 */
	public void printStatistics(final BufferedWriter out) {
		final PrintWriter pw = new PrintWriter(out);
		this.printStatistics(pw);
	}

	/**
	 * Prints runtime statistics for solver
	 *
	 * @param out
	 */
	public void printStatistics(final PrintStream out) {
		out.println();
		out.println("Timing:");
		for (int i = 0; i < Options.getInstance().solverSteps.length; i++) {
			if (this.anzStepsProgress[i] > 0) {
				out.printf("  %10d/%12.2fus/%12.2fms: %s\r\n", this.anzStepsProgress[i],
						(this.stepsNanoTime[i] / this.anzStepsProgress[i] / 1000.0), (this.stepsNanoTime[i] / 1000000.0),
						Options.getInstance().solverStepsProgress[i].getType().getStepName());
			}
		}
		out.println();
		// out.println(stepFinder.getAlsStatistics());
		// out.println(stepFinder.getRCStatistics());
		// out.println(AlsSolver.getStatistics());
	}

	/**
	 * Prints runtime statistics for solver
	 *
	 * @param out
	 */
	public void printStatistics(final PrintWriter out) {
		out.println();
		out.println("Timing:");
		for (int i = 0; i < Options.getInstance().solverSteps.length; i++) {
			if (this.anzStepsProgress[i] > 0) {
				out.printf("  %10d/%12.2fus/%12.2fms: %s\r\n", this.anzStepsProgress[i],
						(this.stepsNanoTime[i] / this.anzStepsProgress[i] / 1000.0), (this.stepsNanoTime[i] / 1000000.0),
						Options.getInstance().solverStepsProgress[i].getType().getStepName());
			}
		}
		out.println();
		// out.println(stepFinder.getAlsStatistics());
		// out.println(stepFinder.getRCStatistics());
		// out.println(AlsSolver.getStatistics());
	}

	/**
	 * @return the stepFinder
	 */
	public SudokuStepFinder getStepFinder() {
		return this.stepFinder;
	}
}
