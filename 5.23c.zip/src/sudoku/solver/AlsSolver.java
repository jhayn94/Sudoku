/*
 * Copyright (C) 2008-12  Bernhard Hobiger
 *
 * This file is part of HoDoKu.
 *
 * HoDoKu is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * HoDoKu is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with HoDoKu. If not, see <http://www.gnu.org/licenses/>.
 */
package sudoku.solver;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.SortedMap;
import java.util.TreeMap;

import sudoku.model.Als;
import sudoku.model.Candidate;
import sudoku.model.Chain;
import sudoku.model.Options;
import sudoku.model.SolutionStep;
import sudoku.model.Sudoku2;
import sudoku.model.SudokuSet;
import sudoku.model.util.SolutionTechnique;

public class AlsSolver extends AbstractSolver {

	/** Maximum number of RCs in an ALS-Chain (forward search only!) */
	private static final int MAX_RC = 50;
	/** A list holding all ALS present in the curent state of the gid. */
	private List<Als> alses = new ArrayList<>(500);
	/** A list with all restricted commons in the present grid. */
	private List<RestrictedCommon> restrictedCommons = new ArrayList<>(2000);
	/**
	 * The indices of the first RC in {@link #restrictedCommons} for every ALS in
	 * {@link #alses}.
	 */
	private int[] startIndices = null;
	/**
	 * The indices of the last RC in {@link #restrictedCommons} for every ALS in
	 * {@link #alses}.
	 */
	private int[] endIndices = null;
	/**
	 * all chains that have been found so far: eliminations and number of links
	 */
	private final SortedMap<String, Integer> deletesMap = new TreeMap<>();
	/**
	 * A special comparator used to find the "best" step out of a list of steps.
	 */
	private static AlsComparator alsComparator = null;
	/** A list with all steps found during the last run. */
	private List<SolutionStep> steps = new ArrayList<>();
	/** One step instance for optimization. */
	private final SolutionStep globalStep = new SolutionStep(SolutionTechnique.HIDDEN_SINGLE);
	/**
	 * The current ALS Chain: The chain consists only of its RCs. A chain cannot
	 * be longer than <code>chain.length</code>.
	 */
	private RestrictedCommon[] chain = new RestrictedCommon[MAX_RC];
	/** The index into {@link #chain} for the current search. */
	private int chainIndex = -1;
	/**
	 * The first RC in the current chain (always is {@link #chain}[0]; needed for
	 * test for eliminations, cached for performance reasons).
	 */
	private RestrictedCommon firstRC = null;
	/**
	 * Chain search: for every ALS already contained in the chain the respective
	 * index is true.
	 */
	private boolean[] alsInChain;
	/** The first ALS in the chain (needed for elimination checks). */
	private Als startAls;
	/** Current recursion depth for chain search. */
	private int recDepth = 0;
	/** Maximum recursion depth for chain search. */
	private int maxRecDepth = 0;
	/** All candidates occurring in both flanking ALS of an ALS step. */
	private short possibleRestrictedCommonsSet = 0;
	/**
	 * Holds all buddies of all candidate cells for one RC (including the
	 * candidate cells themselves).
	 */
	private final SudokuSet restrictedCommonBuddiesSet = new SudokuSet();
	/** All cells containing a specific candidate in two ALS. */
	private final SudokuSet restrictedCommonIndexSet = new SudokuSet();
	/**
	 * One instance of {@link RCForDeathBlossom} for every cell that is not yet
	 * set.
	 */
	private final RCForDeathBlossom[] rcdb = new RCForDeathBlossom[81];
	/** ALS for stem cell that is currently checked. */
	private RCForDeathBlossom aktRcdb = null;
	/** All indices of all ALS for a given stem cell (for recursive search). */
	private final SudokuSet aktDBIndices = new SudokuSet();
	/** All common candidates in the current combination of ALS. */
	private short aktDBCandidates = 0;
	/** The common candidates that were reduced by the current ALS. */
	private final short[] incDBCand = new short[10];
	/** The indices of all ALS in the current try of the Death Blossom search. */
	private final int[] aktDBAls = new int[10];
	/** All indices of all ALS in a DB for a given candidate. */
	private final SudokuSet dbIndicesPerCandidate = new SudokuSet();
	/**
	 * Maximum candidate for which a recursive search for DeathBlossom has to be
	 * made.
	 */
	private int maxDBCand = 0;
	/** The index of the current stem cell for Death Blossom. */
	private int stemCellIndex = 0;
	/** For various checks */
	private final SudokuSet tmpSet = new SudokuSet();
	/** For various checks */
	private final SudokuSet tmpSet1 = new SudokuSet();

	/**
	 * Creates a new instance of AlsSolver
	 *
	 * @param finder
	 */
	public AlsSolver(final SudokuStepFinder finder) {
		super(finder);
		if (alsComparator == null) {
			alsComparator = new AlsComparator();
		}
	}

	@Override
	protected SolutionStep getStep(final SolutionTechnique type) {
		SolutionStep result = null;
		this.sudoku = this.finder.getSudoku();
		// normal search: only forward references
		this.finder.setRcOnlyForward(true);
		switch (type) {
		case ALS_XZ:
			result = this.getAlsXZ(true);
			break;
		case ALS_XY_WING:
			result = this.getAlsXYWing(true);
			break;
		case ALS_XY_CHAIN:
			if (this.chain.length != MAX_RC) {
				this.chain = new RestrictedCommon[MAX_RC];
			}
			result = this.getAlsXYChain();
			break;
		case DEATH_BLOSSOM:
			result = this.getAlsDeathBlossom(true);
			break;
		default: // Nothing to do.
		}
		return result;
	}

	@Override
	protected boolean doStep(final SolutionStep step) {
		boolean handled = true;
		this.sudoku = this.finder.getSudoku();
		switch (step.getType()) {
		case ALS_XZ:
		case ALS_XY_WING:
		case ALS_XY_CHAIN:
		case DEATH_BLOSSOM:
			for (final Candidate cand : step.getCandidatesToDelete()) {
				this.sudoku.delCandidate(cand.getIndex(), cand.getValue());
			}
			break;
		default:
			handled = false;
		}
		return handled;
	}

	/**
	 * Finds all ALS steps except Death Blossom present in the current grid. The
	 * parameters specify, which types should be searched.
	 */
	protected List<SolutionStep> getAllAlses(final boolean doXz, final boolean doXy, final boolean doChain) {
		this.sudoku = this.finder.getSudoku();
		final List<SolutionStep> oldSteps = this.steps;
		final List<SolutionStep> resultSteps = new ArrayList<>();
		this.finder.setRcOnlyForward(Options.getInstance().isAllStepsAlsChainForwardOnly());
		if (this.chain.length == MAX_RC) {
			this.chain = new RestrictedCommon[Options.getInstance().getAllStepsAlsChainLength()];
		}
		this.collectAllAlses();
		this.collectAllRestrictedCommons(Options.getInstance().isAllowAlsOverlap());
		if (doXz) {
			this.steps.clear();
			this.getAlsXZInt(false);
			Collections.sort(this.steps, alsComparator);
			resultSteps.addAll(this.steps);
		}
		if (doXy) {
			this.steps.clear();
			this.getAlsXYWingInt(false);
			Collections.sort(this.steps, alsComparator);
			resultSteps.addAll(this.steps);
		}
		if (doChain) {
			this.steps.clear();
			this.getAlsXYChainInt();
			Collections.sort(this.steps, alsComparator);
			resultSteps.addAll(this.steps);
		}
		this.steps = oldSteps;
		return resultSteps;
	}

	/**
	 * Finds all Death Blossoms present in the current grid.
	 */
	protected List<SolutionStep> getAllDeathBlossoms() {
		this.sudoku = this.finder.getSudoku();
		final List<SolutionStep> oldSteps = this.steps;
		final List<SolutionStep> resultSteps = new ArrayList<>();
		this.collectAllAlses();
		this.collectAllRCsForDeathBlossom();
		this.steps.clear();
		this.getAlsDeathBlossomInt(false);
		Collections.sort(this.steps, alsComparator);
		resultSteps.addAll(this.steps);
		this.steps = oldSteps;
		return resultSteps;
	}

	/**
	 * Finds the next Death Blossom. If <code>onlyOne</code> is set, the search
	 * stops after the first occurrence has been found.
	 *
	 * @return Next step or <code>null</code> if no step could be found.
	 */
	private SolutionStep getAlsDeathBlossom(final boolean onlyOne) {
		this.steps.clear();
		this.collectAllAlses();
		this.collectAllRCsForDeathBlossom();
		SolutionStep step = this.getAlsDeathBlossomInt(onlyOne);
		if (!onlyOne && !this.steps.isEmpty()) {
			Collections.sort(this.steps, alsComparator);
			step = this.steps.get(0);
		}
		return step;
	}

	/**
	 * Finds the next ALS Chain.
	 *
	 * @return Next step or <code>null</code> if no step could be found.
	 */
	private SolutionStep getAlsXYChain() {
		this.steps.clear();
		this.collectAllAlses();
		this.collectAllRestrictedCommons(Options.getInstance().isAllowAlsOverlap());
		this.getAlsXYChainInt();
		if (!this.steps.isEmpty()) {
			Collections.sort(this.steps, alsComparator);
			return this.steps.get(0);
		} else {
			return null;
		}
	}

	/**
	 * Finds the next ALS XY-Wing. If <code>onlyOne</code> is set, the search
	 * stops after the first occurrence has been found.
	 *
	 * @param onlyOne
	 * @return Next step or <code>null</code> if no step could be found.
	 */
	private SolutionStep getAlsXYWing(final boolean onlyOne) {
		this.steps.clear();
		this.collectAllAlses();
		this.collectAllRestrictedCommons(Options.getInstance().isAllowAlsOverlap());
		SolutionStep step = this.getAlsXYWingInt(onlyOne);
		if (!onlyOne && !this.steps.isEmpty()) {
			Collections.sort(this.steps, alsComparator);
			step = this.steps.get(0);
		}
		return step;
	}

	/**
	 * Finds the next ALS XZ. If <code>onlyOne</code> is set, the search stops
	 * after the first occurrence has been found.
	 *
	 * @param onlyOne
	 * @return Next step or <code>null</code> if no step could be found.
	 */
	private SolutionStep getAlsXZ(final boolean onlyOne) {
		this.steps.clear();
		this.collectAllAlses();
		this.collectAllRestrictedCommons(Options.getInstance().isAllowAlsOverlap());
		SolutionStep step = this.getAlsXZInt(onlyOne);
		if (!onlyOne && !this.steps.isEmpty()) {
			Collections.sort(this.steps, alsComparator);
			step = this.steps.get(0);
		}
		return step;
	}

	/**
	 * Check all restricted commons: For every RC check all candidates common to
	 * both ALS but minus the RC candidate(s). If buddies exist outside the ALS
	 * they can be eliminated.<br>
	 *
	 * Doubly linked ALS-XZ: If two ALS are linked by 2 RCs, the rest of each ALS
	 * becomes a locked set and eliminates additional candidates; plus each of the
	 * two RCs can be used for "normal" ALS-XZ eliminations.<br>
	 *
	 * @param onlyOne
	 *          If <code>true</code> the search stops after the first step was
	 *          found.
	 * @return The first step found or null
	 */
	private SolutionStep getAlsXZInt(final boolean onlyOne) {
		this.globalStep.reset();
		for (int i = 0; i < this.restrictedCommons.size(); i++) {
			final RestrictedCommon rc = this.restrictedCommons.get(i);
			// only forward check necessary
			if (rc.getAls1() > rc.getAls2()) {
				continue;
			}
			final Als als1 = this.alses.get(rc.getAls1());
			final Als als2 = this.alses.get(rc.getAls2());
			this.checkCandidatesToDelete(als1, als2, rc.getCand1());
			if (rc.getCand2() != 0) {
				// als1 and als2 are doubly linked -> check for additional eliminations
				this.checkCandidatesToDelete(als1, als2, rc.getCand2());
				final boolean d1 = this.checkDoublyLinkedAls(als1, als2, rc.getCand1(), rc.getCand2());
				final boolean d2 = this.checkDoublyLinkedAls(als2, als1, rc.getCand1(), rc.getCand2());
				if (d1 || d2) {
					// no common candidates for doublylinked als-xz
					this.globalStep.getFins().clear();
				}
			}
			if (!this.globalStep.getCandidatesToDelete().isEmpty()) {
				this.globalStep.setType(SolutionTechnique.ALS_XZ);
				this.globalStep.addAls(als1.indices, als1.candidates);
				this.globalStep.addAls(als2.indices, als2.candidates);
				this.addRestrictedCommonToStep(als1, als2, rc.getCand1(), false);
				if (rc.getCand2() != 0) {
					this.addRestrictedCommonToStep(als1, als2, rc.getCand2(), false);
				}
				final SolutionStep step = (SolutionStep) this.globalStep.clone();
				if (onlyOne) {
					return step;
				}
				this.steps.add(step);
				this.globalStep.reset();
			}
		}
		return null;
	}

	/**
	 * Check all combinations of two RCs and check whether it is possible to
	 * construct an ALS XY-Wing:
	 * <ul>
	 * <li>we need three different ALS</li>
	 * <li>if RC1 and RC2 both have only one candidate that candidate must
	 * differ</li>
	 * </ul>
	 *
	 * If a valid combination could be found, identify ALS C and check ALS A and B
	 * for possible eliminations.
	 *
	 * @param onlyOne
	 *          If <code>true</code> the search stops after the first step was
	 *          found.
	 * @return The first step found or null
	 */
	private SolutionStep getAlsXYWingInt(final boolean onlyOne) {
		this.globalStep.reset();
		for (int i = 0; i < this.restrictedCommons.size(); i++) {
			final RestrictedCommon rc1 = this.restrictedCommons.get(i);
			for (int j = i + 1; j < this.restrictedCommons.size(); j++) {
				final RestrictedCommon rc2 = this.restrictedCommons.get(j);
				// at least two different candidates in rc1 and rc2!
				// must always be true, if the two rcs have a different
				// number of digits.
				if (rc1.getCand2() == 0 && rc2.getCand2() == 0 && rc1.getCand1() == rc2.getCand1()) {
					// both RCs have only one digit and the digits dont differ
					continue;
				}
				// the two RCs have to connect 3 different ALS; since
				// rc1.als1 != rc1.als2 && rc2.als1 != rc2.als2 not many possibilites
				// are left
				if (!((rc1.getAls1() == rc2.getAls1() && rc1.getAls2() != rc2.getAls2())
						|| (rc1.getAls2() == rc2.getAls1() && rc1.getAls1() != rc2.getAls2())
						|| (rc1.getAls1() == rc2.getAls2() && rc1.getAls2() != rc2.getAls1())
						|| (rc1.getAls2() == rc2.getAls2() && rc1.getAls1() != rc2.getAls1()))) {
					// cant be an XY-Wing
					continue;
				}
				// Identify C so we can check for eliminations
				Als a = null;
				Als b = null;
				Als c = null;
				if (rc1.getAls1() == rc2.getAls1()) {
					c = this.alses.get(rc1.getAls1());
					a = this.alses.get(rc1.getAls2());
					b = this.alses.get(rc2.getAls2());
				}
				if (rc1.getAls1() == rc2.getAls2()) {
					c = this.alses.get(rc1.getAls1());
					a = this.alses.get(rc1.getAls2());
					b = this.alses.get(rc2.getAls1());
				}
				if (rc1.getAls2() == rc2.getAls1()) {
					c = this.alses.get(rc1.getAls2());
					a = this.alses.get(rc1.getAls1());
					b = this.alses.get(rc2.getAls2());
				}
				if (rc1.getAls2() == rc2.getAls2()) {
					c = this.alses.get(rc1.getAls2());
					a = this.alses.get(rc1.getAls1());
					b = this.alses.get(rc2.getAls1());
				}
				if (!Options.getInstance().isAllowAlsOverlap()) {
					// Check overlaps: the RCs have already been checked, a and b are
					// missing:
					this.tmpSet.set(a.indices);
					if (!this.tmpSet.andEmpty(b.indices)) {
						// overlap -> not allowed
						continue;
					}
				}
				// even if overlaps are allowed, a(b) must not be a subset of b (a)
				this.tmpSet.set(a.indices);
				this.tmpSet.or(b.indices);
				if (this.tmpSet.equals(a.indices) || this.tmpSet.equals(b.indices)) {
					continue;
				}
				// now check candidates of A and B
				this.checkCandidatesToDelete(a, b, rc1.getCand1(), rc1.getCand2(), rc2.getCand1(), rc2.getCand2());
				if (!this.globalStep.getCandidatesToDelete().isEmpty()) {
					this.globalStep.setType(SolutionTechnique.ALS_XY_WING);
					this.globalStep.addAls(a.indices, a.candidates);
					this.globalStep.addAls(b.indices, b.candidates);
					this.globalStep.addAls(c.indices, c.candidates);
					this.addRestrictedCommonToStep(a, c, rc1.getCand1(), false);
					if (rc1.getCand2() != 0) {
						this.addRestrictedCommonToStep(a, c, rc1.getCand2(), false);
					}
					this.addRestrictedCommonToStep(b, c, rc2.getCand1(), false);
					if (rc2.getCand2() != 0) {
						this.addRestrictedCommonToStep(b, c, rc2.getCand2(), false);
					}
					final SolutionStep step = (SolutionStep) this.globalStep.clone();
					if (onlyOne) {
						return step;
					}
					this.steps.add(step);
					this.globalStep.reset();
				}
			}
		}
		return null;
	}

	/**
	 * Check all combinations starting with every ALS. The following rules are
	 * applied:
	 * <ul>
	 * <li>Two adjacent ALS may overlap as long as the overlapping area doesnt
	 * contain an RC</li>
	 * <li>Two non adjacent ALS may overlap without restrictions</li>
	 * <li>If the first and last ALS are identical or if the first ALS is
	 * contained in the last or vice versa the chain becomes a loop -> currently
	 * not implemented</li>
	 * <li>Two adjacent RCs must follow the adjency rules (see below)</li>
	 * <li>each chain must be at least 4 ALS long (2 is an XZ, 3 is an
	 * XY-Wing)</li>
	 * <li>start and end ALS must have a common candidate that exists outside the
	 * chain -> can be eliminated (the candidate can be eliminated from the chain
	 * as well but not from the start and end ALS -> cannibalistic ALS-chain)</li>
	 * </ul>
	 *
	 * Adjacency rules for RCs joining ALS1 and ALS2:
	 * <ul>
	 * <li>get all RCs between ALS1 and ALS2 ("possible RCs" - "PRC")</li>
	 * <li>subtract the "actual RCs" ("ARC") of the previous step; the remainder
	 * becomes the new ARC(s)</li>
	 * <li>if no ARC is left, the chain ends at ALS1</li>
	 * </ul>
	 *
	 * If a new ALS is already contained within the chain, the chain becomes a
	 * whip (not handled)<br>
	 * Its unclear whether the search has to go in both directions (currently only
	 * one direction is done since RCs are collected only in one direction).
	 */
	private void getAlsXYChainInt() {
		this.recDepth = 0;
		this.maxRecDepth = 0;
		this.deletesMap.clear();
		for (int i = 0; i < this.alses.size(); i++) {
			this.startAls = this.alses.get(i);
			this.chainIndex = 0;
			if (this.alsInChain == null || this.alsInChain.length < this.alses.size()) {
				this.alsInChain = new boolean[this.alses.size()];
			} else {
				Arrays.fill(this.alsInChain, false);
			}
			this.alsInChain[i] = true;
			this.firstRC = null;
			this.getAlsXYChainRecursive(i, null);
		}
	}

	/**
	 * Real search: for als with index alsIndex check all RCs. If the RC fulfills
	 * the adjacency rules and the als to which the RC points is not already part
	 * of the chain, the als is added and the search is continued recursively.
	 * When the chain size reaches 4, every step is tested for possible
	 * eliminations.<br>
	 * <br>
	 *
	 * Caution: If the first RC has two candidates, both of them have to be tried
	 * independently.
	 *
	 * @param alsIndex
	 *          index of the last added ALS
	 * @param lastRC
	 *          RC of the last step (needed for adjacency check)
	 */
	private void getAlsXYChainRecursive(final int alsIndex, final RestrictedCommon lastRC) {
		// check for end of recursion
		// wrong condition: the chain ends, when it becomes too long!
		if (this.chainIndex >= this.chain.length) {
			// no space left -> stop it!
			return;
		}
		this.recDepth++;
		if (this.recDepth > this.maxRecDepth) {
			this.maxRecDepth = this.recDepth;
		}
		if (this.recDepth % 100 == 0) {
		}
		// check all RCs; if none exist the loop is never entered
		boolean firstTry = true;
		for (int i = this.startIndices[alsIndex]; i < this.endIndices[alsIndex]; i++) {
			final RestrictedCommon rc = this.restrictedCommons.get(i);
			if (this.chainIndex >= this.chain.length || !rc.checkRC(lastRC, firstTry)) {
				// chain is full or RC doesnt adhere to the adjacency rules
				continue;
			}
			if (this.alsInChain[rc.getAls2()]) {
				// ALS already part of the chain -> whips are not handled!
				continue;
			}
			final Als aktAls = this.alses.get(rc.getAls2());

			// ok, ALS can be added
			if (this.chainIndex == 0) {
				this.firstRC = rc;
			}
			this.chain[this.chainIndex++] = rc;
			this.alsInChain[rc.getAls2()] = true;
			// if the chain length has reached at least 4 RCs check for candidates to
			// eliminate
			if (this.chainIndex >= 3) {
				this.globalStep.getCandidatesToDelete().clear();
				int c1 = this.firstRC.getCand1();
				int c2 = this.firstRC.getCand2();
				int c3 = 0;
				int c4 = 0;

				if (this.firstRC.getActualRC() == 1) {
					c2 = 0;
				} else if (this.firstRC.getActualRC() == 2) {
					c1 = 0;
				}
				if (rc.getActualRC() == 1) {
					c3 = rc.getCand1();
				} else if (rc.getActualRC() == 2) {
					c3 = rc.getCand2();
				} else if (rc.getActualRC() == 3) {
					c3 = rc.getCand1();
					c4 = rc.getCand2();
				}
				this.checkCandidatesToDelete(this.startAls, aktAls, c1, c2, c3, c4, null);
				if (!this.globalStep.getCandidatesToDelete().isEmpty()) {
					// chain found: build it and write it
					this.globalStep.setType(SolutionTechnique.ALS_XY_CHAIN);
					this.globalStep.addAls(this.startAls.indices, this.startAls.candidates);
					Als tmpAls = this.startAls;
					for (int j = 0; j < this.chainIndex; j++) {
						final Als tmp = this.alses.get(this.chain[j].getAls2());
						this.globalStep.addAls(tmp.indices, tmp.candidates);
						this.globalStep.addRestrictedCommon((RestrictedCommon) this.chain[j].clone());

						if (this.chain[j].getActualRC() == 1 || this.chain[j].getActualRC() == 3) {
							this.addRestrictedCommonToStep(tmpAls, tmp, this.chain[j].getCand1(), true);
						}
						if (this.chain[j].getActualRC() == 2 || this.chain[j].getActualRC() == 3) {
							this.addRestrictedCommonToStep(tmpAls, tmp, this.chain[j].getCand2(), true);
						}
						tmpAls = tmp;
					}

					// check if we already have a chain for the given set of eliminations.
					// if we do, the new chain is only written, if it is shorter than the
					// old one.
					boolean writeIt = true;
					int replaceIndex = -1;
					String elim = null;
					if (Options.getInstance().isOnlyOneAlsPerStep()) {
						elim = this.globalStep.getCandidateString();
						final Integer alreadyThere = this.deletesMap.get(elim);
						if (alreadyThere != null) {
							// a step already exists!
							final SolutionStep tmp = this.steps.get(alreadyThere);
							if (tmp.getAlsesIndexCount() > this.globalStep.getAlsesIndexCount()) {
								writeIt = true;
								replaceIndex = alreadyThere;
							} else {
								writeIt = false;
							}
						}
					}
					if (writeIt) {
						if (replaceIndex != -1) {
							this.steps.remove(replaceIndex);
							this.steps.add(replaceIndex, (SolutionStep) this.globalStep.clone());
						} else {
							this.steps.add((SolutionStep) this.globalStep.clone());
							if (elim != null) {
								this.deletesMap.put(elim, this.steps.size() - 1);
							}
						}
					}
					this.globalStep.reset();
				}
			}

			// and to the next level...
			this.getAlsXYChainRecursive(rc.getAls2(), rc);

			// and back one level
			this.alsInChain[rc.getAls2()] = false;
			this.chainIndex--;

			if (lastRC == null) {
				if (rc.getCand2() != 0 && firstTry) {
					// first RC in chain and a second RC is present: try it!
					firstTry = false;
					i--;
				} else {
					firstTry = true;
				}
			}
		}
		this.recDepth--;
	}

	/**
	 * Searches for all available Death blossoms: if a cell exists that has at
	 * least one ALS for every candidate check all combinations of available ALS
	 * for that cell. Any combination of (non overlapping) ALS has to be checked
	 * for common candidates that can eliminate candidates outside the ALS and the
	 * stem cell.<br>
	 * <br>
	 *
	 * The ALS/cell combinations must already have been written to {@link #rcdb}.
	 */
	private SolutionStep getAlsDeathBlossomInt(final boolean onlyOne) {
		this.deletesMap.clear();
		this.globalStep.reset();
		this.globalStep.setType(SolutionTechnique.DEATH_BLOSSOM);
		for (int i = 0; i < Sudoku2.LENGTH; i++) {
			if (this.sudoku.getValue(i) != 0) {
				// cell already set -> ignore
				continue;
			}
			if (this.rcdb[i] == null || this.sudoku.getCells()[i] != this.rcdb[i].candMask) {
				// the cell cant see any ALS or
				// there are candidates left without ALS -> impossible
				continue;
			}
			// ok here it starts: try all combinations of ALS
			this.stemCellIndex = i;
			this.aktRcdb = this.rcdb[i];
			this.maxDBCand = 0;
			for (int j = 1; j <= 9; j++) {
				if (this.aktRcdb.indices[j] > 0) {
					this.maxDBCand = j;
				}
			}
			this.aktDBIndices.clear();
			this.aktDBCandidates = Sudoku2.MAX_MASK;
			for (int j = 0; j < this.aktDBAls.length; j++) {
				this.aktDBAls[j] = -1;
			}
			final SolutionStep step = this.checkAlsDeathBlossomRecursive(1, onlyOne);
			if (onlyOne && step != null) {
				return step;
			}
		}
		return null;
	}

	/**
	 * Recursively tries all ALS for <code>candidate</code> in the cell
	 * {@link #stemCellIndex}. If <code>candidate</code> equals {@link #maxDBCand}
	 * eliminations have to be checked.
	 */
	private SolutionStep checkAlsDeathBlossomRecursive(final int cand, final boolean onlyOne) {
		if (cand > this.maxDBCand) {
			// nothing left to do
			return null;
		}
		if (this.aktRcdb.indices[cand] > 0) {
			// There are ALS to try
			for (int i = 0; i < this.aktRcdb.indices[cand]; i++) {
				final Als als = this.alses.get(this.aktRcdb.alsPerCandidate[cand][i]);
				// check for overlap
				if (!Options.getInstance().isAllowAlsOverlap() && !als.indices.andNotEquals(this.aktDBIndices)) {
					// new ALS overlaps -> we dont need to look further
					continue;
				}
				// check for common candidates
				final short tmpCandSet = this.aktDBCandidates;
				if ((tmpCandSet & als.candidates) == 0) {
					// no common candidates -> nothing to do
					continue;
				}
				// ALS is valid (overlap) and common candidates exist
				this.aktDBAls[cand] = this.aktRcdb.alsPerCandidate[cand][i];
				// get the candidates that are deleted from aktDBCandidates by als
				this.incDBCand[cand] = this.aktDBCandidates;
				this.incDBCand[cand] &= ~als.candidates;
				// now get the common candidates of the new combination
				this.aktDBCandidates &= als.candidates;
				// add the new indices
				this.aktDBIndices.or(als.indices);
				if (cand < this.maxDBCand) {
					// look further
					final SolutionStep step = this.checkAlsDeathBlossomRecursive(cand + 1, onlyOne);
					if (onlyOne && step != null) {
						return step;
					}
				} else {
					// a valid ALS combination: check for eliminations
					boolean found = false;
					final int[] cands = Sudoku2.POSSIBLE_VALUES[this.aktDBCandidates];
					for (int j = 0; j < cands.length; j++) {
						final int checkCand = cands[j];
						if (this.aktDBAls[checkCand] != -1) {
							// checkCand is used in the stemCell -> cant eliminate anything
							continue;
						}
						boolean first = true;
						for (int k = 0; k < this.aktDBAls.length; k++) {
							if (this.aktDBAls[k] == -1) {
								// no ALS for that candidate
								continue;
							}
							if (first) {
								this.dbIndicesPerCandidate.set(this.alses.get(this.aktDBAls[k]).indicesPerCandidate[checkCand]);
								first = false;
							} else {
								this.dbIndicesPerCandidate.or(this.alses.get(this.aktDBAls[k]).indicesPerCandidate[checkCand]);
							}
						}
						Sudoku2.getBuddies(this.dbIndicesPerCandidate, this.tmpSet);
						// no cannibalism
						this.tmpSet.andNot(this.aktDBIndices);
						// not in the stemCell
						this.tmpSet.remove(this.stemCellIndex);

						// possible eliminations?
						this.tmpSet.and(this.finder.getCandidates()[checkCand]);
						if (!this.tmpSet.isEmpty()) {
							// we found a Death Blossom
							// record the eliminations
							found = true;
							for (int k = 0; k < this.tmpSet.size(); k++) {
								this.globalStep.addCandidateToDelete(this.tmpSet.get(k), checkCand);
							}
						}
					}
					// if eliminations were found, record the step
					if (found) {
						this.globalStep.addIndex(this.stemCellIndex);
						// for every ALS record the RCs as fins and add the als
						for (int k = 1; k <= 9; k++) {
							if (this.aktDBAls[k] == -1) {
								continue;
							}
							final Als tmpAls = this.alses.get(this.aktDBAls[k]);
							for (int l = 0; l < tmpAls.indicesPerCandidate[k].size(); l++) {
								this.globalStep.addFin(tmpAls.indicesPerCandidate[k].get(l), k);
							}
							this.globalStep.addFin(this.stemCellIndex, k);
							this.globalStep.addAls(tmpAls.indices, tmpAls.candidates);
							this.globalStep.addRestrictedCommon(new RestrictedCommon(0, 0, k, 0, 1));
						}

						boolean writeIt = true;
						int replaceIndex = -1;
						String elim = null;
						if (Options.getInstance().isOnlyOneAlsPerStep()) {
							elim = this.globalStep.getCandidateString();
							final Integer alreadyThere = this.deletesMap.get(elim);
							if (alreadyThere != null) {
								// a step already exists!
								final SolutionStep tmp = this.steps.get(alreadyThere);
								if (tmp.getAlsesIndexCount() > this.globalStep.getAlsesIndexCount()) {
									writeIt = true;
									replaceIndex = alreadyThere;
								} else {
									writeIt = false;
								}
							}
						}
						if (writeIt) {
							if (replaceIndex != -1) {
								this.steps.remove(replaceIndex);
								this.steps.add(replaceIndex, (SolutionStep) this.globalStep.clone());
							} else {
								final SolutionStep step = (SolutionStep) this.globalStep.clone();
								if (onlyOne) {
									return step;
								}
								this.steps.add(step);
								if (elim != null) {
									this.deletesMap.put(elim, this.steps.size() - 1);
								}
							}
						}
						this.globalStep.reset();
						this.globalStep.setType(SolutionTechnique.DEATH_BLOSSOM);
					}
				}
				// and back again
				this.aktDBCandidates |= this.incDBCand[cand];
				this.aktDBIndices.andNot(als.indices);
			}
		} else {
			// nothing to do -> next candidate
			this.aktDBAls[cand] = -1;
			final SolutionStep step = this.checkAlsDeathBlossomRecursive(cand + 1, onlyOne);
			if (onlyOne && step != null) {
				return step;
			}
		}
		return null;
	}

	/**
	 * Convenience method, delegates to
	 * {@link #checkCandidatesToDelete(solver.Als, solver.Als, int, int, int, int, sudoku.model.SudokuSet)}.
	 */
	private void checkCandidatesToDelete(final Als als1, final Als als2, final int restr1) {
		this.checkCandidatesToDelete(als1, als2, restr1, -1, -1, -1, null);
	}

	/**
	 * Convenience method, delegates to
	 * {@link #checkCandidatesToDelete(solver.Als, solver.Als, int, int, int, int, sudoku.model.SudokuSet)}.
	 */
	private void checkCandidatesToDelete(final Als als1, final Als als2, final int restr1, final int restr2,
			final int restr3, final int restr4) {
		this.checkCandidatesToDelete(als1, als2, restr1, restr2, restr3, restr4, null);
	}

	/**
	 * Used for XZ, XY-Wing and Chain: Check the common candidates of als1 and
	 * als2 (minus all restrx). If candidates exist, that are outside (als1 +
	 * als2) and see all occurences of one of the common candidates (see above)
	 * they can be eliminated.<br>
	 *
	 * @param als1
	 *          The first flanking ALS
	 * @param als2
	 *          The second flanking ALS
	 * @param als3
	 *          The middle ALS in an XY-Wing, the second last ALS for an ALS
	 *          Chain; only used for correctly adding the RCs to the step
	 * @param restr1
	 *          First RC (unused if -1)
	 * @param restr2
	 *          Second RC (unused if -1)
	 * @param restr3
	 *          Third RC (unused if -1)
	 * @param restr4
	 *          Fourth RC (unused if -1)
	 * @param forChain
	 *          True if method is called for a chain: No restricted commons are
	 *          added to step
	 * @param forbiddenIndices
	 *          If not null describes the cells where no eliminations are allowed
	 *          (can be set for non cannibalistic chains)
	 */
	private void checkCandidatesToDelete(final Als als1, final Als als2, final int restr1, final int restr2,
			final int restr3, final int restr4, final SudokuSet forbiddenIndices) {
		this.possibleRestrictedCommonsSet = als1.candidates;
		this.possibleRestrictedCommonsSet &= als2.candidates;
		if (restr1 != -1 && restr1 != 0) {
			this.possibleRestrictedCommonsSet &= ~Sudoku2.MASKS[restr1];
		}
		if (restr2 != -1 && restr2 != 0) {
			this.possibleRestrictedCommonsSet &= ~Sudoku2.MASKS[restr2];
		}
		if (restr3 != -1 && restr3 != 0) {
			this.possibleRestrictedCommonsSet &= ~Sudoku2.MASKS[restr3];
		}
		if (restr4 != -1 && restr4 != 0) {
			this.possibleRestrictedCommonsSet &= ~Sudoku2.MASKS[restr4];
		}
		// possibleRestrictedCommonsSet now contains all candidates from both
		// ALS except the RCs themselves
		if (this.possibleRestrictedCommonsSet == 0) {
			// nothing to do
			return;
		}
		// check if there are any buddies
		this.tmpSet.set(als1.buddies);
		if (this.tmpSet.andEmpty(als2.buddies)) {
			// no common buddies -> no eliminations!
			return;
		}
		// get all cells from all ALS (als3 may be null!)
		if (forbiddenIndices != null) {
			this.tmpSet.set(forbiddenIndices);
		} else {
			// in an ALS-XY candidates may be eliminated from ALS c!
			this.tmpSet.set(als1.indices);
			this.tmpSet.or(als2.indices);
		}
		// check all candidates common to both ALS that are not RCs
		final int[] prcs = Sudoku2.POSSIBLE_VALUES[this.possibleRestrictedCommonsSet];
		for (int j = 0; j < prcs.length; j++) {
			final int cand = prcs[j];
			// get all cells that can see all occurrences of cand in both als
			this.restrictedCommonBuddiesSet.set(als1.buddiesPerCandidate[cand]);
			this.restrictedCommonBuddiesSet.and(als2.buddiesPerCandidate[cand]);
			// eliminate forbidden cells
			if (forbiddenIndices != null) {
				this.restrictedCommonBuddiesSet.andNot(forbiddenIndices);
			}
			if (!this.restrictedCommonBuddiesSet.isEmpty()) {
				// found one -> can be eliminated
				for (int l = 0; l < this.restrictedCommonBuddiesSet.size(); l++) {
					this.globalStep.addCandidateToDelete(this.restrictedCommonBuddiesSet.get(l), cand);
				}
				// add the common candidates themselves as fins (for display only)
				this.tmpSet1.set(als1.indicesPerCandidate[cand]);
				this.tmpSet1.or(als2.indicesPerCandidate[cand]);
				for (int l = 0; l < this.tmpSet1.size(); l++) {
					this.globalStep.addFin(this.tmpSet1.get(l), cand);
				}
			}
		}
	}

	/**
	 * Adds all cells that contain <code>cand</code> in both <code>als1</code> and
	 * <code>als2</code> as endo fins to the step (only for display). If
	 * <code>withChain</code> is set, a chain is added between the pair of
	 * candidates in both ALS that have the smallest distance.
	 */
	private void addRestrictedCommonToStep(final Als als1, final Als als2, final int cand, final boolean withChain) {
		// get all cells in both als that contain cand
		this.tmpSet.set(als1.indicesPerCandidate[cand]);
		this.tmpSet.or(als2.indicesPerCandidate[cand]);
		for (int i = 0; i < this.tmpSet.size(); i++) {
			// add them as endo fins
			this.globalStep.addEndoFin(this.tmpSet.get(i), cand);
		}
		if (withChain) {
			// create a chain for the smallest distance
			int minDist = Integer.MAX_VALUE;
			int minIndex1 = -1;
			int minIndex2 = -1;
			for (int i1 = 0; i1 < als1.indicesPerCandidate[cand].size(); i1++) {
				for (int i2 = 0; i2 < als2.indicesPerCandidate[cand].size(); i2++) {
					final int index1 = als1.indicesPerCandidate[cand].get(i1);
					final int index2 = als2.indicesPerCandidate[cand].get(i2);
					final int dx = Sudoku2.getLine(index1) - Sudoku2.getLine(index2);
					final int dy = Sudoku2.getCol(index1) - Sudoku2.getCol(index2);
					final int dist = dx * dx + dy * dy;
					if (dist < minDist) {
						minDist = dist;
						minIndex1 = index1;
						minIndex2 = index2;
					}
				}
			}
			final int[] tmpChain = new int[2];
			tmpChain[0] = Chain.makeSEntry(minIndex1, cand, false);
			tmpChain[1] = Chain.makeSEntry(minIndex2, cand, false);
			this.globalStep.addChain(0, 1, tmpChain);
		}
	}

	/**
	 * als1 and als2 are doubly linked by RCs rc1 and rc2; check whether the
	 * locked set {als1 - rc1 - rc2 } can eliminate candidates that are not in
	 * als2.<br>
	 * <br>
	 *
	 * The method has to be called twice with als1 and als2 swapped.<br>
	 *
	 * @param als1
	 *          The als that becomes a locked set
	 * @param als2
	 *          The doubly linked second als, no candidates can be eliminated from
	 *          it
	 * @param rc1
	 *          The first Restricted Common
	 * @param rc2
	 *          The second Restricted Common
	 */
	private boolean checkDoublyLinkedAls(final Als als1, final Als als2, final int rc1, final int rc2) {
		boolean isDoubly = false;
		// collect the remaining candidates
		this.possibleRestrictedCommonsSet = als1.candidates;
		this.possibleRestrictedCommonsSet &= ~Sudoku2.MASKS[rc1];
		this.possibleRestrictedCommonsSet &= ~Sudoku2.MASKS[rc2];
		if (this.possibleRestrictedCommonsSet == 0) {
			// nothing can be eliminated
			return false;
		}
		// for any candidate left get all buddies, subtract als1 and als2 and check
		// for eliminations
		final int[] prcs = Sudoku2.POSSIBLE_VALUES[this.possibleRestrictedCommonsSet];
		for (int i = 0; i < prcs.length; i++) {
			final int cand = prcs[i];
			this.restrictedCommonIndexSet.set(als1.buddiesPerCandidate[cand]);
			this.restrictedCommonIndexSet.andNot(als2.indices);
			if (!this.restrictedCommonIndexSet.isEmpty()) {
				for (int j = 0; j < this.restrictedCommonIndexSet.size(); j++) {
					this.globalStep.addCandidateToDelete(this.restrictedCommonIndexSet.get(j), cand);
					isDoubly = true;
				}
			}
		}
		return isDoubly;
	}

	/**
	 * For all combinations of two ALS check whether they have one or two RC(s).
	 * An RC is a candidate that is common to both ALS and where all instances of
	 * that candidate in both ALS see each other.<br>
	 * ALS with RC(s) may overlap as long as the overlapping area doesnt contain
	 * an RC.<br>
	 * Two ALS can have a maximum of two RCs.<br>
	 * The index of the first RC for {@link #alses}[i] is written to
	 * {@link #startIndices}[i], the index of the last RC is written to
	 * {@link #endIndices}[i] (needed for chain search).
	 *
	 * @param withOverlap
	 *          If <code>false</code> overlapping ALS are not allowed
	 */
	private void collectAllRestrictedCommons(final boolean withOverlap) {
		this.restrictedCommons = this.finder.getRestrictedCommons(this.alses, withOverlap);
		this.startIndices = this.finder.getStartIndices();
		this.endIndices = this.finder.getEndIndices();
	}

	/**
	 * Collects all available ALS in the current grid by simply referring to
	 * {@link Als#getAlses(sudoku.model.Sudoku2) }. The only purpose of this method is
	 * to provide timing and statistics data.
	 */
	private void collectAllAlses() {
		this.alses = this.finder.getAlses();
	}

	/**
	 * Collect all cells, that can see all instances of a candidate within an ALS.
	 * For every cell that is not yet set an instance of {@link RCForDeathBlossom}
	 * is created and stored in {@link #rcdb}. In another method
	 * <code>rcdb[i].candMask</code> is checked against the real candidate mask of
	 * the cell: if they are equal, a possible Death Blossom exists.<br>
	 * <br>
	 *
	 * Calculate all buddies for all candidates in all ALSs -> they are all
	 * possible stem cells.
	 */
	private void collectAllRCsForDeathBlossom() {
		for (int i = 0; i < this.rcdb.length; i++) {
			Arrays.fill(this.rcdb, null);
		}
		for (int i = 0; i < this.alses.size(); i++) {
			final Als act = this.alses.get(i);
			// check all candidate in the current ALS
			for (int j = 1; j <= 9; j++) {
				if ((act.candidates & Sudoku2.MASKS[j]) == 0) {
					// candidate not in als -> nothing to do
					continue;
				}
				for (int k = 0; k < act.buddiesPerCandidate[j].size(); k++) {
					final int index = act.buddiesPerCandidate[j].get(k);
					if (this.rcdb[index] == null) {
						this.rcdb[index] = new RCForDeathBlossom();
					}
					this.rcdb[index].addAlsForCandidate(i, j);
				}
			}
		}
	}

	/**
	 * Restricted Common for Death Blossoms<br>
	 * <br>
	 *
	 * One instance belongs to one sudoku cell. It holds the indices of all ALS
	 * from {@link #alses} that can see that cell. The list is maintained for all
	 * candidates (if two candidates from one ALS can see the same cell, the ALS
	 * is recorded twice). A mask containes all candidates for which ALS have been
	 * added. If that mask equals the candidate mask of the cell, the cell is a
	 * possible stem cell for a Death Blossom.
	 */
	class RCForDeathBlossom {

		/** A mask with every candidate set that has at least one ALS. */
		short candMask;
		/** All ALSs for every candidate. */
		int[][] alsPerCandidate = new int[10][100];
		/** Number of ALS {@link #alsPerCandidate} for every candidate. */
		int[] indices = new int[10];

		/**
		 * creates a new instance.
		 */
		RCForDeathBlossom() {
		}

		/**
		 * Adds an ALS for candidate <code>candidate</code>. {@link #candMask} is
		 * updated accordingly.
		 *
		 * @param als
		 * @param candidate
		 */
		public void addAlsForCandidate(final int als, final int candidate) {
			if (this.indices[candidate] < this.alsPerCandidate[candidate].length) {
				this.alsPerCandidate[candidate][this.indices[candidate]++] = als;
				this.candMask |= Sudoku2.MASKS[candidate];
			}
		}
	}

}

/**
 * Compares two ALS solution steps with each other (different from standard
 * compare). Sort order:<br>
 * <ul>
 * <li>number of eliminations</li>
 * <li>equivalency: same candidates to be deleted</li>
 * <li>sum of indices in the step</li>
 * <li>number of ALS (XY lt XY-Wing)</li>
 * <li>number of indices in all ALS</li>
 * </ul>
 *
 */
class AlsComparator implements Comparator<SolutionStep> {

	/**
	 * Sort order:<br>
	 * <ul>
	 * <li>number of eliminations</li>
	 * <li>equivalency: same candidates to be deleted</li>
	 * <li>sum of indices in the step</li>
	 * <li>number of ALS (XY lt XY-Wing)</li>
	 * <li>number of indices in all ALS</li>
	 * </ul>
	 */
	@Override
	public int compare(final SolutionStep o1, final SolutionStep o2) {
		int sum1 = 0;
		int sum2 = 0;

		int result = o2.getCandidatesToDelete().size() - o1.getCandidatesToDelete().size();
		if (result != 0) {
			return result;
		}
		if (!o1.isEquivalent(o2)) {
			sum1 = o1.getIndexSumme(o1.getCandidatesToDelete());
			sum2 = o2.getIndexSumme(o2.getCandidatesToDelete());
			return (sum1 - sum2);
		}

		result = o1.getAlses().size() - o2.getAlses().size();
		if (result != 0) {
			return result;
		}
		result = o1.getAlsesIndexCount() - o2.getAlsesIndexCount();
		if (result != 0) {
			return result; // zuletzt nach Typ
		}
		return o1.getType().compare(o2.getType());
	}
}
