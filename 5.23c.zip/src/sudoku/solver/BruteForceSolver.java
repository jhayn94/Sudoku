/*
 * Copyright (C) 2008-12  Bernhard Hobiger
 *
 * This file is part of HoDoKu.
 *
 * HoDoKu is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * HoDoKu is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with HoDoKu. If not, see <http://www.gnu.org/licenses/>.
 */

package sudoku.solver;

import sudoku.factories.SudokuFactory;
import sudoku.model.SolutionStep;
import sudoku.model.Sudoku2;
import sudoku.model.SudokuSet;
import sudoku.model.util.SolutionTechnique;

public class BruteForceSolver extends AbstractSolver {

	public BruteForceSolver(final SudokuStepFinder finder) {
		super(finder);
	}

	@Override
	protected SolutionStep getStep(final SolutionTechnique type) {
		SolutionStep result = null;
		this.sudoku = this.finder.getSudoku();
		if (SolutionTechnique.BRUTE_FORCE == type) {
			result = this.getBruteForce();
		}
		return result;
	}

	@Override
	protected boolean doStep(final SolutionStep step) {
		boolean handled = true;
		this.sudoku = this.finder.getSudoku();
		if (SolutionTechnique.BRUTE_FORCE == step.getType()) {
			final int value = step.getValues().get(0);
			for (final int index : step.getIndices()) {
				this.sudoku.setCell(index, value);
			}
		} else {
			handled = false;
		}
		return handled;
	}

	private SolutionStep getBruteForce() {
		if (!this.sudoku.isSolutionSet()) {
			// can happen, when command line mode is used (no brute force solving is
			// done)
			// sets the solution in the sudoku
			final boolean isValid = SudokuFactory.getInstance().validSolution(this.sudoku);
			if (!isValid) {
				return null;
			}
		}

		final SudokuSet unsolved = new SudokuSet();
		for (int i = 0; i < Sudoku2.LENGTH; i++) {
			if (this.sudoku.getValue(i) == 0) {
				unsolved.add(i);
			}
		}

		int index = unsolved.size() / 2;
		index = unsolved.get(index);

		final SolutionStep step = new SolutionStep(SolutionTechnique.BRUTE_FORCE);
		step.addIndex(index);
		step.addValue(this.sudoku.getSolution(index));
		return step;
	}
}
