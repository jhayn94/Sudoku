/*
 * Copyright (C) 2008-12  Bernhard Hobiger
 *
 * This file is part of HoDoKu.
 *
 * HoDoKu is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * HoDoKu is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with HoDoKu. If not, see <http://www.gnu.org/licenses/>.
 */

package sudoku.solver;

import java.util.ArrayList;
import java.util.List;

import sudoku.model.SolutionStep;
import sudoku.model.Sudoku2;
import sudoku.model.SudokuSet;

public class GroupNode {
	private final SudokuSet indices = new SudokuSet(); // indices as bit mask
	private final SudokuSet buddies = new SudokuSet(); // all buddies that can see
																											// all
	// cells in the group node
	private final int cand; // candidate for grouped link
	private int line = -1; // row (index in Sudoku2.ROWS), -1 if not applicable
	private int col = -1; // col (index in Sudoku2.COLS), -1 if not applicable
	private final int block; // block (index in Sudoku2.BLOCKS)
	private final int index1; // index of first cell
	private final int index2; // index of second cell
	private int index3; // index of third cell or -1, if grouped node consists
											// only
											// of two cells

	private static SudokuSet candInHouse = new SudokuSet(); // all positions for a
																													// given candidate in
																													// a given house
	private static SudokuSet tmpSet = new SudokuSet(); // for check with blocks

	public GroupNode(final int cand, final SudokuSet indices) {
		this.cand = cand;
		this.indices.set(indices);
		this.index1 = indices.get(0);
		this.index2 = indices.get(1);
		this.index3 = -1;
		if (indices.size() > 2) {
			this.index3 = indices.get(2);
		}
		this.block = Sudoku2.getBlock(this.index1);
		if (Sudoku2.getLine(this.index1) == Sudoku2.getLine(this.index2)) {
			this.line = Sudoku2.getLine(this.index1);
		}
		if (Sudoku2.getCol(this.index1) == Sudoku2.getCol(this.index2)) {
			this.col = Sudoku2.getCol(this.index1);
		}
		// calculate the buddies
		this.buddies.set(Sudoku2.buddies[this.index1]);
		this.buddies.and(Sudoku2.buddies[this.index2]);
		if (this.index3 >= 0) {
			this.buddies.and(Sudoku2.buddies[this.index3]);
		}
	}

	@Override
	public String toString() {
		return "GroupNode: " + this.cand + " - " + SolutionStep.getCompactCellPrint(this.index1, this.index2, this.index3)
				+ "  - " + this.index1 + "/" + this.index2 + "/" + this.index3 + " (" + this.line + "/" + this.col + "/"
				+ this.block + ")";
	}

	/**
	 * Gets all group nodes from the given sudoku and puts them in an ArrayList.
	 *
	 * For all candidates in all lines and all cols do: - check if they have a
	 * candidate left - if so, check if an intersection of line/col and a block
	 * contains more than one candidate; if yes -> group node found
	 *
	 * @param finder
	 * @return
	 */
	public static List<GroupNode> getGroupNodes(final SudokuStepFinder finder) {
		final List<GroupNode> groupNodes = new ArrayList<>();

		getGroupNodesForHouseType(groupNodes, finder, Sudoku2.LINE_TEMPLATES);
		getGroupNodesForHouseType(groupNodes, finder, Sudoku2.COL_TEMPLATES);

		return groupNodes;
	}

	private static void getGroupNodesForHouseType(final List<GroupNode> groupNodes, final SudokuStepFinder finder,
			final SudokuSet[] houses) {
		for (int i = 0; i < houses.length; i++) {
			for (int cand = 1; cand <= 9; cand++) {
				candInHouse.set(houses[i]);
				candInHouse.and(finder.getCandidates()[cand]);
				if (candInHouse.isEmpty()) {
					// no candidates left in this house -> proceed
					continue;
				}

				// candidates left in house -> check blocks
				for (int j = 0; j < Sudoku2.BLOCK_TEMPLATES.length; j++) {
					tmpSet.set(candInHouse);
					tmpSet.and(Sudoku2.BLOCK_TEMPLATES[j]);
					if (!tmpSet.isEmpty() && tmpSet.size() >= 2) {
						groupNodes.add(new GroupNode(cand, tmpSet));
					}
				}
			}
		}
	}

	public SudokuSet getIndices() {
		return this.indices;
	}

	public SudokuSet getBuddies() {
		return this.buddies;
	}

	public int getCand() {
		return this.cand;
	}

	public int getLine() {
		return this.line;
	}

	public int getCol() {
		return this.col;
	}

	public int getBlock() {
		return this.block;
	}

	public int getIndex1() {
		return this.index1;
	}

	public int getIndex2() {
		return this.index2;
	}

	public int getIndex3() {
		return this.index3;
	}

	public static SudokuSet getCandInHouse() {
		return candInHouse;
	}

	public static SudokuSet getTmpSet() {
		return tmpSet;
	}

}
