/*
 * Copyright (C) 2008-12  Bernhard Hobiger
 *
 * This file is part of HoDoKu.
 *
 * HoDoKu is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * HoDoKu is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with HoDoKu. If not, see <http://www.gnu.org/licenses/>.
 */
package sudoku.solver;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.SortedMap;
import java.util.TreeMap;

import sudoku.model.Candidate;
import sudoku.model.Chain;
import sudoku.model.Options;
import sudoku.model.SolutionStep;
import sudoku.model.Sudoku2;
import sudoku.model.SudokuSet;
import sudoku.model.SudokuSetBase;
import sudoku.model.util.SolutionTechnique;

/**
 *
 * Kraken Fish:
 *
 * In a finned fish either there is a fish or one of the fins is true. This
 * gives the easiest way to find a Kraken Fish (Type 1):
 *
 * - If a candidate that would be eliminated by the unfinned fish can be linked
 * to all fins (fin set -> candidate not set) than that candidate can be
 * eliminated - In a Type 1 KF the eliminated candidate is the same candidate as
 * the fish candidate
 *
 * The other way is a bit more complicated: In an unfinned fish in every cover
 * set exactly one of the base candidates has to be true. In a finned fish
 * either this is true or one of the fins is true. That leads to the second type
 * of Kraken Fish (Type 2):
 *
 * - If chains can be found that link all base candidates of one cover set to a
 * specific candidate (CEC) (base candidate set -> CEC candidate not set) than
 * that candidate can be eliminated. - If the fish has fins, additional chains
 * have to be found for every fin - In a Type 2 KF the deleted candidate can be
 * an arbitrary candidate
 *
 * Endo fins: Have to be treated like normal fins. In Type 2 KF nothing is
 * changed Cannibalism: In Type 1 KF they count as normal possible elimination.
 * In Type 2 KF no chain from the cannibalistic candidate to the CEC has to be
 * found.
 *
 * Implementation: - Type 1: For every possible elimination look after a chain
 * to all the fins - Type 2: For every intersection of a cover set with all base
 * candidates look for possible eliminations; if they exist, try to link them to
 * the fins
 *
 * Caution: Since the Template optimization cannot be applied, KF search can be
 * very slow!
 */
public class FishSolver extends AbstractSolver {

	/** All unfinned basic {@link SolutionTechnique SolutionTypes} */
	private static final SolutionTechnique[] BASIC_TYPES = { SolutionTechnique.X_WING, SolutionTechnique.SWORDFISH,
			SolutionTechnique.JELLYFISH, SolutionTechnique.SQUIRMBAG, SolutionTechnique.WHALE, SolutionTechnique.LEVIATHAN };
	/** All finned basic {@link SolutionTechnique SolutionTypes} */
	private static final SolutionTechnique[] FINNED_BASIC_TYPES = { SolutionTechnique.FINNED_X_WING, SolutionTechnique.FINNED_SWORDFISH,
			SolutionTechnique.FINNED_JELLYFISH, SolutionTechnique.FINNED_SQUIRMBAG, SolutionTechnique.FINNED_WHALE,
			SolutionTechnique.FINNED_LEVIATHAN };
	/** All finned sashimi basic {@link SolutionTechnique SolutionTypes} */
	private static final SolutionTechnique[] SASHIMI_BASIC_TYPES = { SolutionTechnique.SASHIMI_X_WING,
			SolutionTechnique.SASHIMI_SWORDFISH, SolutionTechnique.SASHIMI_JELLYFISH, SolutionTechnique.SASHIMI_SQUIRMBAG,
			SolutionTechnique.SASHIMI_WHALE, SolutionTechnique.SASHIMI_LEVIATHAN };
	/** All unfinned franken {@link SolutionTechnique SolutionTypes} */
	private static final SolutionTechnique[] FRANKEN_TYPES = { SolutionTechnique.FRANKEN_X_WING, SolutionTechnique.FRANKEN_SWORDFISH,
			SolutionTechnique.FRANKEN_JELLYFISH, SolutionTechnique.FRANKEN_SQUIRMBAG, SolutionTechnique.FRANKEN_WHALE,
			SolutionTechnique.FRANKEN_LEVIATHAN };
	/** All finned franken {@link SolutionTechnique SolutionTypes} */
	private static final SolutionTechnique[] FINNED_FRANKEN_TYPES = { SolutionTechnique.FINNED_FRANKEN_X_WING,
			SolutionTechnique.FINNED_FRANKEN_SWORDFISH, SolutionTechnique.FINNED_FRANKEN_JELLYFISH,
			SolutionTechnique.FINNED_FRANKEN_SQUIRMBAG, SolutionTechnique.FINNED_FRANKEN_WHALE, SolutionTechnique.FINNED_FRANKEN_LEVIATHAN };
	/** All unfinned mutant {@link SolutionTechnique SolutionTypes} */
	private static final SolutionTechnique[] MUTANT_TYPES = { SolutionTechnique.MUTANT_X_WING, SolutionTechnique.MUTANT_SWORDFISH,
			SolutionTechnique.MUTANT_JELLYFISH, SolutionTechnique.MUTANT_SQUIRMBAG, SolutionTechnique.MUTANT_WHALE,
			SolutionTechnique.MUTANT_LEVIATHAN };
	/** All finned mutant {@link SolutionTechnique SolutionTypes} */
	private static final SolutionTechnique[] FINNED_MUTANT_TYPES = { SolutionTechnique.FINNED_MUTANT_X_WING,
			SolutionTechnique.FINNED_MUTANT_SWORDFISH, SolutionTechnique.FINNED_MUTANT_JELLYFISH, SolutionTechnique.FINNED_MUTANT_SQUIRMBAG,
			SolutionTechnique.FINNED_MUTANT_WHALE, SolutionTechnique.FINNED_MUTANT_LEVIATHAN };
	/** Set if search is for kraken fish */
	private static final int UNDEFINED = -1;
	/** Search for basic fish */
	private static final int BASIC = 0;
	/** Search for franken fish */
	private static final int FRANKEN = 1;
	/** Search for mutant fish */
	private static final int MUTANT = 2;
	/** Mask for determining the fish shape */
	private static final int LINE_MASK = 0x1;
	/** Mask for determining the fish shape */
	private static final int COL_MASK = 0x2;
	/** Mask for determining the fish shape */
	private static final int BLOCK_MASK = 0x4;
	/** Array with constraint type masks for speedup. */
	private static final int[] MASKS = { BLOCK_MASK, LINE_MASK, COL_MASK };

	/** One entry in the recursion stack for the base unit search */
	private class BaseStackEntry {

		/** The index of the base unit that is currently tried */
		int aktIndex = 0;
		/** The number of the unit that was set previously */
		int lastUnit = 0;
		/**
		 * All cells that are in at least one base set and hold the fish candidate
		 * (low order DWORD)
		 */
		long candidatesM1 = 0;
		/**
		 * All cells that are in at least one base set and hold the fish candidate
		 * (high order DWORD)
		 */
		long candidatesM2 = 0;
		/**
		 * All cells that are in more than one base set and have to be treated as
		 * fins (low order DWORD).
		 */
		long endoFinsM1 = 0;
		/**
		 * All cells that are in more than one base set and have to be treated as
		 * fins (high order DWORD).
		 */
		long endoFinsM2 = 0;
	}

	/** One entry in the recursion stack for the cover unit search */
	private class CoverStackEntry {

		/** The index of the base unit that is currently tried */
		int aktIndex = 0;
		/** The number of the unit that was set previously */
		int lastUnit = 0;
		/**
		 * All cells that are in at least one cover set and hold the fish candidate
		 * (low order DWORD)
		 */
		long candidatesM1 = 0;
		/**
		 * All cells that are in at least one cover set and hold the fish candidate
		 * (high order DWORD)
		 */
		long candidatesM2 = 0;
		/**
		 * All cells that are in more than one cover set and have to be treated as
		 * potential eliminations (low order DWORD).
		 */
		long cannibalisticM1 = 0;
		/**
		 * All cells that are in more than one cover set and have to be treated as
		 * potential eliminations (high order DWORD).
		 */
		long cannibalisticM2 = 0;
	}

	/** The fish candidate */
	private int candidate;
	/**
	 * A set with all positions where the fish candidate is still possible (low
	 * order DWORD)
	 */
	private long candidatesM1;
	/**
	 * A set with all positions where the fish candidate is still possible (high
	 * order DWORD)
	 */
	private long candidatesM2;
	/** A set for template checks (low order DWORD) */
	private long delCandTemplatesM1;
	/** A set for template checks (high order DWORD) */
	private long delCandTemplatesM2;
	/** A set for creating fish steps */
	private final SudokuSet createFishSet = new SudokuSet();
	/** <code>true</code> if only finless fishes should be found */
	private boolean withoutFins;
	/** <code>true</code> if only finned or sashimi fishes should be found */
	private boolean withFins;
	/** <code>true</code> if finned fish can contain endo fins */
	private boolean withEndoFins;
	/**
	 * <code>true</code> if only sashimi fishes should be found ({@link #withFins}
	 * has to be <code>true</code> as well)
	 */
	private boolean sashimi;
	/** <code>true</code> if the search is for kraken fish only */
	private boolean kraken;
	/**
	 * The fish type: {@link #BASIC}, {@link #FRANKEN}, {@link #MUTANT} or
	 * {@link #UNDEFINED} for kraken search.
	 */
	private int fishType = UNDEFINED;
	/** Minimum size of the fish */
	private int minSize;
	/** Maximum size of the fish */
	private int maxSize;
	/**
	 * An array with all possible base units (indices in
	 * {@link Sudoku2#CONSTRAINTS}).
	 */
	private final int[] baseUnits = new int[Sudoku2.UNITS * 3];
	/**
	 * For every base unit all cells where the candidate is set (low order DWORD).
	 */
	private final long[] baseCandidatesM1 = new long[Sudoku2.UNITS * 3];
	/**
	 * For every base unit all cells where the candidate is set (high order
	 * DWORD).
	 */
	private final long[] baseCandidatesM2 = new long[Sudoku2.UNITS * 3];
	/** The number of base units in this search */
	private int numberOfBaseUnits = 0;
	/**
	 * An array with all possible cover units (indices in
	 * {@link Sudoku2#CONSTRAINTS}).
	 */
	private final int[] allCoverUnits = new int[Sudoku2.UNITS * 3];
	/**
	 * For every cover unit all cells where the candidate is set (low order
	 * DWORD).
	 */
	private final long[] allCoverCandidatesM1 = new long[Sudoku2.UNITS * 3];
	/**
	 * For every cover unit all cells where the candidate is set (high order
	 * DWORD).
	 */
	private final long[] allCoverCandidatesM2 = new long[Sudoku2.UNITS * 3];
	/** The number of possible cover units */
	private int numberOfAllCoverUnits = 0;
	/**
	 * An array with all possible cover units for one cover unit search (indices
	 * in {@link Sudoku2#CONSTRAINTS}).
	 */
	private final int[] coverUnits = new int[Sudoku2.UNITS * 3];
	/**
	 * For every entry in {@link #coverUnits} all cells where the candidate is set
	 * (low order DWORD).
	 */
	private final long[] coverCandidatesM1 = new long[Sudoku2.UNITS * 3];
	/**
	 * For every entry in {@link #coverUnits} all cells where the candiate is set
	 * (high order DWORD).
	 */
	private final long[] coverCandidatesM2 = new long[Sudoku2.UNITS * 3];
	/** The number of cover units in this cover search */
	private int numberOfCoverUnits = 0;
	/** True for all base units that are currently used */
	private final boolean[] baseUnitsUsed = new boolean[this.baseUnits.length];
	/** The recursion stack for the base unit search */
	private final BaseStackEntry[] baseStack = new BaseStackEntry[9];
	/** The index of the current level in the {@link #baseStack}. */
	private int baseLevel = 0;
	/** True for all cover units that are currently used */
	private final boolean[] coverUnitsUsed = new boolean[this.allCoverUnits.length];
	/** The recursion stack for the cover unit search */
	private final CoverStackEntry[] coverStack = new CoverStackEntry[9];
	/** The index of the current level in the {@link #coverStack}. */
	private int coverLevel = 0;
	/** Contains one entry for every step (number and indices of eliminations) */
	private final SortedMap<String, Integer> deletesMap = new TreeMap<>();
	/** A set to incrementally check for endo fins (low order DWORD) */
	private long aktEndoFinSetM1;
	/** A set to incrementally check for endo fins (high order DWORD) */
	private long aktEndoFinSetM2;
	/** A set to incrementally check for cannibalism (low order DWORD) */
	private long aktCannibalismSetM1;
	/** A set to incrementally check for cannibalism (high order DWORD) */
	private long aktCannibalismSetM2;
	/** A set for template checks */
	private final SudokuSet templateSet = new SudokuSet();
	/** A set that holds potential eliminations for Kraken Fish */
	private final SudokuSet krakenDeleteCandSet = new SudokuSet();
	/** A set that holds all fins for Kraken Fish search */
	private final SudokuSet krakenFinSet = new SudokuSet();
	/** A set for cannibalistic eliminations in Kraken Fish */
	private final SudokuSet krakenCannibalisticSet = new SudokuSet();

	/** A global {@link SolutionStep}, speeds up search */
	private final SolutionStep globalStep = new SolutionStep(SolutionTechnique.HIDDEN_SINGLE);
	/** A {@link TablingSolver} for Kraken Fish search */
	private TablingSolver tablingSolver = null;
	/** for various checks (low order DWORD) */
	private long tmpSetM1;
	/** for various checks (high order DWORD) */
	private long tmpSetM2;
	/** for various checks (low order DWORD) */
	private long tmpSet1M1;
	/** for various checks (high order DWORD) */
	private long tmpSet1M2;
	/** for various checks (low order DWORD) */
	private long tmpSet2M1;
	/** for various checks (high order DWORD) */
	private long tmpSet2M2;
	/** A set for getting all possible buddies */
	private final SudokuSet getBuddiesSet = new SudokuSet();
	/** For Sashimi check (low order DWORD) */
	private long checkSashimiSetM1;
	/** For Sashimi check (high order DWORD) */
	private long checkSashimiSetM2;
	/** All cells that can be seen by all fins (low order DWORD) */
	private long finBuddiesM1;
	/** All cells that can be seen by all fins (high order DWORD) */
	private long finBuddiesM2;
	/** All fins for a given fish (including endo fins) (low order DWORD) */
	private long finsM1;
	/** All fins for a given fish (including endo fins) (high order DWORD) */
	private long finsM2;
	/**
	 * true, if all fishes should be found (searches for inverse in Kraken Fish)
	 */
	private boolean searchAll;
	/** <code>true</code> if Siamese Fish should be found */
	private boolean siamese;
	/** Check for templates */
	private boolean doTemplates;
	/** All steps found by the last search */
	private List<SolutionStep> steps = new ArrayList<>();
	/**
	 * A cache for steps that were found but cannot be used just now (Finned <->
	 * Sashimi)
	 */
	private final List<SolutionStep> cachedSteps = new ArrayList<>();
	/** the {@link SudokuStepFinder#stepNumber} of the last executed step. */
	private int lastStepNumber = 0;
	/** number of tries for finned fish per number of fins */
	private final int[] anzFins = { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
			0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };

	/**
	 * Creates a new instance of FishSolver
	 */
	protected FishSolver(final SudokuStepFinder finder) {
		super(finder);
		for (int i = 0; i < this.baseStack.length; i++) {
			this.baseStack[i] = new BaseStackEntry();
		}
		for (int i = 0; i < this.coverStack.length; i++) {
			this.coverStack[i] = new CoverStackEntry();
		}
	}

	@Override
	protected SolutionStep getStep(final SolutionTechnique type) {
		SolutionStep result = null;
		this.sudoku = this.finder.getSudoku();
		int size = 2;
		switch (type) {
		case LEVIATHAN:
		case WHALE:
		case SQUIRMBAG:
		case JELLYFISH:
		case SWORDFISH:
			size++;
		case X_WING:
			this.searchAll = false;
			result = this.getAnyFish(size, true, false, false, false, BASIC);
			break;
		case FINNED_LEVIATHAN:
		case FINNED_WHALE:
		case FINNED_SQUIRMBAG:
		case FINNED_JELLYFISH:
		case FINNED_SWORDFISH:
			size++;
		case FINNED_X_WING:
			this.searchAll = false;
			result = this.getAnyFish(size, false, true, false, false, BASIC);
			break;
		case SASHIMI_LEVIATHAN:
		case SASHIMI_WHALE:
		case SASHIMI_SQUIRMBAG:
		case SASHIMI_JELLYFISH:
		case SASHIMI_SWORDFISH:
			size++;
		case SASHIMI_X_WING:
			this.searchAll = false;
			result = this.getAnyFish(size, false, true, true, false, BASIC);
			break;
		case FRANKEN_LEVIATHAN:
		case FRANKEN_WHALE:
		case FRANKEN_SQUIRMBAG:
		case FRANKEN_JELLYFISH:
		case FRANKEN_SWORDFISH:
			size++;
		case FRANKEN_X_WING:
			this.searchAll = false;
			result = this.getAnyFish(size, true, false, false, true, FRANKEN);
			break;
		case FINNED_FRANKEN_LEVIATHAN:
		case FINNED_FRANKEN_WHALE:
		case FINNED_FRANKEN_SQUIRMBAG:
		case FINNED_FRANKEN_JELLYFISH:
		case FINNED_FRANKEN_SWORDFISH:
			size++;
		case FINNED_FRANKEN_X_WING:
			this.searchAll = false;
			result = this.getAnyFish(size, false, true, false, true, FRANKEN);
			break;
		case MUTANT_LEVIATHAN:
		case MUTANT_WHALE:
		case MUTANT_SQUIRMBAG:
		case MUTANT_JELLYFISH:
		case MUTANT_SWORDFISH:
			size++;
		case MUTANT_X_WING:
			this.searchAll = false;
			result = this.getAnyFish(size, true, false, false, true, MUTANT);
			break;
		case FINNED_MUTANT_LEVIATHAN:
		case FINNED_MUTANT_WHALE:
		case FINNED_MUTANT_SQUIRMBAG:
		case FINNED_MUTANT_JELLYFISH:
		case FINNED_MUTANT_SWORDFISH:
			size++;
		case FINNED_MUTANT_X_WING:
			this.searchAll = false;
			result = this.getAnyFish(size, false, true, false, true, MUTANT);
			break;
		case KRAKEN_FISH:
		case KRAKEN_FISH_TYPE_1:
		case KRAKEN_FISH_TYPE_2:
			this.searchAll = false;
			result = this.getKrakenFish();
			break;
		default: // Nothing to do.
		}
		return result;
	}

	@Override
	protected boolean doStep(final SolutionStep step) {
		boolean handled = true;

		this.sudoku = this.finder.getSudoku();
		switch (step.getType()) {
		case X_WING:
		case SWORDFISH:
		case JELLYFISH:
		case SQUIRMBAG:
		case WHALE:
		case LEVIATHAN:
		case FINNED_X_WING:
		case FINNED_SWORDFISH:
		case FINNED_JELLYFISH:
		case FINNED_SQUIRMBAG:
		case FINNED_WHALE:
		case FINNED_LEVIATHAN:
		case SASHIMI_X_WING:
		case SASHIMI_SWORDFISH:
		case SASHIMI_JELLYFISH:
		case SASHIMI_SQUIRMBAG:
		case SASHIMI_WHALE:
		case SASHIMI_LEVIATHAN:
		case FRANKEN_X_WING:
		case FRANKEN_SWORDFISH:
		case FRANKEN_JELLYFISH:
		case FRANKEN_SQUIRMBAG:
		case FRANKEN_WHALE:
		case FRANKEN_LEVIATHAN:
		case FINNED_FRANKEN_X_WING:
		case FINNED_FRANKEN_SWORDFISH:
		case FINNED_FRANKEN_JELLYFISH:
		case FINNED_FRANKEN_SQUIRMBAG:
		case FINNED_FRANKEN_WHALE:
		case FINNED_FRANKEN_LEVIATHAN:
		case MUTANT_X_WING:
		case MUTANT_SWORDFISH:
		case MUTANT_JELLYFISH:
		case MUTANT_SQUIRMBAG:
		case MUTANT_WHALE:
		case MUTANT_LEVIATHAN:
		case FINNED_MUTANT_X_WING:
		case FINNED_MUTANT_SWORDFISH:
		case FINNED_MUTANT_JELLYFISH:
		case FINNED_MUTANT_SQUIRMBAG:
		case FINNED_MUTANT_WHALE:
		case FINNED_MUTANT_LEVIATHAN:
		case KRAKEN_FISH:
		case KRAKEN_FISH_TYPE_1:
		case KRAKEN_FISH_TYPE_2:
			for (final Candidate cand : step.getCandidatesToDelete()) {
				this.sudoku.delCandidate(cand.getIndex(), cand.getValue());
			}
			break;
		default:
			handled = false;
		}
		return handled;
	}

	/**
	 * Get all fishes, display a progress dialog (optional). The search can be
	 * restricted to a certain size, to a candidate and to certain types of fish.
	 *
	 * @param minSize
	 *          Minimum fish size for search
	 * @param maxSize
	 *          Maximum fish size for search
	 * @param maxFins
	 *          Maximum number of fins allowed (speeds up search)
	 * @param maxEndoFins
	 *          Maximum number of endo fins allowed (greatly speeds up search)
	 * @param dlg
	 *          A progress dialog or <code>null</code>
	 * @param forCandidate
	 *          -1 means "search for all candidates", all other values restrict
	 *          the search to those values
	 * @param type
	 *          {@link #BASIC}, {@link #FRANKEN} or {@link #MUTANT}: The maximum
	 *          type for the search
	 */
	protected List<SolutionStep> getAllFishes(final int minSize, final int maxSize, final int maxFins,
			final int maxEndoFins, final int forCandidate, final int type) {
		this.sudoku = this.finder.getSudoku();
		final int oldMaxFins = Options.getInstance().getMaxFins();
		final int oldEndoFins = Options.getInstance().getMaxEndoFins();
		Options.getInstance().setMaxFins(maxFins);
		Options.getInstance().setMaxEndoFins(maxEndoFins);
		final List<SolutionStep> oldSteps = this.steps;
		this.steps = new ArrayList<>();
		this.kraken = false;
		this.searchAll = true;
		this.fishType = UNDEFINED;
		for (int i = 1; i <= 9; i++) {
			if (forCandidate != -1 && forCandidate != i) {
				// not now
				continue;
			}
			this.getFishes(i, minSize, maxSize, true, true, false, true, type);
		}
		final List<SolutionStep> result = this.steps;
		if (result != null) {
			this.findSiameseFish(result);
			Collections.sort(result);
		}
		this.steps = oldSteps;
		Options.getInstance().setMaxFins(oldMaxFins);
		Options.getInstance().setMaxEndoFins(oldEndoFins);
		return result;
	}

	/**
	 * Search for a fish of a given size and shape.
	 */
	private SolutionStep getAnyFish(final int size, final boolean withoutFins, final boolean withFins,
			final boolean sashimi, final boolean withEndoFins, final int fishType) {
		this.searchAll = false;
		if (this.finder.getStepNumber() != this.lastStepNumber) {
			// sudoku is dirty -> cache is useless
			this.cachedSteps.clear();
			this.lastStepNumber = this.finder.getStepNumber();
		} else {
			// try the cache first
			for (int i = 0; i < this.cachedSteps.size(); i++) {
				final SolutionStep step = this.cachedSteps.get(i);
				final SolutionTechnique type = step.getType();
				// for a step to fit it must: be the same size, the same category
				// (BASIC, FRANKEN or MUTANT)
				// and finned/sashimi
				if (type.getFishSize() == size
						&& (fishType == BASIC && type.isBasicFish() || fishType == FRANKEN && type.isFrankenFish()
								|| fishType == MUTANT && type.isMutantFish())
						&& (withFins && (!step.getFins().isEmpty() || !step.getEndoFins().isEmpty()))
						&& sashimi == type.isSashimiFish()) {
					this.cachedSteps.clear();
					return step;
				}
			}
		}
		return this.getAnyFishIfNoneInCache(size, withoutFins, withFins, sashimi, withEndoFins, fishType);
	}

	private SolutionStep getAnyFishIfNoneInCache(final int size, final boolean withoutFins, final boolean withFins,
			final boolean sashimi, final boolean withEndoFins, final int fishType) {
		this.steps.clear();
		this.kraken = false;
		SolutionStep step = null;
		for (int cand = 1; cand <= 9; cand++) {
			step = this.getFishes(cand, size, size, withoutFins, withFins, sashimi, withEndoFins, fishType);
			if (!this.searchAll && !this.siamese && step != null) {
				return step;
			}
		}
		if ((this.searchAll || this.siamese) && !this.steps.isEmpty()) {
			this.findSiameseFish(this.steps);
			Collections.sort(this.steps);
			return this.steps.get(0);
		}
		return step;
	}

	/**
	 * Find all Kraken Fishes. Arguments see
	 * {@link #getAllFishes(int, int, int, int, sudoku.FindAllStepsProgressDialog, int, int)}.
	 */
	protected List<SolutionStep> getAllKrakenFishes(final int minSize, final int maxSize, final int maxFins,
			final int maxEndoFins, final int forCandidate, final int type) {
		this.tablingSolver = this.finder.getTablingSolver();
		synchronized (this.tablingSolver) {
			this.sudoku = this.finder.getSudoku();
			final boolean oldCheckTemplates = Options.getInstance().isCheckTemplates();
			Options.getInstance().setCheckTemplates(false);
			final int oldMaxFins = Options.getInstance().getMaxFins();
			final int oldEndoFins = Options.getInstance().getMaxEndoFins();
			Options.getInstance().setMaxFins(maxFins);
			Options.getInstance().setMaxEndoFins(maxEndoFins);
			final List<SolutionStep> oldSteps = this.steps;
			this.steps = new ArrayList<>();
			this.kraken = true;
			this.searchAll = true;
			this.tablingSolver.initForKrakenSearch();
			for (int i = 1; i <= 9; i++) {
				if (forCandidate != -1 && forCandidate != i) {
					// not now
					continue;
				}
				this.getFishes(i, minSize, maxSize, true, true, false, true, type);
			}
			final List<SolutionStep> result = this.steps;
			if (result != null) {
				Collections.sort(result);
			}
			this.steps = oldSteps;
			Options.getInstance().setCheckTemplates(oldCheckTemplates);
			Options.getInstance().setMaxFins(oldMaxFins);
			Options.getInstance().setMaxEndoFins(oldEndoFins);
			this.kraken = false;
			return result;
		}
	}

	/**
	 * Find a Kraken Fish. All options are taken from {@link Options}.
	 */
	private SolutionStep getKrakenFish() {
		this.tablingSolver = this.finder.getTablingSolver();
		synchronized (this.tablingSolver) {
			this.steps = new ArrayList<>();
			final boolean oldCheckTemplates = Options.getInstance().isCheckTemplates();
			Options.getInstance().setCheckTemplates(false);
			final int oldMaxFins = Options.getInstance().getMaxFins();
			final int oldEndoFins = Options.getInstance().getMaxEndoFins();
			Options.getInstance().setMaxFins(Options.getInstance().getMaxKrakenFins());
			Options.getInstance().setMaxEndoFins(Options.getInstance().getMaxKrakenEndoFins());
			this.kraken = true;
			this.tablingSolver.initForKrakenSearch();
			// Endo fins are only searched if the fish type is other than basic and if
			// the max endo fin size > 0
			this.withEndoFins = Options.getInstance().getMaxKrakenEndoFins() != 0
					&& Options.getInstance().getKrakenMaxFishType() > 0;
			final int size = Options.getInstance().getKrakenMaxFishSize();
			for (int i = 1; i <= 9; i++) {
				this.getFishes(i, 2, size, false, true, true, this.withEndoFins, Options.getInstance().getKrakenMaxFishType());
				if (!this.steps.isEmpty()) {
					break;
				}
			}
			this.kraken = false;
			Options.getInstance().setCheckTemplates(oldCheckTemplates);
			Options.getInstance().setMaxFins(oldMaxFins);
			Options.getInstance().setMaxEndoFins(oldEndoFins);
			if (!this.steps.isEmpty()) {
				this.findSiameseFish(this.steps);
				Collections.sort(this.steps);
				return this.steps.get(0);
			}
			return null;
		}
	}

	/**
	 * Searches for fishes, delegates to {@link #getFishes(boolean)}. For BASIC
	 * and FRANKEN FISH lines/cols is tried first, then cols/lines.
	 *
	 * @param candidate
	 *          The fish candidate
	 * @param minSize
	 *          Minimum number of base units (no smaller fishes are found)
	 * @param maxSize
	 *          Maximum number of base units (smaller fishes are found as well)
	 * @param withoutFins
	 *          <code>true</code>, if only finless fishes should be found
	 * @param withFins
	 *          <code>true</code>, if the search is for Finned/Sashimi Fish
	 * @param sashimi
	 *          <code>true</code>, if the search is for Sashimi Fish
	 *          (<code>withFins</code> must be true as well).
	 * @param withEndoFins
	 *          <code>true</code>, if fishes may contain endo fins
	 * @param fishType
	 *          The type of the fish ({@link #BASIC}, {@link #FRANKEN} or
	 *          {@link #MUTANT}).
	 */
	private SolutionStep getFishes(final int candidate, final int minSize, final int maxSize, final boolean withoutFins,
			final boolean withFins, final boolean sashimi, final boolean withEndoFins, final int fishType) {
		this.deletesMap.clear();
		this.siamese = Options.getInstance().isAllowDualsAndSiamese();
		this.fishType = fishType;
		this.candidate = candidate;
		this.candidatesM1 = this.finder.getCandidates()[candidate].getMask1();
		this.candidatesM2 = this.finder.getCandidates()[candidate].getMask2();
		this.doTemplates = Options.getInstance().isCheckTemplates();
		// put some restrictions on templates: they need a lot of time to be
		// computed so only use them for really large fish
		if ((fishType == BASIC && maxSize <= 5) || (fishType == FRANKEN && maxSize <= 4)
				|| (fishType == MUTANT && maxSize <= 3)) {
			this.doTemplates = false;
		}
		this.withoutFins = withoutFins;
		this.withFins = withFins;
		this.withEndoFins = withEndoFins;
		this.sashimi = sashimi;
		this.minSize = minSize;
		this.maxSize = maxSize;
		if (this.doTemplates) {
			this.delCandTemplatesM1 = this.finder.getDelCandTemplates(false)[candidate].getMask1();
			this.delCandTemplatesM2 = this.finder.getDelCandTemplates(false)[candidate].getMask2();
		}

		// search in lines first
		final SolutionStep step = this.getFishes(true);
		if (fishType == MUTANT || (!this.searchAll && !this.siamese && step != null)) {
			return step;
		}
		// then in cols
		SolutionStep step2 = this.getFishes(false);
		if (step2 == null) {
			step2 = step;
		}
		return step2;
	}

	/**
	 * Gets all fishes with size between {@link #minSize} and {@link #maxSize} of
	 * type {@link #fishType}. Most required data are set in attributes to reduce
	 * method overhead.
	 *
	 * @param withFins
	 *          <code>true</code>, if the search is for Finned/Sashimi Fish
	 * @param sashimi
	 *          <code>true</code>, if the search is for Sashimi Fish
	 *          (<code>withFins</code> must be true as well).
	 * @param withEndoFins
	 *          <code>true</code>, if fishes may contain endo fins
	 * @param lines
	 *          <code>true</code> if the search is for line/col,
	 *          <code>false</code> for col/line
	 * @return A step if one was found or <code>null</code>
	 */
	private SolutionStep getFishes(final boolean lines) {
		if (this.doTemplates) {
			this.templateSet.set(this.finder.getDelCandTemplates(false)[this.candidate]);
			this.templateSet.and(this.finder.getCandidates()[this.candidate]);
			if (this.templateSet.isEmpty()) {
				return null;
			}
		}

		// get all eligible base and cover units
		this.initForCandidate(this.maxSize, this.withFins, lines);

		// try all combinations of base units
		Arrays.fill(this.baseUnitsUsed, false);
		// start with level one (level zero is a stopper)
		this.baseLevel = 1;
		this.baseStack[0].candidatesM1 = 0;
		this.baseStack[0].candidatesM2 = 0;
		this.baseStack[0].endoFinsM1 = 0;
		this.baseStack[0].endoFinsM2 = 0;
		this.baseStack[1].aktIndex = 0;
		this.baseStack[1].lastUnit = -1;
		// the current unit index
		int aktBaseIndex = 0;
		BaseStackEntry bEntry = null;
		while (true) {
			// fall back if no unit is available (only one level because
			// baseUnitsIncluded must be treated correctly
			while (this.baseStack[this.baseLevel].aktIndex >= (this.numberOfBaseUnits)) {
				if (this.baseStack[this.baseLevel].lastUnit != -1) {
					this.baseUnitsUsed[this.baseStack[this.baseLevel].lastUnit] = false;
					this.baseStack[this.baseLevel].lastUnit = -1;
				}
				this.baseLevel--;
				if (this.baseLevel <= 0) {
					// all combinations tried -> done!
					if (!this.steps.isEmpty()) {
						return this.steps.get(0);
					}
					return null;
				}
			}
			bEntry = this.baseStack[this.baseLevel];
			// get the next base set; there must be one left or we would have fallen
			// back
			aktBaseIndex = bEntry.aktIndex++;
			// make all necessary calculations
			// if the new unit has common candidates with the current base set, those
			// candidates have to be treated as fin cells (endo fins).
			this.aktEndoFinSetM1 = this.baseStack[this.baseLevel - 1].candidatesM1 & this.baseCandidatesM1[aktBaseIndex];
			this.aktEndoFinSetM2 = this.baseStack[this.baseLevel - 1].candidatesM2 & this.baseCandidatesM2[aktBaseIndex];
			if (this.aktEndoFinSetM1 != 0 || this.aktEndoFinSetM2 != 0) {
				// intersects() == true means: there are endoFins!
				if (!this.withFins || !this.withEndoFins
						|| (this.getSize(this.baseStack[this.baseLevel - 1].endoFinsM1,
								this.baseStack[this.baseLevel - 1].endoFinsM2)
								+ this.getSize(this.aktEndoFinSetM1, this.aktEndoFinSetM2)) > Options.getInstance().getMaxEndoFins()) {
					// every invalid combination eliminates a lot of possibilities:
					// (all non-zero baseUnits greater than i) over (maxSize - aktSize)
					continue;
				}
			}
			bEntry.candidatesM1 = this.baseStack[this.baseLevel - 1].candidatesM1 | this.baseCandidatesM1[aktBaseIndex];
			bEntry.candidatesM2 = this.baseStack[this.baseLevel - 1].candidatesM2 | this.baseCandidatesM2[aktBaseIndex];
			bEntry.endoFinsM1 = this.baseStack[this.baseLevel - 1].endoFinsM1 | this.aktEndoFinSetM1;
			bEntry.endoFinsM2 = this.baseStack[this.baseLevel - 1].endoFinsM2 | this.aktEndoFinSetM2;
			if (bEntry.lastUnit != -1) {
				this.baseUnitsUsed[bEntry.lastUnit] = false;
			}
			bEntry.lastUnit = this.baseUnits[aktBaseIndex];
			this.baseUnitsUsed[this.baseUnits[aktBaseIndex]] = true;
			this.finBuddiesM1 = SudokuSetBase.MAX_MASK1;
			this.finBuddiesM2 = SudokuSetBase.MAX_MASK2;
			if (this.doTemplates && (bEntry.endoFinsM1 != 0 || bEntry.endoFinsM2 != 0)) {
				// all cells that can see all the endo fins
				Sudoku2.getBuddies(bEntry.endoFinsM1, bEntry.endoFinsM2, this.getBuddiesSet);
				this.finBuddiesM1 = this.getBuddiesSet.getMask1() & ~this.candidatesM1 & this.delCandTemplatesM1;
				this.finBuddiesM2 = this.getBuddiesSet.getMask2() & ~this.candidatesM2 & this.delCandTemplatesM2;
			}
			if (this.baseLevel >= this.minSize && this.baseLevel <= this.maxSize
					&& (this.finBuddiesM1 != 0 || this.finBuddiesM2 != 0)) {
				final SolutionStep step = this.searchCoverUnits(bEntry.candidatesM1, bEntry.candidatesM2, bEntry.endoFinsM1,
						bEntry.endoFinsM2);
				if (!this.searchAll && !this.siamese && step != null) {
					return step;
				}
			}
			// and on to the next level
			if (this.baseLevel < this.maxSize) {
				this.baseLevel++;
				bEntry = this.baseStack[this.baseLevel];
				bEntry.aktIndex = aktBaseIndex + 1;
				bEntry.lastUnit = -1;
			}
		}
	}

	/**
	 * The complete cover unit search: all possible combinations of cover units
	 * that are not identical with base units are tried.
	 */
	private SolutionStep searchCoverUnits(final long baseSetM1, final long baseSetM2, final long endoFinSetM1,
			final long endoFinSetM2) {
		this.numberOfCoverUnits = 0;
		for (int i = 0; i < this.numberOfAllCoverUnits; i++) {
			if (this.baseUnitsUsed[this.allCoverUnits[i]]) {
				// possible cover unit is base unit -> skip it
				continue;
			}
			if ((baseSetM1 & this.allCoverCandidatesM1[i]) == 0 && (baseSetM2 & this.allCoverCandidatesM2[i]) == 0) {
				// no common candidates -> skip it
				continue;
			}
			// valid cover unit
			this.coverUnits[this.numberOfCoverUnits] = this.allCoverUnits[i];
			this.coverCandidatesM1[this.numberOfCoverUnits] = this.allCoverCandidatesM1[i];
			this.coverCandidatesM2[this.numberOfCoverUnits++] = this.allCoverCandidatesM2[i];
		}
		// try all combinations of cover units
		Arrays.fill(this.coverUnitsUsed, false);
		// start with level one (level zero is a stopper)
		this.coverLevel = 1;
		this.coverStack[0].candidatesM1 = 0;
		this.coverStack[0].candidatesM2 = 0;
		this.coverStack[0].cannibalisticM1 = 0;
		this.coverStack[0].cannibalisticM2 = 0;
		this.coverStack[1].aktIndex = 0;
		this.coverStack[1].lastUnit = -1;
		// the current unit index
		int aktCoverIndex = 0;
		CoverStackEntry cEntry = null;
		while (true) {
			// fall back if no unit is available (only one level because
			// coverUnitsIncluded must be treated correctly
			while (this.coverStack[this.coverLevel].aktIndex >= (this.numberOfCoverUnits - this.baseLevel
					+ this.coverLevel)) {
				if (this.coverStack[this.coverLevel].lastUnit != -1) {
					this.coverUnitsUsed[this.coverStack[this.coverLevel].lastUnit] = false;
					this.coverStack[this.coverLevel].lastUnit = -1;
				}
				this.coverLevel--;
				if (this.coverLevel <= 0) {
					// all combinations tried -> done!
					if (!this.steps.isEmpty()) {
						return this.steps.get(0);
					}
					return null;
				}
			}
			cEntry = this.coverStack[this.coverLevel];
			// get the next cover set; there must be one left or we would have fallen
			// back
			aktCoverIndex = cEntry.aktIndex++;
			this.aktCannibalismSetM1 = this.coverStack[this.coverLevel - 1].candidatesM1
					& this.coverCandidatesM1[aktCoverIndex];
			this.aktCannibalismSetM2 = this.coverStack[this.coverLevel - 1].candidatesM2
					& this.coverCandidatesM2[aktCoverIndex];
			// calculate union of existing sets with new cover unit
			// entry.candidates.setOr(coverStack[coverLevel - 1].candidates,
			cEntry.candidatesM1 = this.coverStack[this.coverLevel - 1].candidatesM1 | this.coverCandidatesM1[aktCoverIndex];
			cEntry.candidatesM2 = this.coverStack[this.coverLevel - 1].candidatesM2 | this.coverCandidatesM2[aktCoverIndex];
			cEntry.cannibalisticM1 = this.coverStack[this.coverLevel - 1].cannibalisticM1 | this.aktCannibalismSetM1;
			cEntry.cannibalisticM2 = this.coverStack[this.coverLevel - 1].cannibalisticM2 | this.aktCannibalismSetM2;
			if (cEntry.lastUnit != -1) {
				this.coverUnitsUsed[cEntry.lastUnit] = false;
			}
			cEntry.lastUnit = this.coverUnits[aktCoverIndex];
			this.coverUnitsUsed[this.coverUnits[aktCoverIndex]] = true;
			// statistic
			if (this.coverLevel == this.baseLevel) {
				this.finsM1 = this.finsM2 = 0;
				final long m1 = ~cEntry.candidatesM1 & baseSetM1;
				final long m2 = ~cEntry.candidatesM2 & baseSetM2;
				boolean isCovered = true;
				if (m1 != 0) {
					isCovered = false;
					this.finsM1 = m1;
				}
				if (m2 != 0) {
					isCovered = false;
					this.finsM2 = m2;
				}
				this.finsM1 |= endoFinSetM1;
				this.finsM2 |= endoFinSetM2;
				// for kraken search withoutFins must be false!
				int finSize = 0;
				if (isCovered && this.withoutFins && this.finsM1 == 0 && this.finsM2 == 0) {
					this.anzFins[0]++;
					this.tmpSetM1 = cEntry.candidatesM1 & ~baseSetM1;
					this.tmpSetM2 = cEntry.candidatesM2 & ~baseSetM2;
					if (this.tmpSetM1 != 0 || this.tmpSetM2 != 0 || cEntry.cannibalisticM1 != 0 || cEntry.cannibalisticM2 != 0) {
						// we found ourselves a fish!
						final SolutionStep step = this.createFishStep(this.coverLevel, false, this.finsM1, this.finsM2,
								this.tmpSetM1, this.tmpSetM2, cEntry.cannibalisticM1, cEntry.cannibalisticM2, endoFinSetM1,
								endoFinSetM2, this.tmpSetM1, this.tmpSetM2, false);
						if (!this.searchAll && !this.siamese && step != null) {
							return step;
						}
					}
				} else if (this.withFins && (finSize = this.getSize(this.finsM1, this.finsM2)) > 0
						&& finSize <= Options.getInstance().getMaxFins()) {
					this.anzFins[finSize]++;
					// A candidate is a potential elimination, if it belongs to the cover
					// set, but not to
					// base set, or belongs to more than one cover set. A potential
					// elimination
					// becomes an eventual elimination, if it sees all fins (including
					// endo fins).

					// get all cells that can possibly see all fins
					Sudoku2.getBuddies(this.finsM1, this.finsM2, this.getBuddiesSet);
					this.finBuddiesM1 = this.getBuddiesSet.getMask1();
					this.finBuddiesM2 = this.getBuddiesSet.getMask2();
					if (this.finBuddiesM1 != 0 || this.finBuddiesM2 != 0) {
						this.tmpSetM1 = cEntry.candidatesM1 & ~baseSetM1;
						this.tmpSetM2 = cEntry.candidatesM2 & ~baseSetM2;
						this.tmpSet2M1 = this.tmpSetM1;
						this.tmpSet2M2 = this.tmpSetM2;
						this.tmpSetM1 &= this.finBuddiesM1;
						this.tmpSetM2 &= this.finBuddiesM2;
						this.tmpSet1M1 = cEntry.cannibalisticM1 & this.finBuddiesM1;
						this.tmpSet1M2 = cEntry.cannibalisticM2 & this.finBuddiesM2;
						if (!this.kraken
								&& (this.tmpSetM1 != 0 || this.tmpSetM2 != 0 || this.tmpSet1M1 != 0 || this.tmpSet1M2 != 0)) {
							final SolutionStep step = this.createFishStep(this.coverLevel, true, this.finsM1, this.finsM2,
									this.tmpSetM1, this.tmpSetM2, this.tmpSet1M1, this.tmpSet1M2, endoFinSetM1, endoFinSetM2,
									this.tmpSet2M1, this.tmpSet2M2, false);
							if (step != null && !this.searchAll && !this.siamese) {
								return step;
							}
						} else if (this.kraken && this.tmpSetM1 == 0 && this.tmpSetM2 == 0 && this.tmpSet1M1 == 0
								&& this.tmpSet1M2 == 0) {
							// tmpSet2: cover & ~base -> potential eliminations, add
							// cannibalistic
							this.tmpSet2M1 |= cEntry.cannibalisticM1;
							this.tmpSet2M2 |= cEntry.cannibalisticM2;
							final SolutionStep step = this.searchForKraken(this.tmpSet2M1, this.tmpSet2M2, baseSetM1, baseSetM2,
									this.finsM1, this.finsM2, cEntry.cannibalisticM1, cEntry.cannibalisticM2, endoFinSetM1, endoFinSetM2);
							if (step != null && !this.searchAll) {
								return step;
							}
						}
					}
				}
			}
			// and on to the next level
			if (this.coverLevel < this.maxSize) {
				this.coverLevel++;
				cEntry = this.coverStack[this.coverLevel];
				cEntry.aktIndex = aktCoverIndex + 1;
				cEntry.lastUnit = -1;
			}
		}
	}

	/**
	 * Search the current base/cover set combination for possible Kraken Fish
	 *
	 * @param deleteSetM1
	 *          All potential eliminations, including cannibalistic ones
	 * @param baseSetM1
	 *          All base candidates
	 * @param finsM1
	 *          All fins (including endo fins)
	 * @param cannibalisticM1
	 *          All potential cannibalistic eliminations
	 * @param cannibalisticM2
	 * @param endoFinsM1
	 *          All endo fins (included in finsM1/finsM2)
	 */
	private SolutionStep searchForKraken(final long deleteSetM1, final long deleteSetM2, final long baseSetM1,
			final long baseSetM2, final long finsM1, final long finsM2, final long cannibalisticM1,
			final long cannibalisticM2, final long endoFinsM1, final long endoFinsM2) {
		// Type 1: We have fins but nothing to delete -> check all
		// cover candidates that are not base candidates wether they can be linked
		// to every fin (if fin set -> cover candidate is not set)
		// only one candidate at a time!

		// deleteSet holds all potential eliminations, including cannibalistic ones
		if (deleteSetM1 != 0 || deleteSetM2 != 0) {
			this.krakenDeleteCandSet.set(deleteSetM1, deleteSetM2);
			this.krakenFinSet.set(finsM1, finsM2);
			for (int j = 0; j < this.krakenDeleteCandSet.size(); j++) {
				final int endIndex = this.krakenDeleteCandSet.get(j);
				if (this.tablingSolver.checkKrakenTypeOne(this.krakenFinSet, endIndex, this.candidate)) {
					// kraken fish found -> add!
					this.krakenCannibalisticSet.set(cannibalisticM1, cannibalisticM2);
					if (this.krakenCannibalisticSet.contains(endIndex)) {
						this.krakenCannibalisticSet.clear();
						this.krakenCannibalisticSet.add(endIndex);
					} else {
						this.krakenCannibalisticSet.clear();
					}
					// we add a step without candidates to delete -> we get there
					// afterwards
					SolutionStep step = this.createFishStep(this.coverLevel, true, finsM1, finsM2, 0, 0,
							this.krakenCannibalisticSet.getMask1(), this.krakenCannibalisticSet.getMask2(), endoFinsM1, endoFinsM2,
							deleteSetM1, deleteSetM2, true);
					step.setSubType(step.getType());
					step.setType(SolutionTechnique.KRAKEN_FISH_TYPE_1);
					step.addCandidateToDelete(endIndex, this.candidate);
					// now the chains
					for (int k = 0; k < this.krakenFinSet.size(); k++) {
						final Chain tmpChain = this.tablingSolver.getKrakenChain(this.krakenFinSet.get(k), this.candidate, endIndex,
								this.candidate);
						step.addChain((Chain) tmpChain.clone());
					}
					this.tablingSolver.adjustChains(step);
					step = this.addKrakenStep(step);
					if (step != null && !this.searchAll) {
						return step;
					}
				}
			}
		}
		// Type 2: For every cover set find chains from all base candidates and all
		// fins to a single candidate a check is only necessary if the cover unit
		// doesnt only contain base candidates for cannibalistic candidates no chain
		// is needed
		this.krakenCannibalisticSet.clear();
		for (int coverIndex = 0; coverIndex < this.numberOfCoverUnits; coverIndex++) {
			if (!this.coverUnitsUsed[this.coverUnits[coverIndex]]) {
				continue;
			}
			this.tmpSetM1 = this.coverCandidatesM1[coverIndex] & baseSetM1 & ~cannibalisticM1;
			this.tmpSetM2 = this.coverCandidatesM2[coverIndex] & baseSetM2 & ~cannibalisticM2;
			if (this.coverCandidatesM1[coverIndex] == this.tmpSetM1 && this.coverCandidatesM2[coverIndex] == this.tmpSetM2) {
				// would be a normal Forcing Chain -> skip it
				continue;
			}
			// now add the fins and check all candidates
			this.tmpSetM1 |= finsM1;
			this.tmpSetM2 |= finsM2;
			this.krakenDeleteCandSet.set(this.tmpSetM1, this.tmpSetM2);
			this.krakenFinSet.clear();
			for (int endCandidate = 1; endCandidate <= 9; endCandidate++) {
				if (this.tablingSolver.checkKrakenTypeTwo(this.krakenDeleteCandSet, this.krakenFinSet, this.candidate,
						endCandidate)) {
					// kraken fishes found -> add!
					for (int j = 0; j < this.krakenFinSet.size(); j++) {
						final int endIndex = this.krakenFinSet.get(j);
						// we add a step without candidates to delete -> we get there
						// afterwards
						SolutionStep step = this.createFishStep(this.coverLevel, true, finsM1, finsM2, 0, 0, 0, 0, endoFinsM1,
								endoFinsM2, deleteSetM1, deleteSetM2, true);
						step.setSubType(step.getType());
						step.setType(SolutionTechnique.KRAKEN_FISH_TYPE_2);
						step.addCandidateToDelete(endIndex, endCandidate);
						for (int k = 0; k < this.krakenDeleteCandSet.size(); k++) {
							final Chain tmpChain = this.tablingSolver.getKrakenChain(this.krakenDeleteCandSet.get(k), this.candidate,
									endIndex, endCandidate);
							step.addChain((Chain) tmpChain.clone());
						}
						this.tablingSolver.adjustChains(step);
						step = this.addKrakenStep(step);
						if (step != null && !this.searchAll) {
							return step;
						}
					}
				}
			}
		}
		return null;
	}

	/**
	 * If more than one step is collected ({@link #searchAll} or {@link #siamese}
	 * are set), the step is added to {@link #steps}, in all other cases a copy of
	 * {@link #globalStep} is returned.
	 */
	private SolutionStep addFishStep() {
		if (!this.searchAll && !this.siamese) {
			return (SolutionStep) this.globalStep.clone();
		}
		if (this.fishType != UNDEFINED && !this.searchAll) {
			final SolutionTechnique type = this.globalStep.getType();
			if (this.fishType == BASIC && !type.isBasicFish()) {
				return null;
			}
			if (this.fishType == FRANKEN && !type.isFrankenFish()) {
				return null;
			}
			if (this.fishType == MUTANT && !type.isMutantFish()) {
				return null;
			}
		}
		if (Options.getInstance().isOnlyOneFishPerStep()) {
			final String delOrg = this.globalStep.getCandidateString();
			int startIndex = delOrg.indexOf(')');
			startIndex = delOrg.indexOf('(', startIndex);
			final String del = delOrg.substring(0, startIndex);
			final Integer oldIndex = this.deletesMap.get(del);
			SolutionStep tmpStep = null;
			if (oldIndex != null) {
				tmpStep = this.steps.get(oldIndex.intValue());
			}
			if (tmpStep == null || this.globalStep.getType().compare(tmpStep.getType()) < 0) {
				if (oldIndex != null) {
					this.steps.remove(oldIndex.intValue());
					this.steps.add(oldIndex.intValue(), (SolutionStep) this.globalStep.clone());
				} else {
					this.steps.add((SolutionStep) this.globalStep.clone());
					this.deletesMap.put(del, this.steps.size() - 1);
				}
			}
		} else {
			this.steps.add((SolutionStep) this.globalStep.clone());
		}
		return null;
	}

	/**
	 * Adds a Kraken Fish to {@link #steps} if an equivalent smaller fish doesnt
	 * already exist.
	 */
	private SolutionStep addKrakenStep(final SolutionStep step) {
		final String del = step.getCandidateString() + " " + step.getValues().get(0);
		final Integer oldIndex = this.deletesMap.get(del);
		SolutionStep tmpStep = null;
		if (oldIndex != null) {
			tmpStep = this.steps.get(oldIndex);
		}
		if (tmpStep == null || step.getSubType().compare(tmpStep.getSubType()) < 0
				|| (step.getSubType().compare(tmpStep.getSubType()) == 0 && step.getChainLength() < tmpStep.getChainLength())) {
			this.steps.add(step);
			this.deletesMap.put(del, this.steps.size() - 1);
			return step;
		}
		return null;
	}

	/**
	 * Siamese Fish are two fishes that have the same base sets and differ only in
	 * which candidates are fins; they provide different eliminations. only fishes
	 * of the same category are checked
	 *
	 * To find them: Compare all pairs of fishes, if the base sets match create a
	 * new steps, that contains the same base set and both cover sets/fins/
	 * eliminations.
	 *
	 * @param fishes
	 *          All available fishes
	 */
	private void findSiameseFish(final List<SolutionStep> fishes) {
		if (!Options.getInstance().isAllowDualsAndSiamese()) {
			// not allowed!
			return;
		}
		// read current size (list can be changed by Siamese Fishes)
		final int maxIndex = fishes.size();
		for (int i = 0; i < maxIndex - 1; i++) {
			for (int j = i + 1; j < maxIndex; j++) {
				final SolutionStep step1 = fishes.get(i);
				final SolutionStep step2 = fishes.get(j);
				if (step1.getValues().get(0) != step2.getValues().get(0)) {
					// different candidate
					continue;
				}
				if (step1.getBaseEntities().size() != step2.getBaseEntities().size()) {
					// different fish size -> no dual
					continue;
				}
				if (SolutionTechnique.getStepConfig(step1.getType()).getCategory().ordinal() != SolutionTechnique
						.getStepConfig(step2.getType()).getCategory().ordinal()) {
					// not the same type of fish
					continue;
				}
				boolean baseSetEqual = true;
				for (int k = 0; k < step1.getBaseEntities().size(); k++) {
					if (!step1.getBaseEntities().get(k).equals(step2.getBaseEntities().get(k))) {
						baseSetEqual = false;
						break;
					}
				}
				if (!baseSetEqual) {
					// not the same base set -> cant be a siamese fish
					continue;
				}
				// possible siamese fish; different eliminations?
				if (step1.getCandidatesToDelete().get(0).equals(step2.getCandidatesToDelete().get(0))) {
					// same step twice -> no siamese fish
					continue;
				}
				// ok: siamese fish!
				final SolutionStep siameseStep = (SolutionStep) step1.clone();
				siameseStep.setIsSiamese(true);
				for (int k = 0; k < step2.getCoverEntities().size(); k++) {
					siameseStep.addCoverEntity(step2.getCoverEntities().get(k));
				}
				for (int k = 0; k < step2.getFins().size(); k++) {
					siameseStep.addFin(step2.getFins().get(k));
				}
				for (int k = 0; k < step2.getCandidatesToDelete().size(); k++) {
					siameseStep.addCandidateToDelete(step2.getCandidatesToDelete().get(k));
				}
				siameseStep.getPotentialEliminations().or(step2.getPotentialEliminations());
				siameseStep.getPotentialCannibalisticEliminations().or(step2.getPotentialCannibalisticEliminations());
				fishes.add(siameseStep);
			}
		}
	}

	/**
	 * Create a new fish step. The step is added to the step list if
	 * {@link #searchAll} or {@link #siamese} are set.
	 *
	 * @param potentialEliminations
	 *          All potential eliminations without cannibalistic eliminations
	 * @param kraken
	 *          add step in any case
	 */
	private SolutionStep createFishStep(final int size, final boolean withFins, final long finSetM1, final long finSetM2,
			final long deleteSetM1, final long deleteSetM2, final long cannibalisticSetM1, final long cannibalisticSetM2,
			final long endoFinSetM1, final long endoFinSetM2, final long potentialEliminationsM1,
			final long potentialEliminationsM2, final boolean kraken) {
		this.globalStep.reset();

		// Get masks for the constraint types included in the base and cover sets
		SolutionTechnique type = SolutionTechnique.X_WING;
		final int baseMask = this.getUnitMask(this.baseUnitsUsed);
		final int coverMask = this.getUnitMask(this.coverUnitsUsed);

		// check for Sashimi (only for BASIC FISH)
		boolean isSashimi = false;
		if ((baseMask == LINE_MASK && coverMask == COL_MASK) || (baseMask == COL_MASK && coverMask == LINE_MASK)) {
			for (int i = 0; i < this.numberOfBaseUnits; i++) {
				if (this.baseUnitsUsed[this.baseUnits[i]]) {
					this.checkSashimiSetM1 = this.baseCandidatesM1[i] & ~finSetM1;
					this.checkSashimiSetM2 = this.baseCandidatesM2[i] & ~finSetM2;
					if (this.getSizeLTE1(this.checkSashimiSetM1, this.checkSashimiSetM2)) {
						isSashimi = true;
						break;
					}
				}
			}
		}

		// determine the type
		if ((baseMask == LINE_MASK && coverMask == COL_MASK) || (baseMask == COL_MASK && coverMask == LINE_MASK)) {
			// Basic Fish
			if (isSashimi) {
				type = SASHIMI_BASIC_TYPES[size - 2];
			} else if (withFins) {
				type = FINNED_BASIC_TYPES[size - 2];
			} else {
				type = BASIC_TYPES[size - 2];
			}
		} else if ((((baseMask == LINE_MASK) || (baseMask == (LINE_MASK | BLOCK_MASK)))
				&& ((coverMask == COL_MASK) || (coverMask == (COL_MASK | BLOCK_MASK))))
				|| (((baseMask == COL_MASK) || (baseMask == (COL_MASK | BLOCK_MASK)))
						&& ((coverMask == LINE_MASK) || (coverMask == (LINE_MASK | BLOCK_MASK))))) {
			// Franken Fish
			if (withFins) {
				type = FINNED_FRANKEN_TYPES[size - 2];
			} else {
				type = FRANKEN_TYPES[size - 2];
			}
		} else {
			// Mutant Fish
			if (withFins) {
				type = FINNED_MUTANT_TYPES[size - 2];
			} else {
				type = MUTANT_TYPES[size - 2];
			}
		}
		this.globalStep.setType(type);
		this.globalStep.addValue(this.candidate);
		long bm1 = this.baseStack[this.baseLevel].candidatesM1 & ~finSetM1;
		long bm2 = this.baseStack[this.baseLevel].candidatesM2 & ~finSetM2;
		this.createFishSet.set(bm1, bm2);
		for (int i = 0; i < this.createFishSet.size(); i++) {
			this.globalStep.addIndex(this.createFishSet.get(i));
		}
		for (int i = 0; i < this.baseUnitsUsed.length; i++) {
			if (this.baseUnitsUsed[i]) {
				this.globalStep.addBaseEntity(Sudoku2.CONSTRAINT_TYPE_FROM_CONSTRAINT[i],
						Sudoku2.CONSTRAINT_NUMBER_FROM_CONSTRAINT[i]);
			}
		}
		for (int i = 0; i < this.coverUnitsUsed.length; i++) {
			if (this.coverUnitsUsed[i]) {
				this.globalStep.addCoverEntity(Sudoku2.CONSTRAINT_TYPE_FROM_CONSTRAINT[i],
						Sudoku2.CONSTRAINT_NUMBER_FROM_CONSTRAINT[i]);
			}
		}
		this.createFishSet.set(deleteSetM1, deleteSetM2);
		for (int k = 0; k < this.createFishSet.size(); k++) {
			this.globalStep.addCandidateToDelete(this.createFishSet.get(k), this.candidate);
		}
		// cannibalistic eliminations
		this.createFishSet.set(cannibalisticSetM1, cannibalisticSetM2);
		for (int k = 0; k < this.createFishSet.size(); k++) {
			this.globalStep.addCannibalistic(this.createFishSet.get(k), this.candidate);
			this.globalStep.addCandidateToDelete(this.createFishSet.get(k), this.candidate);
		}
		bm1 = finSetM1 & ~endoFinSetM1;
		bm2 = finSetM2 & ~endoFinSetM2;
		this.createFishSet.set(bm1, bm2);
		for (int i = 0; i < this.createFishSet.size(); i++) {
			this.globalStep.addFin(this.createFishSet.get(i), this.candidate);
		}
		this.createFishSet.set(endoFinSetM1, endoFinSetM2);
		for (int i = 0; i < this.createFishSet.size(); i++) {
			this.globalStep.addEndoFin(this.createFishSet.get(i), this.candidate);
		}
		// add potential (cannibalistic) eliminations
		this.createFishSet.set(potentialEliminationsM1, potentialEliminationsM2);
		this.globalStep.getPotentialEliminations().set(this.createFishSet);
		this.createFishSet.set(cannibalisticSetM1, cannibalisticSetM2);
		this.globalStep.getPotentialCannibalisticEliminations().set(this.createFishSet);

		// differentiate between finned and sashimi: if the type doesnt fit, cache
		// the step but only if the search is not for all fishes
		if (!this.searchAll && this.fishType == BASIC && withFins && this.sashimi != isSashimi) {
			this.cachedSteps.add((SolutionStep) this.globalStep.clone());
			return null;
		}

		// add it to steps or return it
		if (kraken) {
			return (SolutionStep) this.globalStep.clone();
		} else {
			return this.addFishStep();
		}
	}

	/**
	 * Creates a mask that contains bits for every type of constraint contained in
	 * <code>used</code>.
	 */
	private int getUnitMask(final boolean[] used) {
		int mask = 0;
		for (int i = 0; i < used.length; i++) {
			if (used[i]) {
				mask |= MASKS[Sudoku2.CONSTRAINT_TYPE_FROM_CONSTRAINT[i]];
			}
		}
		return mask;
	}

	/**
	 * Calculates all base and cover sets for the current search. Which set is
	 * possible depends on the <code>type</code> of the fish, on its
	 * <code>size</code> (a base set in a search without fins cannot have more
	 * than <code>size</code> candidates) and the status of <code>lines</code>: If
	 * it is <code>true</code>, the base sets include the lines and the cover set
	 * the cols for basic and franken fish.<br>
	 * {@link #candidate}, {@link #candidates} and {@link #fishType} must already
	 * be set.
	 *
	 * @param size
	 *          The maximum size of the fish
	 * @param withFins
	 *          If <code>false</code>, no base set can have more than
	 *          <code>size</code> candidates
	 * @param lines
	 *          If <code>true</code>, the lines go into the base set
	 */
	private void initForCandidate(final int size, final boolean withFins, final boolean lines) {
		this.numberOfBaseUnits = this.numberOfAllCoverUnits = 0;

		// go through all sets
		for (int i = 0; i < Sudoku2.ALL_CONSTRAINTS_TEMPLATES.length; i++) {
			if (i >= 18 && this.fishType == BASIC) {
				continue;
			}
			this.tmpSetM1 = Sudoku2.ALL_CONSTRAINTS_TEMPLATES_M1[i] & this.candidatesM1;
			this.tmpSetM2 = Sudoku2.ALL_CONSTRAINTS_TEMPLATES_M2[i] & this.candidatesM2;
			if (this.tmpSetM1 == 0 && this.tmpSetM2 == 0) {
				// no candidate in unit -> skip it
				continue;
			}
			// valid unit -> store it
			if (i < 9) {
				// unit is a line
				if (lines || this.fishType == MUTANT) {
					this.addUnit(i, this.tmpSetM1, this.tmpSetM2, true, size, withFins);
					if (this.fishType == MUTANT) {
						this.addUnit(i, this.tmpSetM1, this.tmpSetM2, false, size, withFins);
					}
				} else if (!lines || this.fishType == MUTANT) {
					this.addUnit(i, this.tmpSetM1, this.tmpSetM2, false, size, withFins);
					if (this.fishType == MUTANT) {
						this.addUnit(i, this.tmpSetM1, this.tmpSetM2, true, size, withFins);
					}
				}
			} else if (i < 18) {
				// unit is a column
				if (lines || this.fishType == MUTANT) {
					this.addUnit(i, this.tmpSetM1, this.tmpSetM2, false, size, withFins);
					if (this.fishType == MUTANT) {
						this.addUnit(i, this.tmpSetM1, this.tmpSetM2, true, size, withFins);
					}
				} else if (!lines || this.fishType == MUTANT) {
					this.addUnit(i, this.tmpSetM1, this.tmpSetM2, true, size, withFins);
					if (this.fishType == MUTANT) {
						this.addUnit(i, this.tmpSetM1, this.tmpSetM2, false, size, withFins);
					}
				}
			} else {
				// unit is a block
				if (this.fishType != BASIC) {
					this.addUnit(i, this.tmpSetM1, this.tmpSetM2, false, size, withFins);
					this.addUnit(i, this.tmpSetM1, this.tmpSetM2, true, size, withFins);
				}
			}
		}
	}

	/**
	 * Adds a unit to the base or cover units. If the search is for finnless fish,
	 * base units are only added if they have atmost <code>size</code> candidates.
	 */
	private void addUnit(final int unit, final long setM1, final long setM2, final boolean base, final int size,
			final boolean withFins) {
		if (base) {
			if (withFins || this.getSize(setM1, setM2) <= size) {
				this.baseUnits[this.numberOfBaseUnits] = unit;
				this.baseCandidatesM1[this.numberOfBaseUnits] = setM1;
				this.baseCandidatesM2[this.numberOfBaseUnits++] = setM2;
			}
		} else {
			this.allCoverUnits[this.numberOfAllCoverUnits] = unit;
			this.allCoverCandidatesM1[this.numberOfAllCoverUnits] = setM1;
			this.allCoverCandidatesM2[this.numberOfAllCoverUnits++] = setM2;
		}
	}

	/**
	 * Determines the number of bits set in <code>mask1</code> and
	 * <code>mask2</code>.
	 */
	private int getSize(final long mask1, final long mask2) {
		int anzahl = 0;
		if (mask1 != 0) {
			for (int i = 0; i < 64; i += 8) {
				anzahl += SudokuSet.anzValues[(int) ((mask1 >> i) & 0xFF)];
			}
		}
		if (mask2 != 0) {
			for (int i = 0; i < 24; i += 8) {
				anzahl += SudokuSet.anzValues[(int) ((mask2 >> i) & 0xFF)];
			}
		}
		return anzahl;
	}

	/**
	 * Determines if only 0 or 1 bit is set in <code>mask1</code> and
	 * <code>mask2</code>.
	 */
	private boolean getSizeLTE1(final long mask1, final long mask2) {
		int anzahl = 0;
		if (mask1 != 0) {
			for (int i = 0; i < 64; i += 8) {
				anzahl += SudokuSet.anzValues[(int) ((mask1 >> i) & 0xFF)];
				if (anzahl > 1) {
					return false;
				}
			}
		}
		if (mask2 != 0) {
			for (int i = 0; i < 24; i += 8) {
				anzahl += SudokuSet.anzValues[(int) ((mask2 >> i) & 0xFF)];
				if (anzahl > 1) {
					return false;
				}
			}
		}
		return true;
	}

}
