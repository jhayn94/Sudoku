/*
 * Copyright (C) 2008-12  Bernhard Hobiger
 *
 * This file is part of HoDoKu.
 *
 * HoDoKu is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * HoDoKu is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with HoDoKu. If not, see <http://www.gnu.org/licenses/>.
 */

package sudoku.solver;

import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import sudoku.model.Candidate;
import sudoku.model.SolutionStep;
import sudoku.model.SudokuSet;
import sudoku.model.util.SolutionTechnique;

public class TemplateSolver extends AbstractSolver {

	private List<SolutionStep> steps;

	private final SolutionStep globalStep = new SolutionStep(SolutionTechnique.HIDDEN_SINGLE);

	/**
	 * Creates a new instance of TemplateSolver
	 *
	 * @param finder
	 */
	public TemplateSolver(final SudokuStepFinder finder) {
		super(finder);
	}

	@Override
	protected SolutionStep getStep(final SolutionTechnique type) {
		SolutionStep result = null;
		this.sudoku = this.finder.getSudoku();
		switch (type) {
		case TEMPLATE_SET:
			this.getTemplateSet(true);
			if (!this.steps.isEmpty()) {
				result = this.steps.get(0);
			}
			break;
		case TEMPLATE_DEL:
			this.getTemplateDel(true);
			if (!this.steps.isEmpty()) {
				result = this.steps.get(0);
			}
			break;
		default: // Nothing to do.
		}
		return result;
	}

	@Override
	protected boolean doStep(final SolutionStep step) {
		boolean handled = true;
		this.sudoku = this.finder.getSudoku();
		switch (step.getType()) {
		case TEMPLATE_SET:
			final int value = step.getValues().get(0);
			for (final int index : step.getIndices()) {
				this.sudoku.setCell(index, value);
			}
			break;
		case TEMPLATE_DEL:
			for (final Candidate cand : step.getCandidatesToDelete()) {
				this.sudoku.delCandidate(cand.getIndex(), cand.getValue());
			}
			break;
		default:
			handled = false;
		}
		return handled;
	}

	protected List<SolutionStep> getAllTemplates() {
		this.sudoku = this.finder.getSudoku();
		final List<SolutionStep> oldSteps = this.steps;
		this.steps = new ArrayList<>();
		long millis1 = System.currentTimeMillis();
		this.getTemplateSet(false);
		this.getTemplateDel(false);
		millis1 = System.currentTimeMillis() - millis1;
		Logger.getLogger(this.getClass().getName()).log(Level.FINE, "getAllTemplates() gesamt: {0}ms", millis1);
		final List<SolutionStep> result = this.steps;
		this.steps = oldSteps;
		return result;
	}

	private void getTemplateSet(final boolean initSteps) {
		if (initSteps) {
			this.steps = new ArrayList<>();
		}

		final SudokuSet setSet = new SudokuSet();
		for (int i = 1; i <= 9; i++) {
			setSet.set(this.finder.getSetValueTemplates(true)[i]);
			setSet.andNot(this.finder.getPositions()[i]);
			if (!setSet.isEmpty()) {
				this.globalStep.reset();
				this.globalStep.setType(SolutionTechnique.TEMPLATE_SET);
				this.globalStep.addValue(i);
				for (int j = 0; j < setSet.size(); j++) {
					this.globalStep.addIndex(setSet.get(j));
				}
				this.steps.add((SolutionStep) this.globalStep.clone());
			}
		}
	}

	private void getTemplateDel(final boolean initSteps) {
		if (initSteps) {
			this.steps = new ArrayList<>();
		}

		final SudokuSet setSet = new SudokuSet();
		for (int i = 1; i <= 9; i++) {
			setSet.set(this.finder.getDelCandTemplates(true)[i]);
			setSet.and(this.finder.getCandidates()[i]);
			if (!setSet.isEmpty()) {
				this.globalStep.reset();
				this.globalStep.setType(SolutionTechnique.TEMPLATE_DEL);
				this.globalStep.addValue(i);
				for (int j = 0; j < setSet.size(); j++) {
					this.globalStep.addCandidateToDelete(setSet.get(j), i);
				}
				this.steps.add((SolutionStep) this.globalStep.clone());
			}
		}
	}

}
