/*
 * Copyright (C) 2008-12  Bernhard Hobiger
 *
 * This file is part of HoDoKu.
 *
 * HoDoKu is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * HoDoKu is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with HoDoKu. If not, see <http://www.gnu.org/licenses/>.
 */

package sudoku.solver;

import java.util.ArrayList;
import java.util.List;

import sudoku.model.Options;
import sudoku.model.SolutionStep;
import sudoku.model.StepConfig;
import sudoku.model.Sudoku2;
import sudoku.model.util.ClipboardMode;
import sudoku.model.util.DifficultyLevel;
import sudoku.model.util.DifficultyType;
import sudoku.model.util.PuzzleType;
import sudoku.model.util.SolutionTechnique;
import sudoku.model.util.SolutionTechniqueCategory;
import sudoku.model.util.SudokuUtil;

public class SudokuSolver {
	private final SudokuStepFinder stepFinder = new SudokuStepFinder();
	private Sudoku2 sudoku;
	private List<SolutionStep> steps = new ArrayList<>();
	private final List<SolutionStep> tmpSteps = new ArrayList<>();
	private DifficultyLevel level = Options.getInstance().getDifficultyLevel(DifficultyType.EXTREME.ordinal());
	private DifficultyLevel maxLevel = Options.getInstance().getDifficultyLevel(DifficultyType.EXTREME.ordinal());
	private int score;
	private int[] anzSteps = new int[Options.getInstance().solverSteps.length];
	private final int[] anzStepsProgress = new int[Options.getInstance().solverSteps.length];
	private final long[] stepsNanoTime = new long[Options.getInstance().solverSteps.length];

	private static SudokuSolver instance;

	public static SudokuSolver getInstance() {
		if (instance == null) {
			instance = new SudokuSolver();
		}
		return instance;
	}

	public SudokuSolver() {
		// Nothing to do.
	}

	/**
	 * Solves the sudoku without any restrictions.
	 */
	public boolean solve() {
		return this.solve(Options.getInstance().getDifficultyLevel(DifficultyType.EXTREME.ordinal()), null, false, false);
	}

	/**
	 * Solves the sudoku without any restrictions.
	 */
	public boolean solve(final String sudoku) {
		return this.solve(Options.getInstance().getDifficultyLevel(DifficultyType.EXTREME.ordinal()), null, false, false);
	}

	/**
	 * Tries to solve the sudoku using only singles.<br>
	 * The internal variables are not changed
	 */
	public boolean solveSinglesOnly(final Sudoku2 newSudoku) {
		final Sudoku2 tmpSudoku = this.sudoku;
		final List<SolutionStep> oldList = this.steps;
		// sudoku = newSudoku;
		this.setSudoku(newSudoku);
		this.steps = this.tmpSteps;
		SudokuUtil.clearStepListWithNullify(this.steps);
		final boolean solved = this.solve(Options.getInstance().getDifficultyLevel(DifficultyType.EXTREME.ordinal()), null,
				false, true);
		this.steps = oldList;
		// sudoku = tmpSudoku;
		this.setSudoku(tmpSudoku);
		return solved;
	}

	/**
	 * Tries to solve the sudoku using only singles.<br>
	 * The internal variables are not changed
	 *
	 * @param newSudoku
	 * @param stepConfigs
	 * @return
	 */
	public boolean solveWithSteps(final Sudoku2 newSudoku, final StepConfig[] stepConfigs) {
		final Sudoku2 tmpSudoku = this.sudoku;
		final List<SolutionStep> oldList = this.steps;
		this.setSudoku(newSudoku);
		this.steps = this.tmpSteps;
		SudokuUtil.clearStepListWithNullify(this.steps);
		final boolean solved = this.solve(Options.getInstance().getDifficultyLevel(DifficultyType.EXTREME.ordinal()), null,
				false, false, stepConfigs, PuzzleType.STANDARD);
		this.steps = oldList;
		this.setSudoku(tmpSudoku);
		return solved;
	}

	/**
	 * Solves a sudoku using all available techniques.
	 */
	public boolean solve(final DifficultyLevel maxLevel, final Sudoku2 tmpSudoku, final boolean rejectTooLowScore) {
		return this.solve(maxLevel, tmpSudoku, rejectTooLowScore, false);
	}

	/**
	 * Solves a sudoku using all available techniques.
	 */
	public boolean solve(final DifficultyLevel maxLevel, final Sudoku2 tmpSudoku, final boolean rejectTooLowScore,
			final boolean singlesOnly) {
		return this.solve(maxLevel, tmpSudoku, rejectTooLowScore, singlesOnly, Options.getInstance().solverSteps,
				PuzzleType.STANDARD);
	}

	/**
	 * The real solver method. Can reject a possible solution if the
	 * {@link DifficultyLevel} doesnt match or if the score of the sudoku is too
	 * low. If a progress dialog is passed in, the counters in the dialog are
	 * updated.<br>
	 * If <code>stepConfig</code> is {@link Options#solverStepsProgress}, the
	 * method can be used to measure progress or find backdoors.<br>
	 * If the <code>gameMode</code> is any other than <code>STANDARD</code>, any
	 * puzzle is accepted, that contains at least one step with
	 * <code>StepConfig.isEnabledTraining()</code> true.
	 */
	public boolean solve(final DifficultyLevel maxLevel, final Sudoku2 tmpSudoku, final boolean rejectTooLowScore,
			final boolean singlesOnly, final StepConfig[] stepConfigs, final PuzzleType gameMode) {
		if (tmpSudoku != null) {
			this.setSudoku(tmpSudoku);
		}
		final int anzCells = this.sudoku.getUnsolvedCellsAnz();
		if ((81 - anzCells) < 10) {
			return false;
		}
		this.maxLevel = maxLevel;
		this.score = 0;
		this.level = Options.getInstance().getDifficultyLevel(DifficultyType.EASY.ordinal());

		SolutionStep step = null;

		for (int i = 0; i < this.anzSteps.length; i++) {
			this.anzSteps[i] = 0;
		}

		boolean acceptAnyway = false;
		do {

			step = this.getHint(singlesOnly, stepConfigs, acceptAnyway);
			if (step != null) {
				if (gameMode != PuzzleType.STANDARD && step.getType().getStepConfig().isEnabledTraining()) {
					acceptAnyway = true;
				}
				this.steps.add(step);
				this.getStepFinder().doStep(step);
				if (step.getType() == SolutionTechnique.GIVE_UP) {
					step = null;
				}
			}
		} while (step != null);
		while (this.score > this.level.getMaxScore()) {
			this.level = Options.getInstance().getDifficultyLevel(this.level.getOrdinal() + 1);
		}
		if (this.level.getOrdinal() > maxLevel.getOrdinal() && acceptAnyway == false) {
			return false;
		}
		if (rejectTooLowScore && this.level.getOrdinal() > DifficultyType.EASY.ordinal() && acceptAnyway == false) {
			if (this.score < Options.getInstance().getDifficultyLevel(this.level.getOrdinal() - 1).getMaxScore()) {
				return false;
			}
		}
		this.sudoku.setScore(this.score);
		if (this.sudoku.isSolved()) {
			this.sudoku.setLevel(this.level);
			return true;
		} else {
			this.sudoku.setLevel(Options.getInstance().getDifficultyLevel(DifficultyType.EXTREME.ordinal()));
			return false;
		}
	}

	/**
	 * Calculates the progress scores of all steps in <code>steps</code> (see
	 * {@link #getProgressScoreSingles(sudoku.model.Sudoku2, sudoku.model.SolutionStep) }).
	 */
	public void getProgressScore(final Sudoku2 tmpSudoku, final List<SolutionStep> stepsTocheck) {
		this.resetProgressStepCounters();
		final boolean oldCheckTemplates = Options.getInstance().isCheckTemplates();
		Options.getInstance().setCheckTemplates(false);
		final Sudoku2 workingSudoku = tmpSudoku.clone();
		for (int i = 0; i < stepsTocheck.size(); i++) {
			final SolutionStep step = stepsTocheck.get(i);
			workingSudoku.set(tmpSudoku);
			this.getProgressScore(workingSudoku, step);
		}
		Options.getInstance().setCheckTemplates(oldCheckTemplates);
	}

	/**
	 * Calculates the progress score for <code>step</code>. The progress score is
	 * defined as the number of singles the step unlocks in the sudoku, if
	 * {@link Options#solverStepsProgress} is used.
	 */
	public void getProgressScore(final Sudoku2 tmpSudoku, final SolutionStep orgStep) {
		final Sudoku2 save = this.sudoku;
		this.setSudoku(tmpSudoku);

		int progressScoreSingles = 0;
		int progressScoreSinglesOnly = 0;
		int progressScore = 0;
		boolean direct = true;
		// if step sets a cell it should count as single
		final SolutionTechnique type = orgStep.getType();
		if (type == SolutionTechnique.FORCING_CHAIN_VERITY || type == SolutionTechnique.FORCING_NET_VERITY
				|| type == SolutionTechnique.TEMPLATE_SET) {
			final int anz = orgStep.getIndices().size();
			progressScoreSingles += anz;
			progressScoreSinglesOnly += anz;
		}

		this.getStepFinder().doStep(orgStep);
		SolutionStep step = null;
		do {
			step = this.getHint(false, Options.getInstance().solverStepsProgress, false);
			if (step != null) {
				if (step.getType().isSingle()) {
					progressScoreSingles++;
					if (direct) {
						progressScoreSinglesOnly++;
					}
				} else {
					direct = false;
				}
				progressScore += step.getType().getStepConfig().getBaseScore();
				this.getStepFinder().doStep(step);
				if (step.getType() == SolutionTechnique.GIVE_UP) {
					step = null;
				}
			}
		} while (step != null);
		orgStep.setProgressScoreSingles(progressScoreSingles);
		orgStep.setProgressScoreSinglesOnly(progressScoreSinglesOnly);
		orgStep.setProgressScore(progressScore);

		this.setSudoku(save);
	}

	/**
	 * Get the next logical step for a given sudoku. If <code>singlesOnly</code>
	 * is set, only singles are tried.<br>
	 * The current state of the solver instance is saved and restored after the
	 * search is complete.
	 */
	public SolutionStep getHint(final Sudoku2 sudoku, final boolean singlesOnly) {
		final DifficultyLevel oldMaxLevel = this.maxLevel;
		final DifficultyLevel oldLevel = this.level;
		this.maxLevel = Options.getInstance().getDifficultyLevel(DifficultyType.EXTREME.ordinal());
		this.level = Options.getInstance().getDifficultyLevel(DifficultyType.EASY.ordinal());
		this.sudoku = new Sudoku2();
		this.sudoku.setSudoku(sudoku.getSudoku(ClipboardMode.CLUES_ONLY));
		this.setSudoku(this.sudoku);
		final SolutionStep step = this.getHint(singlesOnly);
		this.maxLevel = oldMaxLevel;
		this.level = oldLevel;
		return step;
	}

	/**
	 * Get the next logical step for a given sudoku. If <code>singlesOnly</code>
	 * is set, only singles are tried.<br>
	 * The current state of the solver instance is saved and restored after the
	 * search is complete.
	 */
	public SolutionStep getHint(final String sudokuString, final boolean singlesOnly) {
		final DifficultyLevel oldMaxLevel = this.maxLevel;
		final DifficultyLevel oldLevel = this.level;
		this.maxLevel = Options.getInstance().getDifficultyLevel(DifficultyType.EXTREME.ordinal());
		this.level = Options.getInstance().getDifficultyLevel(DifficultyType.EASY.ordinal());
		this.sudoku = new Sudoku2();
		this.sudoku.setSudoku(sudokuString);
		this.setSudoku(this.sudoku);
		final SolutionStep step = this.getHint(singlesOnly);
		this.maxLevel = oldMaxLevel;
		this.level = oldLevel;
		return step;
	}

	/**
	 * Get the next logical step for the internal sudoku. If
	 * <code>singlesOnly</code> is set, only singles are tried.
	 */
	private SolutionStep getHint(final boolean singlesOnly) {
		return this.getHint(singlesOnly, Options.getInstance().solverSteps, false);
	}

	/**
	 * Get the next logical step for the internal sudoku. If
	 * <code>singlesOnly</code> is set, only singles are tried.<br>
	 * Since the steps are passed as argument this method can be used to calculate
	 * the next step and to calculate the progress measure for a given sudoku
	 * state.<br>
	 * Any step is accepted, if the PuzzleType is not PuzzleType.STANDARD and one
	 * of the training techniques is already in the solution.
	 */
	private SolutionStep getHint(final boolean singlesOnly, final StepConfig[] solverSteps, final boolean acceptAnyway) {
		if (this.sudoku.isSolved()) {
			return null;
		}
		SolutionStep hint = null;

		for (int i = 0; i < solverSteps.length; i++) {
			if (solverSteps == Options.getInstance().solverStepsProgress) {
				if (!solverSteps[i].isEnabledProgress()) {
					continue;
				}
			} else {
				if (!solverSteps[i].isEnabled()) {
					continue;
				}
			}
			final SolutionTechnique type = solverSteps[i].getType();
			if (singlesOnly && (type != SolutionTechnique.HIDDEN_SINGLE && type != SolutionTechnique.NAKED_SINGLE
					&& type != SolutionTechnique.FULL_HOUSE)) {
				continue;
			}
			long nanos = System.nanoTime();
			hint = this.getStepFinder().getStep(type);
			nanos = System.nanoTime() - nanos;
			this.anzStepsProgress[i]++;
			this.stepsNanoTime[i] += nanos;
			if (hint != null) {
				this.anzSteps[i]++;
				this.score += solverSteps[i].getBaseScore();
				if (Options.getInstance().getDifficultyLevels()[solverSteps[i].getLevel()].getOrdinal() > this.level
						.getOrdinal()) {
					this.level = Options.getInstance().getDifficultyLevels()[solverSteps[i].getLevel()];
				}
				if (!acceptAnyway) {
					if (this.level.getOrdinal() > this.maxLevel.getOrdinal() || this.score >= this.maxLevel.getMaxScore()) {
						return null;
					}
				}
				return hint;
			}
		}
		return null;
	}

	public void doStep(final Sudoku2 sudoku, final SolutionStep step) {
		// we mustnt call setSudoku() here or all internal
		// data structures get changed -> just set the field itself
		final Sudoku2 oldSudoku = this.getSudoku();
		this.getStepFinder().setSudoku(sudoku);
		this.getStepFinder().doStep(step);
		this.getStepFinder().setSudoku(oldSudoku);
	}

	public Sudoku2 getSudoku() {
		return this.sudoku;
	}

	public void setSudoku(final Sudoku2 sudoku, final List<SolutionStep> partSteps) {
		// not really sure whether the list may be cleared safely here...
		this.steps = new ArrayList<>();
		for (int i = 0; i < partSteps.size(); i++) {
			this.steps.add(partSteps.get(i));
		}
		this.sudoku = sudoku;
		this.getStepFinder().setSudoku(sudoku);
	}

	public void setSudoku(final Sudoku2 sudoku) {
		SudokuUtil.clearStepList(this.steps);
		for (int i = 0; i < this.anzSteps.length; i++) {
			this.anzSteps[i] = 0;
		}
		this.sudoku = sudoku;
		this.getStepFinder().setSudoku(sudoku);
	}

	public List<SolutionStep> getSteps() {
		return this.steps;
	}

	public int getAnzUsedSteps() {
		int anz = 0;
		for (int i = 0; i < this.anzSteps.length; i++) {
			if (this.anzSteps[i] > 0) {
				anz++;
			}
		}
		return anz;
	}

	public int[] getAnzSteps() {
		return this.anzSteps;
	}

	public int getScore() {
		return this.score;
	}

	public String getLevelString() {
		return StepConfig.getLevelName(this.level);
	}

	public DifficultyLevel getLevel() {
		return this.level;
	}

	public SolutionTechniqueCategory getCategory(final SolutionTechnique type) {
		for (final StepConfig configStep : Options.getInstance().solverSteps) {
			if (type == configStep.getType()) {
				return configStep.getCategory();
			}
		}
		return null;
	}

	public String getCategoryName(final SolutionTechnique type) {
		final SolutionTechniqueCategory cat = this.getCategory(type);
		if (cat == null) {
			return null;
		}
		return cat.getCategoryName();
	}

	public void setSteps(final List<SolutionStep> steps) {
		this.steps = steps;
	}

	public void setLevel(final DifficultyLevel level) {
		this.level = level;
	}

	public DifficultyLevel getMaxLevel() {
		return this.maxLevel;
	}

	public void setMaxLevel(final DifficultyLevel maxLevel) {
		this.maxLevel = maxLevel;
	}

	public void setScore(final int score) {
		this.score = score;
	}

	public void setAnzSteps(final int[] anzSteps) {
		this.anzSteps = anzSteps;
	}

	private void resetProgressStepCounters() {
		for (int i = 0; i < this.anzStepsProgress.length; i++) {
			this.anzStepsProgress[i] = 0;
			this.stepsNanoTime[i] = 0;
		}
	}

	public long[] getStepsNanoTime() {
		return this.stepsNanoTime;
	}

	public SudokuStepFinder getStepFinder() {
		return this.stepFinder;
	}
}
