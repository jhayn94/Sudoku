/*
 * Copyright (C) 2008-12  Bernhard Hobiger
 *
 * This file is part of HoDoKu.
 *
 * HoDoKu is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * HoDoKu is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with HoDoKu. If not, see <http://www.gnu.org/licenses/>.
 */
package sudoku.model;

import java.awt.Color;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Date;
import java.util.List;

import sudoku.factories.PatternFactory;
import sudoku.model.util.ClipboardMode;
import sudoku.model.util.DifficultyLevel;
import sudoku.model.util.DifficultyType;
import sudoku.model.util.PuzzleType;
import sudoku.model.util.SolutionTechnique;
import sudoku.model.util.SolutionTechniqueCategory;

public final class Options {

	private static final String EXTREME = "Eextreme";

	private static final String UNFAIR = "Unfair";

	private static final String HARD = "Hard";

	private static final String EASY = "Easy";

	private static final String INCOMPLETE = "Incomplete";

	private static final String MEDIUM = "Medium";

	private static final ProgressComparator progressComparator = new ProgressComparator();

	public static final DifficultyLevel[] DEFAULT_DIFFICULTY_LEVELS = {
			new DifficultyLevel(DifficultyType.INCOMPLETE, 0, INCOMPLETE, Color.BLACK, Color.WHITE),
			new DifficultyLevel(DifficultyType.EASY, 800, EASY, Color.WHITE, Color.BLACK),
			new DifficultyLevel(DifficultyType.MEDIUM, 1000, MEDIUM, new Color(100, 255, 100), Color.BLACK),
			new DifficultyLevel(DifficultyType.HARD, 1600, HARD, new Color(255, 255, 100), Color.BLACK),
			new DifficultyLevel(DifficultyType.UNFAIR, 1800, UNFAIR, new Color(255, 150, 80), Color.BLACK),
			new DifficultyLevel(DifficultyType.EXTREME, Integer.MAX_VALUE, EXTREME, new Color(255, 100, 100), Color.BLACK) };

	private DifficultyLevel[] difficultyLevels = null;

	public static final StepConfig[] DEFAULT_SOLVER_STEPS = {
			new StepConfig(Integer.MAX_VALUE - 1, SolutionTechnique.INCOMPLETE, DifficultyType.INCOMPLETE.ordinal(),
					SolutionTechniqueCategory.LAST_RESORT, 0, 0, false, false, Integer.MAX_VALUE - 1, false, false),
			new StepConfig(Integer.MAX_VALUE, SolutionTechnique.GIVE_UP, DifficultyType.EXTREME.ordinal(),
					SolutionTechniqueCategory.LAST_RESORT, 20000, 0, true, false, Integer.MAX_VALUE, true, false),
			new StepConfig(100, SolutionTechnique.FULL_HOUSE, DifficultyType.EASY.ordinal(),
					SolutionTechniqueCategory.SINGLES, 4, 0, true, true, 100, true, false),
			new StepConfig(200, SolutionTechnique.NAKED_SINGLE, DifficultyType.EASY.ordinal(),
					SolutionTechniqueCategory.SINGLES, 4, 0, true, true, 200, true, false),
			new StepConfig(300, SolutionTechnique.HIDDEN_SINGLE, DifficultyType.EASY.ordinal(),
					SolutionTechniqueCategory.SINGLES, 14, 0, true, true, 300, true, false),
			new StepConfig(1000, SolutionTechnique.LOCKED_PAIR, DifficultyType.MEDIUM.ordinal(),
					SolutionTechniqueCategory.INTERSECTIONS, 40, 0, true, true, 1000, true, false),
			new StepConfig(1100, SolutionTechnique.LOCKED_TRIPLE, DifficultyType.MEDIUM.ordinal(),
					SolutionTechniqueCategory.INTERSECTIONS, 60, 0, true, true, 1100, true, false),
			new StepConfig(1200, SolutionTechnique.LOCKED_CANDIDATES_1, DifficultyType.MEDIUM.ordinal(),
					SolutionTechniqueCategory.INTERSECTIONS, 50, 0, true, true, 1200, true, false),
			new StepConfig(1300, SolutionTechnique.NAKED_PAIR, DifficultyType.MEDIUM.ordinal(),
					SolutionTechniqueCategory.SUBSETS, 60, 0, true, true, 1300, true, false),
			new StepConfig(1400, SolutionTechnique.NAKED_TRIPLE, DifficultyType.MEDIUM.ordinal(),
					SolutionTechniqueCategory.SUBSETS, 80, 0, true, true, 1400, true, false),
			new StepConfig(1500, SolutionTechnique.HIDDEN_PAIR, DifficultyType.MEDIUM.ordinal(),
					SolutionTechniqueCategory.SUBSETS, 70, 0, true, true, 1500, true, false),
			new StepConfig(1600, SolutionTechnique.HIDDEN_TRIPLE, DifficultyType.MEDIUM.ordinal(),
					SolutionTechniqueCategory.SUBSETS, 100, 0, true, true, 1600, true, false),
			new StepConfig(2000, SolutionTechnique.NAKED_QUADRUPLE, DifficultyType.HARD.ordinal(),
					SolutionTechniqueCategory.SUBSETS, 120, 0, true, true, 2000, true, false),
			new StepConfig(2100, SolutionTechnique.HIDDEN_QUADRUPLE, DifficultyType.HARD.ordinal(),
					SolutionTechniqueCategory.SUBSETS, 150, 0, true, true, 2100, true, false),
			new StepConfig(2200, SolutionTechnique.X_WING, DifficultyType.HARD.ordinal(),
					SolutionTechniqueCategory.BASIC_FISH, 140, 0, true, false, 2200, false, false),
			new StepConfig(2300, SolutionTechnique.SWORDFISH, DifficultyType.HARD.ordinal(),
					SolutionTechniqueCategory.BASIC_FISH, 150, 0, true, false, 2300, false, false),
			new StepConfig(2400, SolutionTechnique.JELLYFISH, DifficultyType.HARD.ordinal(),
					SolutionTechniqueCategory.BASIC_FISH, 160, 0, true, false, 2400, false, false),
			new StepConfig(2500, SolutionTechnique.SQUIRMBAG, DifficultyType.UNFAIR.ordinal(),
					SolutionTechniqueCategory.BASIC_FISH, 470, 0, false, false, 2500, false, false),
			new StepConfig(2600, SolutionTechnique.WHALE, DifficultyType.UNFAIR.ordinal(),
					SolutionTechniqueCategory.BASIC_FISH, 470, 0, false, false, 2600, false, false),
			new StepConfig(2700, SolutionTechnique.LEVIATHAN, DifficultyType.UNFAIR.ordinal(),
					SolutionTechniqueCategory.BASIC_FISH, 470, 0, false, false, 2700, false, false),
			new StepConfig(2800, SolutionTechnique.REMOTE_PAIR, DifficultyType.HARD.ordinal(),
					SolutionTechniqueCategory.CHAINS_AND_LOOPS, 110, 0, true, true, 2800, false, false),
			new StepConfig(2900, SolutionTechnique.BUG_PLUS_1, DifficultyType.HARD.ordinal(),
					SolutionTechniqueCategory.UNIQUENESS, 100, 0, true, true, 2900, false, false),
			new StepConfig(3000, SolutionTechnique.SKYSCRAPER, DifficultyType.HARD.ordinal(),
					SolutionTechniqueCategory.SINGLE_DIGIT_PATTERNS, 130, 0, true, true, 3000, false, false),
			new StepConfig(3200, SolutionTechnique.W_WING, DifficultyType.HARD.ordinal(), SolutionTechniqueCategory.WINGS,
					150, 0, true, true, 3200, false, false),
			new StepConfig(3100, SolutionTechnique.TWO_STRING_KITE, DifficultyType.HARD.ordinal(),
					SolutionTechniqueCategory.SINGLE_DIGIT_PATTERNS, 150, 0, true, true, 3100, false, false),
			new StepConfig(3300, SolutionTechnique.XY_WING, DifficultyType.HARD.ordinal(), SolutionTechniqueCategory.WINGS,
					160, 0, true, true, 3300, false, false),
			new StepConfig(3400, SolutionTechnique.XYZ_WING, DifficultyType.HARD.ordinal(), SolutionTechniqueCategory.WINGS,
					180, 0, true, true, 3400, false, false),
			new StepConfig(3500, SolutionTechnique.UNIQUENESS_1, DifficultyType.HARD.ordinal(),
					SolutionTechniqueCategory.UNIQUENESS, 100, 0, true, true, 3500, false, false),
			new StepConfig(3600, SolutionTechnique.UNIQUENESS_2, DifficultyType.HARD.ordinal(),
					SolutionTechniqueCategory.UNIQUENESS, 100, 0, true, true, 3600, false, false),
			new StepConfig(3700, SolutionTechnique.UNIQUENESS_3, DifficultyType.HARD.ordinal(),
					SolutionTechniqueCategory.UNIQUENESS, 100, 0, true, true, 3700, false, false),
			new StepConfig(3800, SolutionTechnique.UNIQUENESS_4, DifficultyType.HARD.ordinal(),
					SolutionTechniqueCategory.UNIQUENESS, 100, 0, true, true, 3800, false, false),
			new StepConfig(3900, SolutionTechnique.UNIQUENESS_5, DifficultyType.HARD.ordinal(),
					SolutionTechniqueCategory.UNIQUENESS, 100, 0, true, true, 3900, false, false),
			new StepConfig(4000, SolutionTechnique.UNIQUENESS_6, DifficultyType.HARD.ordinal(),
					SolutionTechniqueCategory.UNIQUENESS, 100, 0, true, true, 4000, false, false),
			new StepConfig(4100, SolutionTechnique.FINNED_X_WING, DifficultyType.HARD.ordinal(),
					SolutionTechniqueCategory.FINNED_BASIC_FISH, 130, 0, true, false, 4100, false, false),
			new StepConfig(4200, SolutionTechnique.SASHIMI_X_WING, DifficultyType.HARD.ordinal(),
					SolutionTechniqueCategory.FINNED_BASIC_FISH, 150, 0, true, false, 4200, false, false),
			new StepConfig(4300, SolutionTechnique.FINNED_SWORDFISH, DifficultyType.UNFAIR.ordinal(),
					SolutionTechniqueCategory.FINNED_BASIC_FISH, 200, 0, true, false, 4300, false, false),
			new StepConfig(4400, SolutionTechnique.SASHIMI_SWORDFISH, DifficultyType.UNFAIR.ordinal(),
					SolutionTechniqueCategory.FINNED_BASIC_FISH, 240, 0, true, false, 4400, false, false),
			new StepConfig(4500, SolutionTechnique.FINNED_JELLYFISH, DifficultyType.UNFAIR.ordinal(),
					SolutionTechniqueCategory.FINNED_BASIC_FISH, 250, 0, true, false, 4500, false, false),
			new StepConfig(4600, SolutionTechnique.SASHIMI_JELLYFISH, DifficultyType.UNFAIR.ordinal(),
					SolutionTechniqueCategory.FINNED_BASIC_FISH, 260, 0, true, false, 4600, false, false),
			new StepConfig(4700, SolutionTechnique.FINNED_SQUIRMBAG, DifficultyType.UNFAIR.ordinal(),
					SolutionTechniqueCategory.FINNED_BASIC_FISH, 470, 0, false, false, 4700, false, false),
			new StepConfig(4800, SolutionTechnique.SASHIMI_SQUIRMBAG, DifficultyType.UNFAIR.ordinal(),
					SolutionTechniqueCategory.FINNED_BASIC_FISH, 470, 0, false, false, 4800, false, false),
			new StepConfig(4900, SolutionTechnique.FINNED_WHALE, DifficultyType.UNFAIR.ordinal(),
					SolutionTechniqueCategory.FINNED_BASIC_FISH, 470, 0, false, false, 4900, false, false),
			new StepConfig(5000, SolutionTechnique.SASHIMI_WHALE, DifficultyType.UNFAIR.ordinal(),
					SolutionTechniqueCategory.FINNED_BASIC_FISH, 470, 0, false, false, 5000, false, false),
			new StepConfig(5100, SolutionTechnique.FINNED_LEVIATHAN, DifficultyType.UNFAIR.ordinal(),
					SolutionTechniqueCategory.FINNED_BASIC_FISH, 470, 0, false, false, 5100, false, false),
			new StepConfig(5200, SolutionTechnique.SASHIMI_LEVIATHAN, DifficultyType.UNFAIR.ordinal(),
					SolutionTechniqueCategory.FINNED_BASIC_FISH, 470, 0, false, false, 5200, false, false),
			new StepConfig(5300, SolutionTechnique.SUE_DE_COQ, DifficultyType.UNFAIR.ordinal(),
					SolutionTechniqueCategory.MISCELLANEOUS, 250, 0, true, true, 5300, false, false),
			new StepConfig(5400, SolutionTechnique.X_CHAIN, DifficultyType.UNFAIR.ordinal(),
					SolutionTechniqueCategory.CHAINS_AND_LOOPS, 260, 0, true, true, 5400, false, false),
			new StepConfig(5500, SolutionTechnique.XY_CHAIN, DifficultyType.UNFAIR.ordinal(),
					SolutionTechniqueCategory.CHAINS_AND_LOOPS, 260, 0, true, true, 5500, false, false),
			new StepConfig(5600, SolutionTechnique.NICE_LOOP, DifficultyType.UNFAIR.ordinal(),
					SolutionTechniqueCategory.CHAINS_AND_LOOPS, 280, 0, true, true, 5600, false, false),
			new StepConfig(5700, SolutionTechnique.ALS_XZ, DifficultyType.UNFAIR.ordinal(),
					SolutionTechniqueCategory.ALMOST_LOCKED_SETS, 300, 0, true, true, 5700, false, false),
			new StepConfig(5800, SolutionTechnique.ALS_XY_WING, DifficultyType.UNFAIR.ordinal(),
					SolutionTechniqueCategory.ALMOST_LOCKED_SETS, 320, 0, true, true, 5800, false, false),
			new StepConfig(5900, SolutionTechnique.ALS_XY_CHAIN, DifficultyType.UNFAIR.ordinal(),
					SolutionTechniqueCategory.ALMOST_LOCKED_SETS, 340, 0, true, true, 5900, false, false),
			new StepConfig(6000, SolutionTechnique.DEATH_BLOSSOM, DifficultyType.UNFAIR.ordinal(),
					SolutionTechniqueCategory.ALMOST_LOCKED_SETS, 360, 0, false, true, 6000, false, false),
			new StepConfig(6100, SolutionTechnique.FRANKEN_X_WING, DifficultyType.UNFAIR.ordinal(),
					SolutionTechniqueCategory.FRANKEN_FISH, 300, 0, true, false, 6100, false, false),
			new StepConfig(6200, SolutionTechnique.FRANKEN_SWORDFISH, DifficultyType.UNFAIR.ordinal(),
					SolutionTechniqueCategory.FRANKEN_FISH, 350, 0, true, false, 6200, false, false),
			new StepConfig(6300, SolutionTechnique.FRANKEN_JELLYFISH, DifficultyType.UNFAIR.ordinal(),
					SolutionTechniqueCategory.FRANKEN_FISH, 370, 0, false, false, 6300, false, false),
			new StepConfig(6400, SolutionTechnique.FRANKEN_SQUIRMBAG, DifficultyType.EXTREME.ordinal(),
					SolutionTechniqueCategory.FRANKEN_FISH, 470, 0, false, false, 6400, false, false),
			new StepConfig(6500, SolutionTechnique.FRANKEN_WHALE, DifficultyType.EXTREME.ordinal(),
					SolutionTechniqueCategory.FRANKEN_FISH, 470, 0, false, false, 6500, false, false),
			new StepConfig(6600, SolutionTechnique.FRANKEN_LEVIATHAN, DifficultyType.EXTREME.ordinal(),
					SolutionTechniqueCategory.FRANKEN_FISH, 470, 0, false, false, 6600, false, false),
			new StepConfig(6700, SolutionTechnique.FINNED_FRANKEN_X_WING, DifficultyType.UNFAIR.ordinal(),
					SolutionTechniqueCategory.FINNED_FRANKEN_FISH, 390, 0, true, false, 6700, false, false),
			new StepConfig(6800, SolutionTechnique.FINNED_FRANKEN_SWORDFISH, DifficultyType.UNFAIR.ordinal(),
					SolutionTechniqueCategory.FINNED_FRANKEN_FISH, 410, 0, true, false, 6800, false, false),
			new StepConfig(6900, SolutionTechnique.FINNED_FRANKEN_JELLYFISH, DifficultyType.UNFAIR.ordinal(),
					SolutionTechniqueCategory.FINNED_FRANKEN_FISH, 430, 0, false, false, 6900, false, false),
			new StepConfig(7000, SolutionTechnique.FINNED_FRANKEN_SQUIRMBAG, DifficultyType.EXTREME.ordinal(),
					SolutionTechniqueCategory.FINNED_FRANKEN_FISH, 470, 0, false, false, 7000, false, false),
			new StepConfig(7100, SolutionTechnique.FINNED_FRANKEN_WHALE, DifficultyType.EXTREME.ordinal(),
					SolutionTechniqueCategory.FINNED_FRANKEN_FISH, 470, 0, false, false, 7100, false, false),
			new StepConfig(7200, SolutionTechnique.FINNED_FRANKEN_LEVIATHAN, DifficultyType.EXTREME.ordinal(),
					SolutionTechniqueCategory.FINNED_FRANKEN_FISH, 470, 0, false, false, 7200, false, false),
			new StepConfig(7300, SolutionTechnique.MUTANT_X_WING, DifficultyType.EXTREME.ordinal(),
					SolutionTechniqueCategory.MUTANT_FISH, 450, 0, false, false, 7300, false, false),
			new StepConfig(7400, SolutionTechnique.MUTANT_SWORDFISH, DifficultyType.EXTREME.ordinal(),
					SolutionTechniqueCategory.MUTANT_FISH, 450, 0, false, false, 7400, false, false),
			new StepConfig(7500, SolutionTechnique.MUTANT_JELLYFISH, DifficultyType.EXTREME.ordinal(),
					SolutionTechniqueCategory.MUTANT_FISH, 450, 0, false, false, 7500, false, false),
			new StepConfig(7600, SolutionTechnique.MUTANT_SQUIRMBAG, DifficultyType.EXTREME.ordinal(),
					SolutionTechniqueCategory.MUTANT_FISH, 470, 0, false, false, 7600, false, false),
			new StepConfig(7700, SolutionTechnique.MUTANT_WHALE, DifficultyType.EXTREME.ordinal(),
					SolutionTechniqueCategory.MUTANT_FISH, 470, 0, false, false, 7700, false, false),
			new StepConfig(7800, SolutionTechnique.MUTANT_LEVIATHAN, DifficultyType.EXTREME.ordinal(),
					SolutionTechniqueCategory.MUTANT_FISH, 470, 0, false, false, 7800, false, false),
			new StepConfig(7900, SolutionTechnique.FINNED_MUTANT_X_WING, DifficultyType.EXTREME.ordinal(),
					SolutionTechniqueCategory.FINNED_MUTANT_FISH, 470, 0, false, false, 7900, false, false),
			new StepConfig(8000, SolutionTechnique.FINNED_MUTANT_SWORDFISH, DifficultyType.EXTREME.ordinal(),
					SolutionTechniqueCategory.FINNED_MUTANT_FISH, 470, 0, false, false, 8000, false, false),
			new StepConfig(8100, SolutionTechnique.FINNED_MUTANT_JELLYFISH, DifficultyType.EXTREME.ordinal(),
					SolutionTechniqueCategory.FINNED_MUTANT_FISH, 470, 0, false, false, 8100, false, false),
			new StepConfig(8200, SolutionTechnique.FINNED_MUTANT_SQUIRMBAG, DifficultyType.EXTREME.ordinal(),
					SolutionTechniqueCategory.FINNED_MUTANT_FISH, 470, 0, false, false, 8200, false, false),
			new StepConfig(8300, SolutionTechnique.FINNED_MUTANT_WHALE, DifficultyType.EXTREME.ordinal(),
					SolutionTechniqueCategory.FINNED_MUTANT_FISH, 470, 0, false, false, 8300, false, false),
			new StepConfig(8400, SolutionTechnique.FINNED_MUTANT_LEVIATHAN, DifficultyType.EXTREME.ordinal(),
					SolutionTechniqueCategory.FINNED_MUTANT_FISH, 470, 0, false, false, 8400, false, false),
			new StepConfig(8700, SolutionTechnique.TEMPLATE_SET, DifficultyType.EXTREME.ordinal(),
					SolutionTechniqueCategory.LAST_RESORT, 10000, 0, false, false, 8700, false, false),
			new StepConfig(8800, SolutionTechnique.TEMPLATE_DEL, DifficultyType.EXTREME.ordinal(),
					SolutionTechniqueCategory.LAST_RESORT, 10000, 0, false, false, 8800, false, false),
			new StepConfig(8500, SolutionTechnique.FORCING_CHAIN, DifficultyType.EXTREME.ordinal(),
					SolutionTechniqueCategory.LAST_RESORT, 500, 0, true, false, 8500, false, false),
			new StepConfig(8600, SolutionTechnique.FORCING_NET, DifficultyType.EXTREME.ordinal(),
					SolutionTechniqueCategory.LAST_RESORT, 700, 0, true, false, 8600, false, false),
			new StepConfig(8900, SolutionTechnique.BRUTE_FORCE, DifficultyType.EXTREME.ordinal(),
					SolutionTechniqueCategory.LAST_RESORT, 10000, 0, true, false, 8900, false, false),
			new StepConfig(5650, SolutionTechnique.GROUPED_NICE_LOOP, DifficultyType.UNFAIR.ordinal(),
					SolutionTechniqueCategory.CHAINS_AND_LOOPS, 300, 0, true, true, 5650, false, false),
			new StepConfig(3170, SolutionTechnique.EMPTY_RECTANGLE, DifficultyType.HARD.ordinal(),
					SolutionTechniqueCategory.SINGLE_DIGIT_PATTERNS, 120, 0, true, true, 3170, false, false),
			new StepConfig(4010, SolutionTechnique.HIDDEN_RECTANGLE, DifficultyType.HARD.ordinal(),
					SolutionTechniqueCategory.UNIQUENESS, 100, 0, true, true, 4010, false, false),
			new StepConfig(4020, SolutionTechnique.AVOIDABLE_RECTANGLE_1, DifficultyType.HARD.ordinal(),
					SolutionTechniqueCategory.UNIQUENESS, 100, 0, true, true, 4020, false, false),
			new StepConfig(4030, SolutionTechnique.AVOIDABLE_RECTANGLE_2, DifficultyType.HARD.ordinal(),
					SolutionTechniqueCategory.UNIQUENESS, 100, 0, true, true, 4030, false, false),
			new StepConfig(5330, SolutionTechnique.SIMPLE_COLORS, DifficultyType.HARD.ordinal(),
					SolutionTechniqueCategory.COLORING, 150, 0, true, true, 5330, false, false),
			new StepConfig(5360, SolutionTechnique.MULTI_COLORS, DifficultyType.HARD.ordinal(),
					SolutionTechniqueCategory.COLORING, 200, 0, true, true, 5360, false, false),
			new StepConfig(8450, SolutionTechnique.KRAKEN_FISH, DifficultyType.EXTREME.ordinal(),
					SolutionTechniqueCategory.LAST_RESORT, 500, 0, false, false, 8450, false, false),
			new StepConfig(3120, SolutionTechnique.TURBOT_FISH, DifficultyType.HARD.ordinal(),
					SolutionTechniqueCategory.SINGLE_DIGIT_PATTERNS, 120, 0, true, true, 3120, false, false),
			new StepConfig(1210, SolutionTechnique.LOCKED_CANDIDATES_2, DifficultyType.MEDIUM.ordinal(),
					SolutionTechniqueCategory.INTERSECTIONS, 50, 0, true, true, 1210, true, false) };
	private StepConfig[] orgSolverSteps = null;
	public StepConfig[] solverSteps = null;
	public StepConfig[] solverStepsProgress = null;

	// ChainSolver
	public static final int RESTRICT_CHAIN_LENGTH = 20;
	public static final int RESTRICT_NICE_LOOP_LENGTH = 10;
	public static final boolean RESTRICT_CHAIN_SIZE = true;
	private final int restrictChainLength = RESTRICT_CHAIN_LENGTH;
	private final int restrictNiceLoopLength = RESTRICT_NICE_LOOP_LENGTH;
	private final boolean restrictChainSize = RESTRICT_CHAIN_SIZE;
	// TablingSolver
	public static final int MAX_TABLE_ENTRY_LENGTH = 1000;
	public static final int ANZ_TABLE_LOOK_AHEAD = 4;
	public static final boolean ONLY_ONE_CHAIN_PER_STEP = true;
	public static final boolean ALLOW_ALS_IN_TABLING_CHAINS = false;
	public static final boolean ALL_STEPS_ALLOW_ALS_IN_TABLING_CHAINS = true;
	private final int maxTableEntryLength = MAX_TABLE_ENTRY_LENGTH;
	private final int anzTableLookAhead = ANZ_TABLE_LOOK_AHEAD;
	private final boolean onlyOneChainPerStep = ONLY_ONE_CHAIN_PER_STEP;
	private final boolean allowAlsInTablingChains = ALLOW_ALS_IN_TABLING_CHAINS;

	// AlsSolver
	public static final boolean ONLY_ONE_ALS_PER_STEP = true;
	public static final boolean ALLOW_ALS_OVERLAP = false;
	public static final boolean ALL_STEPS_ONLY_ONE_ALS_PER_STEP = true;
	public static final boolean ALL_STEPS_ALLOW_ALS_OVERLAP = true;
	private final boolean onlyOneAlsPerStep = ONLY_ONE_ALS_PER_STEP;
	private final boolean allowAlsOverlap = ALLOW_ALS_OVERLAP;

	// FishSolver
	public static final int MAX_FINS = 5;
	public static final int MAX_ENDO_FINS = 2;
	public static final boolean CHECK_TEMPLATES = true;

	public static final int KRAKEN_MAX_FISH_TYPE = 1;
	public static final int KRAKEN_MAX_FISH_SIZE = 4;
	public static final int MAX_KRAKEN_FINS = 2;
	public static final int MAX_KRAKEN_ENDO_FINS = 0;
	public static final boolean ONLY_ONE_FISH_PER_STEP = true;
	public static final int FISH_DISPLAY_MODE = 0;
	private int maxFins = MAX_FINS;
	private int maxEndoFins = MAX_ENDO_FINS;
	private boolean checkTemplates = CHECK_TEMPLATES;
	private final int krakenMaxFishType = KRAKEN_MAX_FISH_TYPE;
	private final int krakenMaxFishSize = KRAKEN_MAX_FISH_SIZE;
	private final int maxKrakenFins = MAX_KRAKEN_FINS;
	private final int maxKrakenEndoFins = MAX_KRAKEN_ENDO_FINS;
	private final boolean onlyOneFishPerStep = ONLY_ONE_FISH_PER_STEP;
	private final int fishDisplayMode = FISH_DISPLAY_MODE;
	// Search all steps
	public static final boolean ALL_STEPS_SEARCH_FISH = true;
	public static final int ALL_STEPS_MAX_FISH_TYPE = 1;
	public static final int ALL_STEPS_MIN_FISH_SIZE = 2;
	public static final int ALL_STEPS_MAX_FISH_SIZE = 4;
	public static final int ALL_STEPS_MAX_FINS = 5;
	public static final int ALL_STEPS_MAX_ENDO_FINS = 2;

	public static final boolean ALL_STEPS_CHECK_TEMPLATES = true;
	public static final int ALL_STEPS_MAX_KRAKEN_FISH_TYPE = 1;

	public static final int ALL_STEPS_MIN_KRAKEN_FISH_SIZE = 2;
	public static final int ALL_STEPS_MAX_KRAKEN_FISH_SIZE = 4;
	public static final int ALL_STEPS_MAX_KRAKEN_FINS = 2;
	public static final int ALL_STEPS_MAX_KRAKEN_ENDO_FINS = 0;
	public static final String ALL_STEPS_FISH_CANDIDATES = "111111111";
	public static final String ALL_STEPS_KRAKEN_FISH_CANDIDATES = "111111111";
	public static final int ALL_STEPS_SORT_MODE = 4;
	public static final int ALL_STEPS_ALS_CHAIN_LENGTH = 6;
	public static final boolean ALL_STEPS_ALS_CHAIN_FORWARD_ONLY = true;
	private final int allStepsAlsChainLength = ALL_STEPS_ALS_CHAIN_LENGTH;
	private final boolean allStepsAlsChainForwardOnly = ALL_STEPS_ALS_CHAIN_FORWARD_ONLY;
	// SudokuPanel
	// Coloring Solver
	public static final Color[] COLORING_COLORS = { new Color(255, 192, 89), // 'a'
																																						// -
																																						// first
																																						// color
																																						// of
																																						// first
																																						// color
																																						// pair
			new Color(247, 222, 143), // 'A' - second color of first color pair
			new Color(177, 165, 243), // 'b' - first color of second color pair
			new Color(220, 212, 252), // 'B' - second color of second color pair
			new Color(247, 165, 167), // 'c' - first color of third color pair
			new Color(255, 210, 210), // 'C' - second color of third color pair
			new Color(134, 232, 208), // 'd' - first color of fourth color pair
			new Color(206, 251, 237), // 'D' - second color of fourth color pair
			new Color(134, 242, 128), // 'e' - first color of fifth color pair
			new Color(215, 255, 215) // 'E' - second color of fifth color pair
			// new Color(140, 198, 255), // 'a' - first color of first color pair
			// new Color(205, 171, 255), // 'A' - second color of first color pair
			// new Color(255, 164, 119), // 'b' - first color of second color pair
			// new Color(190, 124, 124), // 'B' - second color of second color pair
			// new Color(130, 130, 130), // 'c' - first color of third color pair
			// new Color(130, 30, 130), // 'C' - second color of third color pair
			// new Color(140, 140, 140), // 'd' - first color of fourth color pair
			// new Color(140, 40, 140), // 'D' - second color of fourth color pair
			// new Color(168, 255, 168), // 'e' - first color of fifth color pair
			// new Color(215, 255, 215) // 'E' - second color of fifth color pair
	};
	public static final boolean COLOR_VALUES = true;
	private Color[] coloringColors = null;
	// Single Digit Pattern Solver
	public static final boolean ALLOW_ERS_WITH_ONLY_TWO_CANDIDATES = false;
	private final boolean allowErsWithOnlyTwoCandidates = ALLOW_ERS_WITH_ONLY_TWO_CANDIDATES;
	public static final boolean ALLOW_DUALS_AND_SIAMESE = false;

	private final boolean allowDualsAndSiamese = ALLOW_DUALS_AND_SIAMESE;
	// Uniqueness Solver
	public static final boolean ALLOW_UNIQUENESS_MISSING_CANDIDATES = true;
	private final boolean allowUniquenessMissingCandidates = ALLOW_UNIQUENESS_MISSING_CANDIDATES;
	public static final boolean SHOW_CANDIDATES = true;
	public static final boolean SHOW_WRONG_VALUES = true;
	public static final boolean SHOW_DEVIATIONS = true;
	public static final boolean SHOW_COLORKU = false;
	public static final boolean INVALID_CELLS = false;
	public static final boolean COLOR_CELLS = true;
	public static final boolean SAVE_WINDOW_LAYOUT = true;
	public static final boolean USE_OR_INSTEAD_OF_AND_FOR_FILTER = false;
	public static final boolean INITIAL_SHOW_HINT_PANEL = true;
	public static final boolean INITIAL_SHOW_TOOLBAR = true;
	public static final int ACT_LEVEL = DEFAULT_DIFFICULTY_LEVELS[1].getOrdinal();
	public static final boolean SHOW_SUDOKU_SOLVED = false;
	public static final boolean EDIT_MODE_AUTO_ADVANCE = false;
	private final boolean useOrInsteadOfAndForFilter = USE_OR_INSTEAD_OF_AND_FOR_FILTER;

	public static final boolean USE_ZERO_INSTEAD_OF_DOT = false;
	public static final Color GRID_COLOR = Color.BLACK;
	public static final Color INNER_GRID_COLOR = Color.LIGHT_GRAY;
	public static final Color WRONG_VALUE_COLOR = Color.RED;
	public static final Color DEVIATION_COLOR = new Color(255, 185, 185);
	public static final Color CELL_FIXED_VALUE_COLOR = Color.BLACK;
	public static final Color CELL_VALUE_COLOR = Color.BLUE;
	public static final Color CANDIDATE_COLOR = new Color(100, 100, 100);
	public static final Color DEFAULT_CELL_COLOR = Color.WHITE;
	public static final Color ALTERNATE_CELL_COLOR = Color.WHITE;
	public static final Color AKT_CELL_COLOR = new Color(255, 255, 150);
	public static final Color INVALID_CELL_COLOR = new Color(255, 185, 185);
	public static final Color POSSIBLE_CELL_COLOR = new Color(185, 255, 185);
	public static final Color HINT_CANDIDATE_BACK_COLOR = new Color(63, 218, 101);
	public static final Color HINT_CANDIDATE_DELETE_BACK_COLOR = new Color(255, 118, 132);
	public static final Color HINT_CANDIDATE_CANNIBALISTIC_BACK_COLOR = new Color(235, 0, 0);
	public static final Color HINT_CANDIDATE_FIN_BACK_COLOR = new Color(127, 187, 255);
	public static final Color HINT_CANDIDATE_ENDO_FIN_BACK_COLOR = new Color(216, 178, 255);
	public static final Color HINT_CANDIDATE_COLOR = Color.BLACK;
	public static final Color HINT_CANDIDATE_DELETE_COLOR = Color.BLACK;
	public static final Color HINT_CANDIDATE_CANNIBALISTIC_COLOR = Color.BLACK;
	public static final Color HINT_CANDIDATE_FIN_COLOR = Color.BLACK;
	public static final Color HINT_CANDIDATE_ENDO_FIN_COLOR = Color.BLACK;
	public static final Color[] HINT_CANDIDATE_ALS_BACK_COLORS = { new Color(197, 232, 140), new Color(255, 203, 203),
			new Color(178, 223, 223), new Color(252, 220, 165) };
	public static final Color[] HINT_CANDIDATE_ALS_COLORS = { Color.BLACK, Color.BLACK, Color.BLACK, Color.BLACK };
	public static final Color ARROW_COLOR = Color.RED;
	public static final double VALUE_FONT_FACTOR = 0.6;
	public static final double CANDIDATE_FONT_FACTOR = 0.25;
	public static final double HINT_BACK_FACTOR = 1.6;
	/** How much should the lines around the boxes be thicker than normal lines */
	public static final double BOX_LINE_FACTOR = 1.5;
	private Color[] hintCandidateAlsBackColors = null;
	private Color[] hintCandidateAlsColors = null;
	public static final String DEFAULT_FILE_DIR = System.getProperty("user.home");
	public static final String DEFAULT_IMAGE_DIR = System.getProperty("user.home");
	public static final String DEFAULT_LANGUAGE = "";
	public static final String DEFAULT_LAF = "";
	public static final PuzzleType PUZZLE_TYPE = PuzzleType.STANDARD;

	// history of created puzzles and savepoints
	public static final int HISTORY_SIZE = 50;
	public static final boolean HISTORY_PREVIEW = true;
	private final int historySize = HISTORY_SIZE;
	private final List<String> historyOfCreatedPuzzles = new ArrayList<>(this.historySize);

	public static final int BDS_SEARCH_CANDIDATES_ANZ = 0;
	// Generator Patterns: List is empty per default
	public static final int GENERATOR_PATTERN_INDEX = -1;
	private final List<PatternFactory> generatorPatterns = new ArrayList<>();
	private final int generatorPatternIndex = GENERATOR_PATTERN_INDEX;

	// Singleton
	public static Options instance = null;

	public Options() {
		this.difficultyLevels = this.copyDifficultyLevels(DEFAULT_DIFFICULTY_LEVELS);
		this.orgSolverSteps = DEFAULT_SOLVER_STEPS;
		this.sortProgressSteps(this.orgSolverSteps);
		this.solverSteps = DEFAULT_SOLVER_STEPS;
		this.sortProgressSteps(this.solverSteps);
		this.solverStepsProgress = DEFAULT_SOLVER_STEPS;
		this.sortProgressSteps(this.solverStepsProgress);
		this.hintCandidateAlsBackColors = new Color[HINT_CANDIDATE_ALS_BACK_COLORS.length];
		for (int i = 0; i < HINT_CANDIDATE_ALS_BACK_COLORS.length; i++) {
			this.hintCandidateAlsBackColors[i] = new Color(HINT_CANDIDATE_ALS_BACK_COLORS[i].getRGB());
		}
		this.hintCandidateAlsColors = new Color[HINT_CANDIDATE_ALS_COLORS.length];
		for (int i = 0; i < HINT_CANDIDATE_ALS_COLORS.length; i++) {
			this.hintCandidateAlsColors[i] = new Color(HINT_CANDIDATE_ALS_COLORS[i].getRGB());
		}
		this.coloringColors = new Color[COLORING_COLORS.length];
		for (int i = 0; i < COLORING_COLORS.length; i++) {
			this.coloringColors[i] = new Color(COLORING_COLORS[i].getRGB());
		}
	}

	/**
	 * Find a {@link DifficultyLevel} via its ordinal.
	 */
	public DifficultyLevel getDifficultyLevel(final int ordinal) {
		int i = 0;
		for (i = 0; i < this.difficultyLevels.length; i++) {
			if (ordinal == this.difficultyLevels[i].getOrdinal()) {
				break;
			}
		}
		if (i >= this.difficultyLevels.length) {
			return null;
		} else {
			return this.difficultyLevels[i];
		}
	}

	/**
	 * Adds a new sudoku to the creation history. The size of the history buffer
	 * is adjusted accordingly. New sudokus are always inserted at the start of
	 * the list and deleted from the end of the list, effectively turning the list
	 * in a queue (the performance overhead can be ignored here).
	 */
	public void addSudokuToHistory(final Sudoku2 sudoku) {
		if (sudoku.getLevel() == null) {
			// something went wrong, dont add it to the history
			return;
		}
		final List<String> history = this.historyOfCreatedPuzzles;
		while (history.size() > this.historySize - 1) {
			history.remove(history.size() - 1);
		}
		final String str = sudoku.getSudoku(ClipboardMode.CLUES_ONLY) + "#" + sudoku.getLevel().getOrdinal() + "#"
				+ sudoku.getScore() + "#" + new Date().getTime();
		history.add(0, str);
	}

	public static Options getInstance() {
		if (instance == null) {
			instance = new Options();
		}
		return instance;
	}

	public DifficultyLevel[] copyDifficultyLevels(final DifficultyLevel[] src) {
		final DifficultyLevel[] dest = new DifficultyLevel[src.length];
		for (int i = 0; i < src.length; i++) {
			final DifficultyLevel act = src[i];
			dest[i] = new DifficultyLevel(act.getType(), act.getMaxScore(), act.getName(), act.getBackgroundColor(),
					act.getForegroundColor());
		}
		return dest;
	}

	/**
	 * Resort the progressSteps (needed after options change)
	 */
	public void sortProgressSteps(final StepConfig[] stepConfigs) {
		Arrays.sort(stepConfigs, progressComparator);
	}

	/**
	 * Since the local is set AFTER the options have been read, the names of the
	 * difficulty levels are always in the default local. They have to be adjusted
	 * after the correct locale has been set.
	 */
	public void resetDifficultyLevelStrings() {
		DEFAULT_DIFFICULTY_LEVELS[0].setName(INCOMPLETE);
		DEFAULT_DIFFICULTY_LEVELS[1].setName(EASY);
		DEFAULT_DIFFICULTY_LEVELS[2].setName(MEDIUM);
		DEFAULT_DIFFICULTY_LEVELS[3].setName(HARD);
		DEFAULT_DIFFICULTY_LEVELS[4].setName(UNFAIR);
		DEFAULT_DIFFICULTY_LEVELS[5].setName(EXTREME);
		this.difficultyLevels[0].setName(INCOMPLETE);
		this.difficultyLevels[1].setName(EASY);
		this.difficultyLevels[2].setName(MEDIUM);
		this.difficultyLevels[3].setName(HARD);
		this.difficultyLevels[4].setName(UNFAIR);
		this.difficultyLevels[5].setName(EXTREME);
	}

	/**
	 * Returns a String that contains a comma seperated list of all steps, that
	 * are configured for training mode.
	 */
	public String getTrainingStepsString(final boolean ellipsis) {
		return this.getTrainingStepsString(this.orgSolverSteps, ellipsis);
	}

	/**
	 * Returns a String that contains a comma seperated list of all steps, that
	 * are configured for training mode.<br>
	 * If ellipsis is <cde>true</code>, only one technique us shown. If more than
	 * one technique is selected, an ellipsis is appended to the first technique.
	 */
	public String getTrainingStepsString(final StepConfig[] stepArray, final boolean ellipsis) {
		final StringBuilder tmp = new StringBuilder();
		boolean first = true;
		for (final StepConfig step : stepArray) {
			if (step.isEnabledTraining()) {
				if (first) {
					first = false;
				} else {
					if (ellipsis) {
						tmp.append("...");
						break;
					} else {
						tmp.append(", ");
					}
				}
				tmp.append(step.getType().getStepName());
			}
		}
		return tmp.toString();
	}

	private static class ProgressComparator implements Comparator<StepConfig> {

		@Override
		public int compare(final StepConfig o1, final StepConfig o2) {
			return o1.getIndexProgress() - o2.getIndexProgress();
		}
	}

	public int getGeneratorPatternIndex() {
		return this.generatorPatternIndex;
	}

	public List<PatternFactory> getGeneratorPatterns() {
		return this.generatorPatterns;
	}

	public int getAllStepsAlsChainLength() {
		return this.allStepsAlsChainLength;
	}

	public boolean isAllStepsAlsChainForwardOnly() {
		return this.allStepsAlsChainForwardOnly;
	}

	public boolean isAllowAlsOverlap() {
		return this.allowAlsOverlap;
	}

	public boolean isOnlyOneAlsPerStep() {
		return this.onlyOneAlsPerStep;
	}

	public int getFishDisplayMode() {
		return this.fishDisplayMode;
	}

	public Color[] getColoringColors() {
		return this.coloringColors;
	}

	public DifficultyLevel[] getDifficultyLevels() {
		return this.difficultyLevels;
	}

	public boolean isUseOrInsteadOfAndForFilter() {
		return this.useOrInsteadOfAndForFilter;
	}

	public boolean isRestrictChainSize() {
		return this.restrictChainSize;
	}

	public int getRestrictNiceLoopLength() {
		return this.restrictNiceLoopLength;
	}

	public int getRestrictChainLength() {
		return this.restrictChainLength;
	}

	public int getMaxFins() {
		return this.maxFins;
	}

	public void setMaxFins(final int maxFins) {
		this.maxFins = maxFins;
	}

	public int getMaxEndoFins() {
		return this.maxEndoFins;
	}

	public void setMaxEndoFins(final int maxEndoFins) {
		this.maxEndoFins = maxEndoFins;
	}

	public int getMaxKrakenFins() {
		return this.maxKrakenFins;
	}

	public int getMaxKrakenEndoFins() {
		return this.maxKrakenEndoFins;
	}

	public int getKrakenMaxFishType() {
		return this.krakenMaxFishType;
	}

	public int getKrakenMaxFishSize() {
		return this.krakenMaxFishSize;
	}

	public boolean isAllowDualsAndSiamese() {
		return this.allowDualsAndSiamese;
	}

	public boolean isOnlyOneFishPerStep() {
		return this.onlyOneFishPerStep;
	}

	public boolean isAllowErsWithOnlyTwoCandidates() {
		return this.allowErsWithOnlyTwoCandidates;
	}

	public boolean isCheckTemplates() {
		return this.checkTemplates;
	}

	public void setCheckTemplates(final boolean checkTemplates) {
		this.checkTemplates = checkTemplates;
	}

	public int getMaxTableEntryLength() {
		return this.maxTableEntryLength;
	}

	public boolean isAllowAlsInTablingChains() {
		return this.allowAlsInTablingChains;
	}

	public boolean isAllowUniquenessMissingCandidates() {
		return this.allowUniquenessMissingCandidates;
	}

	public boolean isOnlyOneChainPerStep() {
		return this.onlyOneChainPerStep;
	}

	public int getAnzTableLookAhead() {
		return this.anzTableLookAhead;
	}

}
