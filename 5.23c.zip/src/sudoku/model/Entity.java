/*
 * Copyright (C) 2008-12  Bernhard Hobiger
 *
 * This file is part of HoDoKu.
 *
 * HoDoKu is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * HoDoKu is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with HoDoKu. If not, see <http://www.gnu.org/licenses/>.
 */

package sudoku.model;

public class Entity implements Cloneable {
	private int entityName;
	private int entityNumber;

	public Entity() {

	}

	public Entity(final int name, final int number) {
		this.entityName = name;
		this.entityNumber = number;
	}

	@Override
	public boolean equals(final Object o) {
		if (o == null) {
			return false;
		}
		if (!(o instanceof Entity)) {
			return false;
		}
		final Entity c = (Entity) o;
		if (this.entityName == c.entityName && this.entityNumber == c.entityNumber) {
			return true;
		}
		return false;
	}

	@Override
	public int hashCode() {
		int hash = 7;
		hash = 13 * hash + this.entityName;
		hash = 13 * hash + this.entityNumber;
		return hash;
	}

	public int getEntityName() {
		return this.entityName;
	}

	public void setEntityName(final int entityName) {
		this.entityName = entityName;
	}

	public int getEntityNumber() {
		return this.entityNumber;
	}

	public void setEntityNumber(final int entityNumber) {
		this.entityNumber = entityNumber;
	}
}
