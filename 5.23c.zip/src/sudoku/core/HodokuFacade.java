package sudoku.core;

/**
 * This project incorporates a lot of components of the "HoDoKu" application.
 * Such files have the original copyright at the top to indicate their origin.
 * In addition, these files have been moderately changed in order to improve
 * code quality. However, due to the intricacy (and illegibility) of some code,
 * I have decided to leave the primary logic as is, and this class acts as a
 * single access point to all HoDoKu components.
 *
 * Thus, this class contains various methods to access HoDoKu components from a
 * SPOC.
 *
 */
public class HodokuFacade {
	private static HodokuFacade instance;

	public static HodokuFacade getInstance() {
		if (instance == null) {
			instance = new HodokuFacade();
		}
		return instance;
	}

	private HodokuFacade() {
		// Private constructor to prevent external instantiation.
	}

	// TODO - evaluate need for this class.

}
