/*
 * Copyright (C) 2008-12  Bernhard Hobiger
 *
 * This file is part of HoDoKu.
 *
 * HoDoKu is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * HoDoKu is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with HoDoKu. If not, see <http://www.gnu.org/licenses/>.
 */

package sudoku.factories;

import java.util.List;

import sudoku.model.Options;
import sudoku.model.SolutionStep;
import sudoku.model.Sudoku2;
import sudoku.model.util.ClipboardMode;
import sudoku.model.util.DifficultyLevel;
import sudoku.model.util.PuzzleType;
import sudoku.solver.SudokuSolver;

/**
 * A PuzzleGenerator generates sudokus with a given {@link DifficultyLevel} and
 * for a given {@link PuzzleType}.
 *
 */
public final class SudokuPuzzleGenerator {

	private static SudokuPuzzleGenerator instance;

	public static SudokuPuzzleGenerator getInstance() {
		if (instance == null) {
			instance = new SudokuPuzzleGenerator();
		}
		return instance;
	}

	public SudokuPuzzleGenerator() {
		// Nothing to do.
	}

	/**
	 * Creates a sudoku with the given difficulty level and game mode.
	 */
	public String generate(final DifficultyLevel level, final PuzzleType mode) {
		Sudoku2 sudoku = null;
		SudokuFactory creator = null;
		SudokuSolver solver = null;
		solver = SudokuSolver.getInstance();
		creator = SudokuFactory.getInstance();
		sudoku = creator.generateSudoku(true);
		final Sudoku2 solvedSudoku = sudoku.clone();
		// while (solvedSudoku.getLevel() != level) {
		final boolean ok = solver.solve(level, solvedSudoku, true, false, Options.getInstance().solverSteps, mode);
		boolean containsTrainingStep = true;
		if (mode != PuzzleType.STANDARD) {
			containsTrainingStep = false;
			final List<SolutionStep> steps = solver.getSteps();
			for (final SolutionStep step : steps) {
				if (step.getType().getStepConfig().isEnabledTraining()) {
					containsTrainingStep = true;
					break;
				}
			}
		}
		if (ok && containsTrainingStep && (solvedSudoku.getLevel().getOrdinal() == level.getOrdinal()
				|| mode == PuzzleType.SOLVED_JUST_BEFORE_SPECIFIC_TECHNIQUE)) {
			sudoku.setLevel(solvedSudoku.getLevel());
			sudoku.setScore(solvedSudoku.getScore());
		}
		// }

		return sudoku.getSudoku(ClipboardMode.CLUES_ONLY);
	}

}
