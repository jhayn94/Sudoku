/*
 * Copyright (C) 2008-12  Bernhard Hobiger
 *
 * This file is part of HoDoKu.
 *
 * HoDoKu is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * HoDoKu is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with HoDoKu. If not, see <http://www.gnu.org/licenses/>.
 */
package sudoku.factories;

import java.util.Arrays;

import sudoku.model.Sudoku2;

/**
 * A pattern indicates which cells should contain givens when generating new
 * puzzles. This class generates these patterns, which are used by
 * SudokuGenerator to create proper puzzles.
 *
 * <b>Caution:</b> The setter for {@link #pattern} only sets the reference, the
 * constructor actually makes a copy of the pattern, that has been passed in.
 * When working with new patterns, only the constructor should be used, the
 * setter is used internally by <code>XmlDecoder</code>.
 *
 */
public class PatternFactory implements Cloneable {
	/**
	 * One entry per cell; if it is <code>true</code>, the cell must be a given.
	 */
	private boolean[] pattern = new boolean[Sudoku2.LENGTH];
	/** The name of the pattern. */
	private String name = "";
	/**
	 * Patterns must be tested befor they can be applied. the result of the test
	 * is stored here.
	 */
	private boolean valid = false;

	public PatternFactory() {
		// Nothing to do.
	}

	/**
	 * Constructor: Makes a new pattern with a given name.
	 *
	 * @param name
	 */
	public PatternFactory(final String name) {
		this.name = name;
	}

	/**
	 * Constructor: Makes a copy of the pattern and sets it.
	 *
	 * @param name
	 * @param pattern
	 */
	public PatternFactory(final String name, final boolean[] pattern) {
		this.name = name;
		this.pattern = Arrays.copyOf(pattern, pattern.length);
	}

	/**
	 * Makes a copy of a GeneratorPattern.
	 *
	 * @return
	 */
	@Override
	public PatternFactory clone() {
		PatternFactory newPattern = null;
		newPattern = new PatternFactory();
		// no deep copy required for name, it is immutable
		newPattern.setName(this.name);
		newPattern.setValid(this.valid);
		System.arraycopy(this.pattern, 0, newPattern.pattern, 0, this.pattern.length);
		return newPattern;
	}

	@Override
	public String toString() {
		return this.name + ": " + Arrays.toString(this.pattern);
	}

	/**
	 * Returns the number of entries in {@link #pattern}, that are
	 * <code>true</code>.
	 */
	public int getAnzGivens() {
		int anz = 0;
		for (int i = 0; i < this.pattern.length; i++) {
			if (this.pattern[i]) {
				anz++;
			}
		}
		return anz;
	}

	public boolean[] getPattern() {
		return this.pattern;
	}

	public void setPattern(final boolean[] pattern) {
		this.pattern = pattern;
	}

	public String getName() {
		return this.name;
	}

	public void setName(final String name) {
		this.name = name;
	}

	public boolean isValid() {
		return this.valid;
	}

	public void setValid(final boolean valid) {
		this.valid = valid;
	}

}
